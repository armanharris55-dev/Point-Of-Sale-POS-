/* Dashboard pages: expenses, reports, users, settings */
(function(){
const P=AP.pages=AP.pages||{};const $=AP.$,$$=AP.$$,E=AP.esc,M=AP.money;
const ECATS=['Shop rent','Electricity','Salary','Transport','Tea & snacks','Internet / phone','Repair','Marketing','Supplier payment','Other'];

/* ----- EXPENSES ----- */
AP.expenseForm=function(done,drawer){
  const sh=AP.openShift();
  const m=AP.modal({title:'Add expense',size:'sm',body:'<div class="grid g2"><div class="fld"><label class="req">Category</label><select class="sel" id="ec">'+ECATS.map(c=>'<option>'+c+'</option>').join('')+'</select></div><div class="fld"><label class="req">Amount (৳)</label><input class="inp" type="number" min="0" step="0.01" id="ea"></div></div><div class="fld" style="margin-top:10px"><label>Paid from</label><select class="sel" id="em"><option value="cash">Cash'+(sh?' (counter drawer)':'')+'</option><option value="bank">Bank</option><option value="bkash">bKash</option></select></div><div class="fld" style="margin-top:10px"><label>Note</label><input class="inp" id="en" placeholder="Optional"></div>',
    foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:mm=>{const a=+$('#ea',m.el).value;if(!(a>0)){AP.toast('Enter the amount','bad');return}const meth=$('#em',m.el).value;
      AP.put('expenses',{id:AP.uid(),no:AP.seq('exp','EXP-',5),t:Date.now(),cat:$('#ec',m.el).value,amount:a,method:meth,note:$('#en',m.el).value.trim(),by:AP.me().name,drawer:meth==='cash'&&!!sh&&(drawer!==false),shiftId:sh?sh.id:null});mm.close();AP.toast('Expense saved');if(done)done()}}]});
};
P.expenses=function(v){
  AP.list(v,{title:'Expenses',unit:'expenses',rows:()=>AP.all('expenses').sort((a,b)=>b.t-a.t),search:r=>r.no+' '+r.cat+' '+r.note,date:r=>r.t,
    pre:'',actions:p=>{p.innerHTML='<button class="btn" id="a">+ Add expense</button>';$('#a',p).onclick=()=>AP.expenseForm(()=>AP.refresh())},
    filters:[{k:'q',type:'text',ph:'Category or note',grow:1},{k:'cat',label:'Category',opts:()=>[['','All']].concat(ECATS.map(c=>[c,c])),test:(r,v)=>r.cat===v},{k:'from',type:'date',label:'From'},{k:'to',type:'date',label:'To'}],
    cols:[{h:'No.',f:r=>'<span class="mono b">'+r.no+'</span>'},{h:'Date',f:r=>AP.dt(r.t)},{h:'Category',f:r=>E(r.cat)},{h:'Note',f:r=>E(r.note||'—')},{h:'From',f:r=>E(r.method)},{h:'Amount',cls:'r num',f:r=>AP.n(r.amount)},{h:'By',f:r=>E(r.by)},{h:'',cls:'r',f:r=>'<button class="btn sm danger" data-d="'+r.id+'">Delete</button>'}],
    empty:{icon:'<i class="fa-solid fa-money-bill-transfer"></i>',title:'No expenses yet',text:'Record rent, salary, tea… to see true profit.',btn:'+ Add expense',fn:()=>AP.expenseForm(()=>AP.refresh())},
    after:tw=>$$('[data-d]',tw).forEach(b=>b.onclick=async()=>{if(await AP.confirm('Delete this expense?','Delete',true)){AP.del('expenses',b.dataset.d);AP.refresh()}})});
};

/* ----- REPORTS ----- */
P.reports=function(v,tab){
  tab=tab||'day';
  const T=[['day','Day summary'],['items','Item sales'],['profit','Profit'],['stock','Stock value'],['due','Due list'],['low','Low stock'],['expiry','Expiry']];
  const today=AP.iso(Date.now());let from=AP.q.get('from')||today,to=AP.q.get('to')||today;
  if(tab==='profit'&&!AP.q.get('from')){const d=new Date();d.setDate(1);from=AP.iso(d)}
  const range=()=>{const a=+new Date(from+'T00:00:00'),b=+new Date(to+'T00:00:00')+864e5;return[a,b]};
  const draw=()=>{
    const [a,b]=range();const inv=AP.all('invoices').filter(i=>i.t>=a&&i.t<b);
    v.innerHTML='<div class="ph"><h1>Reports</h1><div class="row w">'+(['day','items','profit'].includes(tab)?'<input class="inp" type="date" id="f1" value="'+from+'" style="width:150px"><span class="muted">to</span><input class="inp" type="date" id="f2" value="'+to+'" style="width:150px">':'')+'<button class="btn ghost" id="csv"><i class="fa-solid fa-file-csv"></i> CSV</button><button class="btn ghost" onclick="print()"><i class="fa-solid fa-print"></i> Print</button></div></div><div class="tabs">'+T.map(t=>'<button data-t="'+t[0]+'" class="'+(t[0]===tab?'on':'')+'">'+t[1]+'</button>').join('')+'</div><div id="rb"></div>';
    $$('.tabs button',v).forEach(x=>x.onclick=()=>{location.hash='#/reports/'+x.dataset.t});
    const f1=$('#f1',v);if(f1){f1.onchange=()=>{from=f1.value;draw()};$('#f2',v).onchange=e=>{to=e.target.value;draw()}}
    const rb=$('#rb',v);let csv=[];
    const net=i=>i.total-(i.returned||0);
    if(tab==='day'||tab==='profit'){
      const ret=AP.all('returns').filter(r=>r.t>=a&&r.t<b),exp=AP.all('expenses').filter(e=>e.t>=a&&e.t<b&&e.cat!=='Supplier payment'),rec=AP.all('receipts').filter(r=>r.t>=a&&r.t<b);
      const sales=inv.reduce((s,i)=>s+i.total,0),rf=ret.reduce((s,r)=>s+r.refund,0),cogs=inv.reduce((s,i)=>s+i.items.reduce((x,l)=>x+l.cost*(l.qty-(l.ret||0)),0),0);
      const ex=exp.reduce((s,e)=>s+e.amount,0),gross=sales-rf-cogs,np=gross-ex;
      const pm={};inv.forEach(i=>(i.pay||[]).forEach(p=>{pm[p.m]=(pm[p.m]||0)+p.amt-(p.m==='cash'?i.change||0:0)}));
      const due=inv.reduce((s,i)=>s+i.due,0);
      rb.innerHTML='<div class="grid g4" style="margin-bottom:14px"><div class="card kpi mint"><div class="k">Sales</div><div class="v">'+M(sales)+'</div><div class="s">'+inv.length+' invoices</div></div><div class="card kpi"><div class="k">Returns</div><div class="v">'+M(rf)+'</div><div class="s">'+ret.length+' returns</div></div><div class="card kpi"><div class="k">Gross profit</div><div class="v">'+M(gross)+'</div><div class="s">After cost of goods</div></div><div class="card kpi ink"><div class="k">Net profit</div><div class="v">'+M(np)+'</div><div class="s">After '+M(ex)+' expenses</div></div></div>'
      +'<div class="grid g2"><div class="card pad"><h3>Payment methods</h3>'+(Object.keys(pm).length?Object.keys(pm).map(k=>'<div class="sumrow"><span>'+(AP.PAY[k]||k)+'</span><b>'+M(pm[k])+'</b></div>').join(''):'<p class="muted">No payments</p>')+'<div class="sumrow"><span>Sold on due</span><b class="warn">'+M(due)+'</b></div><div class="sumrow"><span>Due collected</span><b>'+M(rec.filter(r=>r.type==='Due collected').reduce((s,r)=>s+r.amount,0))+'</b></div></div><div class="card pad"><h3>Expenses</h3>'+(exp.length?exp.map(e=>'<div class="sumrow"><span>'+E(e.cat)+(e.note?' · '+E(e.note):'')+'</span><b>'+M(e.amount)+'</b></div>').join(''):'<p class="muted">No expenses</p>')+'</div></div>';
      csv=[['Metric','Amount'],['Sales',sales],['Returns',rf],['COGS',cogs],['Gross profit',gross],['Expenses',ex],['Net profit',np]];
    }
    if(tab==='items'){
      const o={};inv.forEach(i=>i.items.forEach(l=>{const q=l.qty-(l.ret||0);const x=o[l.pid]||(o[l.pid]={n:l.name,q:0,r:0,c:0});x.q+=q;x.r+=l.price*q-l.disc;x.c+=l.cost*q}));
      const L=Object.values(o).sort((x,y)=>y.r-x.r);
      rb.innerHTML=L.length?'<div class="card tw"><table class="t"><thead><tr><th>#</th><th>Item</th><th class="r">Qty sold</th><th class="r">Revenue</th><th class="r">Cost</th><th class="r">Profit</th></tr></thead><tbody>'+L.map((x,k)=>'<tr><td class="muted">'+(k+1)+'</td><td class="b">'+E(x.n)+'</td><td class="r num">'+x.q+'</td><td class="r num">'+AP.n(x.r)+'</td><td class="r num">'+AP.n(x.c)+'</td><td class="r num '+(x.r-x.c<0?'bad':'ok')+'">'+AP.n(x.r-x.c)+'</td></tr>').join('')+'</tbody></table></div>':'<div class="card empty"><div class="ei"><i class="fa-solid fa-chart-column"></i></div><h4>No sales in this period</h4></div>';
      csv=[['Item','Qty','Revenue','Cost','Profit']].concat(L.map(x=>[x.n,x.q,x.r,x.c,x.r-x.c]));
    }
    const prods=AP.all('products').filter(p=>p.type!=='service'&&p.on!==false);
    const tbl=(h,rows,empty)=>rows.length?'<div class="card tw"><table class="t"><thead><tr>'+h.map(x=>'<th class="'+(x[1]||'')+'">'+x[0]+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map((c,i)=>'<td class="'+(h[i][1]||'')+'">'+c+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>':'<div class="card empty"><div class="ei">✓</div><h4>'+empty+'</h4></div>';
    if(tab==='stock'){const rows=prods.map(p=>[E(p.name),AP.n(p.stock,0)+' '+E(p.unit),AP.n(p.cost),AP.n((+p.stock||0)*(+p.cost||0)),AP.n((+p.stock||0)*(+p.price||0))]);const tc=prods.reduce((s,p)=>s+(+p.stock||0)*(+p.cost||0),0),tr=prods.reduce((s,p)=>s+(+p.stock||0)*(+p.price||0),0);
      rb.innerHTML='<div class="grid g2" style="margin-bottom:14px"><div class="card kpi"><div class="k">Stock value at cost</div><div class="v">'+M(tc)+'</div></div><div class="card kpi mint"><div class="k">Stock value at selling price</div><div class="v">'+M(tr)+'</div><div class="s">Possible profit '+M(tr-tc)+'</div></div></div>'+tbl([['Item'],['Stock','r'],['Cost','r'],['Value (cost)','r'],['Value (sell)','r']],rows,'No stock'),csv=[['Item','Stock','Cost','Value cost','Value sell']].concat(prods.map(p=>[p.name,p.stock,p.cost,p.stock*p.cost,p.stock*p.price]))}
    if(tab==='due'){const L=AP.all('customers').map(c=>({c,d:AP.custDue(c.id)})).filter(x=>x.d>0).sort((x,y)=>y.d-x.d);rb.innerHTML=tbl([['Customer'],['Mobile'],['Oldest bill'],['Due','r'],['']],L.map(x=>{const o=AP.all('invoices').filter(i=>i.customerId===x.c.id&&i.due>0).sort((p,q)=>p.t-q.t)[0];return['<b>'+E(x.c.name)+'</b>',E(x.c.phone),o?AP.d(o.t)+' · '+AP.ago(o.t):'—','<b class="bad">'+AP.n(x.d)+'</b>','<a class="btn sm" href="'+AP.waLink(x.c.phone,'আসসালামু আলাইকুম '+x.c.name+', '+AP.cfg().shop.name+'-এ আপনার বকেয়া '+M(x.d)+'। ধন্যবাদ।')+'" target="_blank"><i class="fa-brands fa-whatsapp"></i> Remind</a> <a class="btn sm ghost" href="#/receipts/new?c='+x.c.id+'">Receive</a>']}),'Nobody owes you money <i class="fa-solid fa-circle-check"></i>');csv=[['Customer','Mobile','Due']].concat(L.map(x=>[x.c.name,x.c.phone,x.d]))}
    if(tab==='low'){const L=AP.alerts().low;rb.innerHTML=(L.length?'<div class="row" style="margin-bottom:12px"><span class="sp muted">Items at or below their low-stock level</span><a class="btn" href="#/stockin?low=1"><i class="fa-solid fa-arrow-down"></i> Make stock-in from this list</a></div>':'')+tbl([['Item'],['Category'],['Stock','r'],['Alert at','r']],L.map(p=>['<b>'+E(p.name)+'</b>',E(AP.catName(p.cat)||'—'),'<b class="'+(p.stock<=0?'bad':'warn')+'">'+AP.n(p.stock,0)+'</b>',p.min||'—']),'Stock levels are healthy');csv=[['Item','Stock','Alert']].concat(L.map(p=>[p.name,p.stock,p.min]))}
    if(tab==='expiry'){const L=prods.filter(p=>p.expiry&&(+p.stock||0)>0).sort((x,y)=>x.expiry.localeCompare(y.expiry));rb.innerHTML=tbl([['Item'],['Expiry'],['Status'],['Stock','r'],['Value at cost','r']],L.map(p=>{const dd=Math.ceil((+new Date(p.expiry)-Date.now())/864e5);return['<b>'+E(p.name)+'</b>',E(p.expiry),dd<0?'<span class="tag bad">Expired '+(-dd)+' d ago</span>':dd<=30?'<span class="tag warn">In '+dd+' days</span>':'<span class="tag ok">'+dd+' days</span>',AP.n(p.stock,0),AP.n(p.stock*p.cost)]}),'No items with expiry dates');csv=[['Item','Expiry','Stock']].concat(L.map(p=>[p.name,p.expiry,p.stock]))}
    $('#csv',v).onclick=()=>AP.csv('report-'+tab+'.csv',csv);
  };
  draw();
};

/* ----- USERS ----- */
P.users=function(v){
  const me=AP.me();if(me.role!=='owner'){v.innerHTML='<div class="card empty"><div class="ei"><i class="fa-solid fa-lock"></i></div><h4>Only the owner can manage users</h4></div>';return}
  const form=u=>{u=u||{};const m=AP.modal({title:u.id?'Edit user':'Add user',body:'<div class="grid g2"><div class="fld"><label class="req">Name</label><input class="inp" id="un" value="'+E(u.name||'')+'"></div><div class="fld"><label class="req">Role</label><select class="sel" id="ur"><option value="cashier"'+(u.role==='cashier'?' selected':'')+'>Cashier (POS only)</option><option value="manager"'+(u.role==='manager'?' selected':'')+'>Manager (all except users)</option></select></div><div class="fld"><label class="req">Email</label><input class="inp" id="ue" value="'+E(u.email||'')+'"></div><div class="fld"><label>Mobile</label><input class="inp" id="up" value="'+E(u.phone||'')+'"></div></div><div class="fld" style="margin-top:12px"><label'+(u.id?'':' class="req"')+'>'+(u.id?'New password (leave empty to keep)':'Password')+'</label><input class="inp" type="password" id="upw" autocomplete="new-password"><div class="hint">At least 8 characters.</div></div>',
    foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:async mm=>{const n=$('#un',m.el).value.trim(),e=$('#ue',m.el).value.trim().toLowerCase(),pw=$('#upw',m.el).value;
      if(!n||!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)){AP.toast('Enter name and a valid email','bad');return}
      if(AP.all('users').some(x=>x.email===e&&x.id!==u.id)){AP.toast('Email already used','bad');return}
      if(!u.id&&pw.length<8||pw&&pw.length<8){AP.toast('Password must be 8+ characters','bad');return}
      const o=Object.assign({t:Date.now()},u,{name:n,email:e,phone:$('#up',m.el).value.trim(),role:$('#ur',m.el).value});if(pw)o.pass=await AP.sha(pw);AP.put('users',o);mm.close();AP.toast('User saved');AP.refresh()}}]})};
  AP.list(v,{title:'Users',unit:'users',rows:()=>AP.all('users'),search:r=>r.name+' '+r.email,
    actions:p=>{p.innerHTML='<button class="btn" id="a">+ Add user</button>';$('#a',p).onclick=()=>form()},
    filters:[{k:'q',type:'text',ph:'Name or email',grow:1}],
    cols:[{h:'Name',f:r=>'<span class="av" style="display:inline-grid;width:28px;height:28px;font-size:11px;margin-right:8px;vertical-align:middle">'+AP.avatar(r.name)+'</span><b>'+E(r.name)+'</b>'+(r.id===me.id?' <span class="tag">you</span>':'')},{h:'Email',f:r=>E(r.email)},{h:'Role',f:r=>'<span class="tag '+(r.role==='owner'?'ok':'')+'">'+r.role+'</span>'},{h:'Status',f:r=>r.off?'<span class="tag bad">Disabled</span>':'<span class="tag ok">Active</span>'},{h:'',cls:'r',f:r=>r.role==='owner'?'':'<button class="btn sm ghost" data-e="'+r.id+'">Edit</button> <button class="btn sm danger" data-t="'+r.id+'">'+(r.off?'Enable':'Disable')+'</button>'}],
    empty:{title:'No users'},after:tw=>{$$('[data-e]',tw).forEach(b=>b.onclick=()=>form(AP.find('users',b.dataset.e)));$$('[data-t]',tw).forEach(b=>b.onclick=()=>{const u=AP.find('users',b.dataset.t);u.off=!u.off;AP.put('users',u);AP.refresh()})}});
};

/* ----- SETTINGS ----- */
P.settings=function(v){
  const c=AP.cfg(),me=AP.me();
  v.innerHTML='<div class="ph"><h1>Settings</h1><button class="btn" id="sv">Save settings</button></div>'
  +'<div class="grid g2" style="align-items:start"><div class="card pad"><h3>Shop details <span class="muted" style="font-weight:400">(printed on invoices)</span></h3><div class="grid" style="gap:12px"><div class="fld"><label class="req">Shop name</label><input class="inp" id="sn" value="'+E(c.shop.name)+'"></div><div class="fld"><label>Address</label><input class="inp" id="sa" value="'+E(c.shop.addr||'')+'"></div><div class="grid g2"><div class="fld"><label>Phone</label><input class="inp" id="sp" value="'+E(c.shop.phone||'')+'"></div><div class="fld"><label>Email</label><input class="inp" id="se" value="'+E(c.shop.email||'')+'"></div></div><div class="fld"><label>Invoice footer</label><input class="inp" id="sf" value="'+E(c.footer||'')+'"></div></div></div>'
  +'<div class="card pad"><h3>Targets &amp; estimates</h3><div class="grid g2" style="gap:12px"><div class="fld"><label>Daily sales target (৳)</label><input class="inp" type="number" min="0" id="stg" value="'+(c.target||'')+'" placeholder="Shown on dashboard"></div><div class="fld"><label>Margin for manual sales (%)</label><input class="inp" type="number" min="0" max="100" id="smm" value="'+(c.manualMargin==null?20:c.manualMargin)+'"></div></div><p class="muted" style="font-size:12.5px;margin:8px 0 0">Manual sales have no item cost, so profit is estimated with this margin.</p></div>'
  +'<div class="card pad"><h3>Selling</h3><div class="grid g2" style="gap:12px"><div class="fld"><label>VAT % on every sale</label><input class="inp" type="number" min="0" max="100" id="sv1" value="'+(c.vat||0)+'"></div><div class="fld"><label>Default print</label><select class="sel" id="sp1"><option value="80"'+(c.paper==='80'?' selected':'')+'>80 mm receipt</option><option value="a4"'+(c.paper==='a4'?' selected':'')+'>A4</option></select></div><div class="fld"><label>Default low-stock level</label><input class="inp" type="number" min="0" id="sl" value="'+(c.lowStock||5)+'"></div><div class="fld"><label>Loyalty: 1 point per ৳</label><input class="inp" type="number" min="1" id="spt" value="'+(c.ptsPer||100)+'"></div></div><label class="chk" style="margin-top:14px"><input type="checkbox" id="swa" '+(c.wa!==false?'checked':'')+'> Show WhatsApp buttons (due reminder, invoice share)</label></div></div>'
  +'<div class="card pad" style="margin-top:16px"><h3>Data</h3><p class="muted" style="margin-top:0">This version keeps data in this browser. Back it up regularly. When the PHP + MySQL backend is connected, data will live on your server.</p><div class="row w"><button class="btn ghost" id="bk"><i class="fa-solid fa-arrow-down"></i> Download backup</button><button class="btn ghost" id="rs"><i class="fa-solid fa-arrow-up-from-bracket"></i> Restore backup</button><button class="btn ghost" id="dm"><i class="fa-solid fa-wand-magic-sparkles"></i> Load demo data</button><button class="btn danger" id="wp"><i class="fa-solid fa-trash"></i> Erase all shop data</button></div></div>';
  $('#sv',v).onclick=()=>{const n=$('#sn',v).value.trim();if(!n){AP.toast('Shop name is required','bad');return}
    AP.setCfg({shop:{name:n,addr:$('#sa',v).value.trim(),phone:$('#sp',v).value.trim(),email:$('#se',v).value.trim()},vat:+$('#sv1',v).value||0,footer:$('#sf',v).value.trim(),paper:$('#sp1',v).value,lowStock:+$('#sl',v).value||0,ptsPer:+$('#spt',v).value||100,ptsValue:1,target:+$('#stg',v).value||0,manualMargin:$('#smm',v).value===''?20:+$('#smm',v).value,wa:$('#swa',v).checked});AP.toast('Settings saved');$('#shopchip').firstChild.textContent=n};
  $('#bk',v).onclick=()=>{const o={};Object.keys(localStorage).filter(k=>k.startsWith('amnpos:')&&!/session|draft_/.test(k)).forEach(k=>o[k]=localStorage.getItem(k));const b=new Blob([JSON.stringify(o)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='amanath-pos-backup-'+AP.iso(Date.now())+'.json';a.click()};
  $('#rs',v).onclick=()=>{const i=document.createElement('input');i.type='file';i.accept='.json';i.onchange=async()=>{try{const o=JSON.parse(await i.files[0].text());if(!Object.keys(o).every(k=>k.startsWith('amnpos:')))throw 0;if(!await AP.confirm('Restore will <b>replace</b> current data. Continue?','Restore',true))return;Object.keys(o).forEach(k=>localStorage.setItem(k,o[k]));location.reload()}catch(e){AP.toast('Not a valid backup file','bad')}};i.click()};
  $('#dm',v).onclick=async()=>{if(AP.all('products').length&&!await AP.confirm('Demo data will be <b>added</b> to your existing data. Continue?'))return;AP.seedDemo();AP.refresh()};
  $('#wp',v).onclick=()=>{if(me.role!=='owner'){AP.toast('Only the owner can erase data','bad');return}const m=AP.modal({title:'Erase all shop data',size:'sm',body:'<p>This deletes <b>products, customers, invoices, stock</b> and everything else. Users and settings stay. This cannot be undone.</p><div class="fld"><label>Type ERASE to confirm</label><input class="inp" id="ec"></div>',foot:[{label:'Cancel'},{label:'Erase everything',cls:'acc',fn:mm=>{if($('#ec',m.el).value!=='ERASE'){AP.toast('Type ERASE exactly','bad');return}const keep=['users','cfg','session','theme'];Object.keys(localStorage).filter(k=>k.startsWith('amnpos:')&&!keep.includes(k.slice(7))).forEach(k=>localStorage.removeItem(k));mm.close();AP.toast('All shop data erased');location.hash='#/home';AP.refresh()}}]})};
};

P.activity=function(v){
  AP.list(v,{title:'Activity log',unit:'events',rows:()=>AP.get('log',[]),search:r=>r.type+' '+r.msg+' '+r.by,date:r=>r.t,
    filters:[{k:'q',type:'text',ph:'Search activity',grow:1},{k:'from',type:'date',label:'From'},{k:'to',type:'date',label:'To'}],
    cols:[{h:'When',f:r=>AP.dt(r.t)},{h:'Event',f:r=>'<b>'+E(r.type)+'</b>'},{h:'Details',f:r=>E(r.msg||'')},{h:'By',f:r=>E(r.by)}],
    empty:{icon:'<i class="fa-solid fa-list-check"></i>',title:'Nothing logged yet',text:'Sales, stock-ins, cash moves and settings changes appear here.'}});
};
})();
