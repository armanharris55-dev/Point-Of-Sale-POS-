/* Dashboard pages: products, product wizard, catalog, stock in */
(function(){
const P=AP.pages=AP.pages||{};const $=AP.$,$$=AP.$$,E=AP.esc,M=AP.money;
const catOpts=(sel,none)=>(none?'<option value="">'+none+'</option>':'')+AP.all('categories').filter(c=>!c.parent).sort((a,b)=>a.name.localeCompare(b.name)).map(c=>{const subs=AP.all('categories').filter(s=>s.parent===c.id);return'<option value="'+c.id+'"'+(sel===c.id?' selected':'')+'>'+E(c.name)+'</option>'+subs.map(s=>'<option value="'+s.id+'"'+(sel===s.id?' selected':'')+'>&nbsp;&nbsp;↳ '+E(s.name)+'</option>').join('')}).join('');
const brandOpts=sel=>'<option value="">None</option>'+AP.all('brands').map(b=>'<option value="'+b.id+'"'+(sel===b.id?' selected':'')+'>'+E(b.name)+'</option>').join('');
const unitOpts=sel=>AP.all('units').map(b=>'<option'+(sel===b.name?' selected':'')+'>'+E(b.name)+'</option>').join('')||'<option>pcs</option>';
const genSku=()=>'AMN'+String(Date.now()).slice(-7)+String((Math.random()*90+10)|0);
const nameOf=(c,id)=>(AP.find(c,id)||{}).name||'';
const stockTag=p=>p.type==='service'?'<span class="muted">Service</span>':'<b class="'+((+p.stock||0)<=0?'bad':(+p.stock||0)<=(+p.min||AP.cfg().lowStock)?'warn':'')+'">'+AP.n(p.stock,0)+' '+E(p.unit||'pcs')+'</b>';

/* ----- label print ----- */
function printLabel(p){
  const fr=document.createElement('iframe');fr.style.cssText='position:fixed;width:0;height:0;border:0';document.body.appendChild(fr);
  const bars=String(p.sku).split('').map((c,i)=>'<i style="display:inline-block;height:34px;background:#000;width:'+(1+(c.charCodeAt(0)+i)%3)+'px;margin-right:'+(1+(c.charCodeAt(0)*3+i)%2)+'px"></i>').join('');
  fr.contentDocument.open();fr.contentDocument.write('<meta charset=utf-8><style>body{margin:0;font:10px system-ui,Arial;width:50mm;padding:2mm;text-align:center}b{font-size:13px}</style><div>'+E(p.name).slice(0,34)+'</div><div>'+bars+'</div><div style="font-family:monospace">'+E(p.sku)+'</div><b>'+M(p.price)+'</b>');fr.contentDocument.close();
  setTimeout(()=>{fr.contentWindow.print();setTimeout(()=>fr.remove(),3000)},200);
}
AP.printLabel=printLabel;

/* ----- PRODUCTS LIST ----- */
function adjust(p){
  const m=AP.modal({title:'Adjust stock',sub:E(p.name)+' · now '+p.stock+' '+E(p.unit||''),size:'sm',body:'<div class="fld"><label class="req">New counted quantity</label><input class="inp" type="number" min="0" id="aq" value="'+(p.stock||0)+'"></div><div class="fld" style="margin-top:10px"><label>Reason</label><select class="sel" id="ar"><option>Stock count correction</option><option>Damaged</option><option>Expired</option><option>Lost / theft</option><option>Gift / sample</option></select></div>',foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:mm=>{const q=+$('#aq',m.el).value;if(q<0||isNaN(q))return;const diff=q-(+p.stock||0);p.stock=q;AP.put('products',p);AP.put('adjusts',{id:AP.uid(),t:Date.now(),pid:p.id,name:p.name,diff,reason:$('#ar',m.el).value,by:AP.me().name});mm.close();AP.toast('Stock updated ('+(diff>0?'+':'')+diff+')');AP.refresh()}}]});
}
P.products=function(v){
  AP.list(v,{title:'Products',unit:'products',info:'Everything you sell. Low stock shows in amber, out of stock in red.',
    rows:()=>AP.all('products'),search:r=>r.name+' '+r.sku+' '+(r.mfr||''),
    sort:f=>({new:(a,b)=>(b.t||0)-(a.t||0),name:(a,b)=>a.name.localeCompare(b.name),low:(a,b)=>(+a.stock||0)-(+b.stock||0),price:(a,b)=>b.price-a.price}[f.sort||'new']),
    actions:p=>{p.innerHTML='<button class="btn ghost" id="x"><i class="fa-solid fa-file-csv"></i> CSV</button><button class="btn ghost" id="i"><i class="fa-solid fa-arrow-up-from-bracket"></i> Import</button><a class="btn" href="#/products/new">+ Add product</a>';
      $('#x',p).onclick=()=>AP.csv('products.csv',[['SKU','Name','Category','Brand','Unit','Cost','Price','Stock','Expiry']].concat(AP.all('products').map(r=>[r.sku,r.name,AP.catName(r.cat),nameOf('brands',r.brand),r.unit,r.cost,r.price,r.stock,r.expiry||''])));
      $('#i',p).onclick=()=>{const inp=document.createElement('input');inp.type='file';inp.accept='.csv';inp.onchange=()=>{const rd=new FileReader();rd.onload=()=>{let n=0;String(rd.result).replace(/^﻿/,'').split(/\r?\n/).filter(Boolean).forEach((ln,i)=>{const c=ln.split(',').map(x=>x.replace(/^"|"$/g,'').trim());if(i===0&&/sku|name/i.test(c[0]+c[1]))return;if(!c[1]||isNaN(+c[6]))return;AP.put('products',{id:AP.uid(),sku:c[0]||genSku(),name:c[1],cat:'',brand:'',unit:c[4]||'pcs',cost:+c[5]||0,price:+c[6],stock:+c[7]||0,min:5,expiry:c[8]||'',tax:0,type:'stock',on:true,t:Date.now()});n++});AP.toast(n+' products imported');AP.refresh()};rd.readAsText(inp.files[0])};inp.click()}},
    filters:[{k:'q',type:'text',ph:'Name, product code or SKU',grow:1},
      {k:'st',label:'Status',def:'on',opts:()=>[['on','Active'],['off','Inactive'],['all','All']],test:(r,v)=>v==='all'||(v==='on'?r.on!==false:r.on===false)},
      {k:'ty',label:'Type',opts:()=>[['','All'],['stock','Stock item'],['service','Service']],test:(r,v)=>(r.type||'stock')===v},
      {k:'cat',label:'Category',opts:()=>[['','All categories']].concat(AP.all('categories').map(c=>[c.id,AP.catName(c.id)])),test:(r,v)=>r.cat===v||(AP.find('categories',r.cat)||{}).parent===v},
      {k:'br',label:'Brand',opts:()=>[['','All brands']].concat(AP.all('brands').map(b=>[b.id,b.name])),test:(r,v)=>r.brand===v},
      {k:'sort',label:'Sort',opts:()=>[['new','Newest first'],['name','Name A–Z'],['low','Lowest stock'],['price','Highest price']]}],
    cols:[{h:'SL',f:(r,i)=>'<span class="muted">'+(i+1)+'</span>'},{h:'SKU',f:r=>'<span class="mono tag">'+E(r.sku)+'</span>'},{h:'Product',f:r=>'<a href="#/products/edit/'+r.id+'" class="b">'+E(r.name)+'</a>'+(r.expiry&&+new Date(r.expiry)<Date.now()+30*864e5?' <span class="tag warn">exp '+E(r.expiry)+'</span>':'')},{h:'Category',f:r=>'<span class="muted">'+E(AP.catName(r.cat)||'—')+'</span>'},{h:'Brand',f:r=>E(nameOf('brands',r.brand)||'—')},{h:'Price',cls:'r num',f:r=>M(r.price)},{h:'Stock',cls:'r',f:r=>stockTag(r)},
      {h:'Actions',cls:'r',f:r=>'<a class="btn sm ghost" href="#/products/edit/'+r.id+'"><i class="fa-solid fa-pen"></i> Edit</a> <button class="ib" data-m="'+r.id+'" aria-label="More"><i class="fa-solid fa-ellipsis"></i></button>'}],
    empty:{icon:'<i class="fa-solid fa-box"></i>',title:'No products yet',text:'Add your first product to start selling.',btn:'+ Add product',fn:()=>location.hash='#/products/new'},
    after:tw=>$$('[data-m]',tw).forEach(b=>b.onclick=()=>{const p=AP.find('products',b.dataset.m);AP.pop(b,'<button data-a="dup"><i class="fa-solid fa-copy"></i> Duplicate</button><button data-a="adj"><i class="fa-solid fa-scale-balanced"></i> Adjust stock</button><button data-a="lbl"><i class="fa-solid fa-tags"></i> Print label</button><button data-a="tg">'+(p.on===false?'✓ Activate':'<i class="fa-solid fa-pause"></i> Deactivate')+'</button><hr><button data-a="del" style="color:var(--bad)"><i class="fa-solid fa-trash"></i> Delete</button>',async a=>{
      if(a==='dup'){const q=Object.assign({},p,{id:AP.uid(),sku:genSku(),name:p.name+' (copy)',stock:0,t:Date.now()});AP.put('products',q);AP.toast('Duplicated');location.hash='#/products/edit/'+q.id}
      else if(a==='adj')adjust(p);else if(a==='lbl')printLabel(p);
      else if(a==='tg'){p.on=p.on===false;AP.put('products',p);AP.refresh()}
      else if(a==='del'&&await AP.confirm('Delete <b>'+E(p.name)+'</b>? Past invoices keep their history.','Delete',true)){AP.del('products',p.id);AP.refresh()}})})});
};

/* ----- PRODUCT WIZARD ----- */
P.productForm=function(v,id){
  const editing=id?AP.find('products',id):null;
  if(id&&!editing){v.innerHTML='<div class="card pad">Product not found.</div>';return}
  const KEY='draft_product';
  let d=editing?Object.assign({vars:'',track:!!editing.expiry,buyUnit:editing.unit,conv:1},editing):Object.assign({type:'stock',name:'',brand:'',cat:'',mode:'one',vars:'',sku:'',mfr:'',desc:'',unit:'pcs',buyUnit:'pcs',conv:1,min:5,cost:'',price:'',tax:0,stock:'',expiry:'',track:false,on:true},AP.get(KEY,{}));
  let step=1;const err={};
  const unlocked=!editing;
  const draw=()=>{
    const st=['Product','Units','Prices','Review'];
    v.innerHTML='<div class="muted" style="margin-bottom:6px"><a href="#/products">Products</a> › '+(editing?'Edit product':'Add product')+'</div><div class="ph"><h1>'+(editing?'Edit product':'Add product')+'</h1></div>'
    +'<div class="card steps">'+st.map((s,i)=>'<span class="st '+(step===i+1?'on':step>i+1?'done':'')+'"><b>'+(step>i+1?'✓':i+1)+'</b>'+s+'</span>'+(i<3?'<span class="ln"></span>':'')).join('')+'</div>'
    +'<div class="wiz"><div class="card"><div class="pad" style="padding:20px" id="sb"></div><div class="row" style="padding:14px 20px;border-top:1px solid var(--line);background:var(--bg);border-radius:0 0 12px 12px"><a href="#/products" class="btn ghost">Cancel</a><span class="sp"></span><span class="muted">Step '+step+' of 4</span>'+(step>1?'<button class="btn ghost" id="bk">← Back</button>':'')+'<button class="btn" id="nx">'+(step===4?(editing?'Save changes':'Save product'):'Next →')+'</button></div></div>'
    +'<div class="card pad stk"><h3>Summary</h3>'+sumHTML()+(unlocked?'<p class="muted" style="font-size:12px;margin:10px 0 0">Draft kept on this device until you save.</p>':'')+'</div></div>';
    body();$('#nx',v).onclick=next;const b=$('#bk',v);if(b)b.onclick=()=>{collect();step--;draw()};
  };
  const sumHTML=()=>[['Name',d.name||'—'],['Type',d.type==='service'?'Service':'Stock item'],['Category',AP.catName(d.cat)||'—'],['Sold by',d.unit||'—'],['Bought by',d.buyUnit&&d.buyUnit!==d.unit?d.buyUnit+' = '+d.conv+' '+d.unit:d.unit||'—'],['Tax',(d.tax||0)+'%'],['Selling price',d.price!==''&&d.price!=null?M(d.price):'—']].map(r=>'<div class="sumrow"><span>'+r[0]+'</span><b>'+E(r[1])+'</b></div>').join('');
  const fld=(k,label,inner,hint)=>'<div class="fld'+(err[k]?' err':'')+'"><label'+(label.endsWith('*')?' class="req"':'')+'>'+label.replace(/ \*$/,'')+'</label>'+inner+(err[k]?'<div class="hint bad">'+err[k]+'</div>':hint?'<div class="hint">'+hint+'</div>':'')+'</div>';
  const body=()=>{
    const sb=$('#sb',v);
    if(step===1)sb.innerHTML='<h3>Product</h3><div class="lbl" style="margin-bottom:6px">Type</div><div class="grid g2" id="ty"><div class="opt '+(d.type!=='service'?'on':'')+'" data-t="stock"><span><i class="fa-solid fa-box"></i></span><div><b>Stock item</b><small>Kept in stock</small></div></div><div class="opt '+(d.type==='service'?'on':'')+'" data-t="service"><span><i class="fa-solid fa-screwdriver-wrench"></i></span><div><b>Service</b><small>No stock, e.g. repair</small></div></div></div>'+(unlocked?'<div class="lock" style="margin:6px 0 14px"><i class="fa-solid fa-lock"></i> Can\'t be changed later</div>':'<div style="height:14px"></div>')
      +'<div class="grid g2">'+fld('name','Name *','<input class="inp" id="pn" value="'+E(d.name)+'">')+fld('brand','Brand','<select class="sel" id="pb">'+brandOpts(d.brand)+'</select>')+fld('cat','Category','<select class="sel" id="pc">'+catOpts(d.cat,'No category')+'</select>','Add categories in Product setup')+'</div>'
      +(unlocked?'<div class="lbl" style="margin:14px 0 6px">Versions</div><div class="grid g2" id="vm"><div class="opt '+(d.mode!=='var'?'on':'')+'" data-m="one"><span><i class="fa-solid fa-square"></i></span><div><b>One version</b></div></div><div class="opt '+(d.mode==='var'?'on':'')+'" data-m="var"><span><i class="fa-solid fa-table-cells-large"></i></span><div><b>Sizes, colours or styles</b></div></div></div>'+(d.mode==='var'?'<div class="fld" style="margin-top:10px"><label>Versions (comma separated)</label><input class="inp" id="pv" value="'+E(d.vars)+'" placeholder="S, M, L, XL"><div class="hint">One product per version will be created, e.g. “T-shirt — M”.</div></div>':''):'')
      +'<div class="card" style="margin-top:16px"><div class="row" style="padding:12px 16px;cursor:pointer" id="cdh"><b class="sp">Codes and description</b><span class="muted">Product code: '+(d.sku?E(d.sku):'automatic')+'</span></div><div id="cdb" class="'+(d.cdOpen||d.mfr||d.desc?'':'hide')+'" style="padding:0 16px 16px"><div class="grid g2"><div class="fld"><label>Product Code</label><input class="inp mono" id="ps" value="'+E(d.sku||'')+'" placeholder="Automatic"></div><div class="fld"><label>Manufacturer Code (barcode)</label><input class="inp mono" id="pm" value="'+E(d.mfr||'')+'" placeholder="Scan or type"></div></div><div class="fld" style="margin-top:10px"><label>Description</label><textarea class="inp" id="pd" rows="3">'+E(d.desc||'')+'</textarea></div></div></div>';
    if(step===2)sb.innerHTML='<h3>Units</h3><div class="grid g2">'+fld('unit','Sold by *','<select class="sel" id="pu">'+unitOpts(d.unit)+'</select>')+fld('buy','Bought by','<select class="sel" id="pbu">'+unitOpts(d.buyUnit||d.unit)+'</select>','If you buy in boxes but sell by piece, set the box size')+'<div class="fld '+((d.buyUnit||d.unit)===d.unit?'hide':'')+'" id="cvw"><label>1 '+E(d.buyUnit)+' = how many '+E(d.unit)+'?</label><input class="inp" type="number" min="1" id="pcv" value="'+(d.conv||1)+'"></div>'+(d.type!=='service'?fld('min','Low-stock alert at','<input class="inp" type="number" min="0" id="pmin" value="'+(d.min??5)+'">','Amber warning when stock falls to this'):'')+'</div><button class="btn ghost sm" id="nu" style="margin-top:12px">+ New unit</button>';
    if(step===3)sb.innerHTML='<h3>Prices</h3><div class="grid g2">'+fld('cost','Cost price (৳)','<input class="inp" type="number" min="0" step="0.01" id="pco" value="'+E(d.cost)+'">','What you pay per '+E(d.unit))+fld('price','Selling price (৳) *','<input class="inp" type="number" min="0" step="0.01" id="ppr" value="'+E(d.price)+'">')+fld('wprice','Wholesale price (৳)','<input class="inp" type="number" min="0" step="0.01" id="pwp" value="'+E(d.wprice||'')+'">','Used for customers in the Wholesale category')+'<div class="fld"><label>Quick-sale tile</label><label class="row" style="gap:8px;padding-top:8px"><input type="checkbox" id="pfv"'+(d.fav?' checked':'')+'> Show as favorite on POS</label></div>'+fld('tax','Tax / VAT %','<input class="inp" type="number" min="0" max="100" id="ptx" value="'+(d.tax||0)+'">')+'<div class="fld"><label>Margin</label><div class="inp" id="mg" style="display:flex;align-items:center;background:var(--bg)">—</div></div>'
      +(d.type!=='service'?(editing?'<div class="fld"><label>Current stock</label><div class="inp" style="display:flex;align-items:center;background:var(--bg)">'+(d.stock||0)+' '+E(d.unit)+'</div><div class="hint">Change stock with Stock in or Adjust stock</div></div>':fld('stock','Opening stock','<input class="inp" type="number" min="0" id="pst" value="'+E(d.stock)+'">','How many you have now'))+'<div class="fld"><label class="chk"><input type="checkbox" id="ptr" '+(d.track?'checked':'')+'> Track expiry date</label><input class="inp '+(d.track?'':'hide')+'" type="date" id="pex" value="'+E(d.expiry||'')+'" style="margin-top:6px"></div>':'')+'</div>';
    if(step===4)sb.innerHTML='<h3>Review</h3><div class="card">'+[['Name',d.name],['Type',d.type==='service'?'Service':'Stock item'],['Category',AP.catName(d.cat)||'—'],['Brand',nameOf('brands',d.brand)||'—'],['Versions',d.mode==='var'&&unlocked?(d.vars||'—'):'One'],['Sold by',d.unit],['Cost',M(d.cost||0)],['Selling price',M(d.price||0)],['Tax',(d.tax||0)+'%'],['Opening stock',d.type==='service'?'—':(editing?d.stock:(d.stock||0))+' '+d.unit],['Expiry',d.track&&d.expiry?d.expiry:'—']].map(r=>'<div class="sumrow" style="padding:10px 16px"><span>'+r[0]+'</span><b>'+E(r[1])+'</b></div>').join('')+'</div><label class="chk" style="margin-top:12px"><input type="checkbox" id="pon" '+(d.on!==false?'checked':'')+'> Active — can be sold at POS</label>'+(unlocked?'<label class="chk" style="margin-top:8px"><input type="checkbox" id="pan"> Save and add another</label>':'');
    wire();
  };
  const wire=()=>{
    $$('#ty .opt',v).forEach(o=>o.onclick=()=>{if(!unlocked)return;collect();d.type=o.dataset.t;draw()});
    $$('#vm .opt',v).forEach(o=>o.onclick=()=>{collect();d.mode=o.dataset.m;draw()});
    const h=$('#cdh',v);if(h)h.onclick=()=>{$('#cdb',v).classList.toggle('hide')};
    if(step===2){const sync=()=>{collect();$('#cvw',v).classList.toggle('hide',d.buyUnit===d.unit);$('#cvw label',v).textContent='1 '+d.buyUnit+' = how many '+d.unit+'?'};$('#pu',v).onchange=sync;$('#pbu',v).onchange=sync;
      $('#nu',v).onclick=()=>{const m=AP.modal({title:'New unit',size:'sm',body:'<div class="fld"><label>Unit name</label><input class="inp" id="un" placeholder="e.g. dozen"></div>',foot:[{label:'Cancel'},{label:'Add',cls:'pri',fn:mm=>{const n=$('#un',m.el).value.trim();if(!n)return;if(!AP.all('units').some(u=>u.name.toLowerCase()===n.toLowerCase()))AP.put('units',{id:AP.uid(),name:n,on:true});mm.close();collect();draw()}}]})}}
    if(step===3){const mg=()=>{const c=+$('#pco',v).value,p=+$('#ppr',v).value;$('#mg',v).innerHTML=p>0?'<b class="'+(p<c?'bad':'ok')+'">'+AP.n(p-c)+' ('+(c?AP.n((p-c)/c*100,0)+'% markup':'—')+')</b>':'—'};$('#pco',v).oninput=mg;$('#ppr',v).oninput=mg;mg();const t=$('#ptr',v);if(t)t.onchange=()=>$('#pex',v).classList.toggle('hide',!t.checked)}
    $$('input,select,textarea',v).forEach(i=>i.addEventListener('change',()=>{collect();const s=$('.stk',v);if(s)s.innerHTML='<h3>Summary</h3>'+sumHTML()+(unlocked?'<p class="muted" style="font-size:12px;margin:10px 0 0">Draft kept on this device until you save.</p>':'')}));
  };
  const collect=()=>{
    const g=(i)=>{const e=$(i,v);return e?e.value:undefined};
    if(step===1){d.name=g('#pn').trim();d.brand=g('#pb');d.cat=g('#pc');const pv=g('#pv');if(pv!==undefined)d.vars=pv;const ps=g('#ps');if(ps!==undefined){d.sku=ps.trim();d.mfr=g('#pm').trim();d.desc=g('#pd').trim()}}
    if(step===2){d.unit=g('#pu');d.buyUnit=g('#pbu');d.conv=Math.max(1,+g('#pcv')||1);const m=g('#pmin');if(m!==undefined)d.min=+m}
    if(step===3){d.cost=g('#pco');d.price=g('#ppr');d.wprice=g('#pwp');d.fav=!!($('#pfv',v)&&$('#pfv',v).checked);d.tax=+g('#ptx')||0;const s=g('#pst');if(s!==undefined)d.stock=s;const t=$('#ptr',v);if(t){d.track=t.checked;d.expiry=t.checked?g('#pex'):''}}
    if(step===4){const o=$('#pon',v);if(o)d.on=o.checked}
    if(unlocked){try{AP.set(KEY,d)}catch(e){}}
  };
  const validate=()=>{Object.keys(err).forEach(k=>delete err[k]);
    if(step===1){if(!d.name)err.name='Enter the product name';else if(d.name.length<2)err.name='Name is too short';if(d.mode==='var'&&unlocked&&!d.vars.split(',').some(x=>x.trim()))err.name=err.name||'Enter at least one version'}
    if(step===3){if(d.price===''||isNaN(+d.price)||+d.price<0)err.price='Enter the selling price';if(d.cost!==''&&+d.cost<0)err.cost='Cost cannot be negative'}
    return !Object.keys(err).length};
  const next=()=>{collect();if(!validate()){draw();const e=$('.fld.err .inp,.fld.err .sel',v);if(e)e.focus();return}
    if(step<4){step++;draw();return}
    const base={type:d.type,cat:d.cat,brand:d.brand,unit:d.unit,buyUnit:d.buyUnit,conv:d.conv,min:+d.min||0,cost:+d.cost||0,price:+d.price,wprice:+d.wprice||0,fav:!!d.fav,tax:+d.tax||0,expiry:d.track?d.expiry:'',desc:d.desc,mfr:d.mfr,on:d.on!==false};
    if(editing){AP.put('products',Object.assign({},editing,base,{name:d.name,sku:d.sku||editing.sku}));AP.toast('Product saved');location.hash='#/products';return}
    const dupe=AP.all('products').some(p=>p.sku===d.sku&&d.sku);if(dupe){AP.toast('Product code already used','bad');step=1;draw();return}
    const names=d.mode==='var'?d.vars.split(',').map(x=>x.trim()).filter(Boolean).map(x=>d.name+' — '+x):[d.name];
    names.forEach((n,i)=>AP.put('products',Object.assign({id:AP.uid(),t:Date.now()+i},base,{name:n,sku:(i===0&&d.sku)||genSku(),stock:d.type==='service'?0:(+d.stock||0)})));
    const another=$('#pan',v)&&$('#pan',v).checked;try{localStorage.removeItem('amnpos:'+KEY)}catch(e){}
    AP.toast(names.length>1?names.length+' products added':'Product added');
    if(another){d={type:'stock',name:'',brand:d.brand,cat:d.cat,mode:'one',vars:'',sku:'',mfr:'',desc:'',unit:d.unit,buyUnit:d.unit,conv:1,min:5,cost:'',price:'',tax:0,stock:'',expiry:'',track:false,on:true};step=1;draw()}else location.hash='#/products';
  };
  draw();
};

/* ----- CATALOG ----- */
P.catalog=function(v,tab){
  tab=tab||'categories';
  const T=[['categories','Categories','<i class="fa-solid fa-folder-open"></i>'],['brands','Brands','<i class="fa-solid fa-tags"></i>'],['units','Units','<i class="fa-solid fa-scale-balanced"></i>'],['attrs','Attributes','<i class="fa-solid fa-palette"></i>']];
  const simple=(col,label,withFn)=>{
    const rows=AP.all(col);
    const uses=r=>col==='brands'?AP.all('products').filter(p=>p.brand===r.id).length:AP.all('products').filter(p=>p.unit===r.name).length;
    return'<div class="card"><div class="row" style="padding:14px 16px;border-bottom:1px solid var(--line)"><b class="sp">'+label+' ('+rows.length+')</b><button class="btn sm" id="add">+ Add</button></div>'+(rows.length?'<table class="t"><tbody>'+rows.map(r=>'<tr><td class="b">'+E(r.name)+'</td><td class="muted">'+uses(r)+' products</td><td class="r"><button class="btn sm ghost" data-e="'+r.id+'">Edit</button> <button class="btn sm danger" data-d="'+r.id+'">Delete</button></td></tr>').join('')+'</tbody></table>':'<div class="empty"><p>None yet.</p></div>')+'</div>';
  };
  const draw=()=>{
    v.innerHTML='<div class="muted" style="margin-bottom:6px">Product setup › '+T.find(t=>t[0]===tab)[1]+'</div><div class="ph"><h1>'+T.find(t=>t[0]===tab)[1]+'</h1></div><div class="grid" style="grid-template-columns:220px 1fr;align-items:start" id="cg"><div class="card pad" style="padding:8px">'+T.map(t=>'<a href="#/catalog/'+t[0]+'" class="row" style="padding:10px 12px;border-radius:10px;color:var(--ink);font-weight:600;text-decoration:none;'+(t[0]===tab?'background:var(--ink);color:var(--bg)':'')+'"><span>'+t[2]+'</span>'+t[1]+'</a>').join('')+'</div><div id="cc"></div></div>';
    if(innerWidth<900)$('#cg',v).style.gridTemplateColumns='1fr';
    const cc=$('#cc',v);
    const nameForm=(col,o)=>{o=o||{};const m=AP.modal({title:(o.id?'Edit ':'Add ')+(col==='brands'?'brand':'unit'),size:'sm',body:'<div class="fld"><label class="req">Name</label><input class="inp" id="nm" value="'+E(o.name||'')+'"></div>',foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:mm=>{const n=$('#nm',m.el).value.trim();if(!n)return;if(AP.all(col).some(x=>x.name.toLowerCase()===n.toLowerCase()&&x.id!==o.id)){AP.toast('Already exists','bad');return}AP.put(col,Object.assign({on:true},o,{name:n}));mm.close();draw()}}]});$('#nm',m.el).onkeydown=e=>{if(e.key==='Enter')$('.btn.pri',m.el).click()}};
    if(tab==='brands'||tab==='units'){
      cc.innerHTML=simple(tab,tab==='brands'?'Brands':'Units');$('#add',cc).onclick=()=>nameForm(tab);
      $$('[data-e]',cc).forEach(b=>b.onclick=()=>nameForm(tab,AP.find(tab,b.dataset.e)));
      $$('[data-d]',cc).forEach(b=>b.onclick=async()=>{const r=AP.find(tab,b.dataset.d);if(await AP.confirm('Delete <b>'+E(r.name)+'</b>?','Delete',true)){AP.del(tab,r.id);draw()}});
    }
    if(tab==='categories'){
      const C=AP.all('categories'),top=C.filter(c=>!c.parent).sort((a,b)=>a.name.localeCompare(b.name));
      const cnt=id=>AP.all('products').filter(p=>p.cat===id||(AP.find('categories',p.cat)||{}).parent===id).length;
      const row=(c,lab,sub)=>'<tr><td style="'+(sub?'padding-left:36px':'')+'">'+(sub?'<span class="muted">↳ </span>':'')+'<b>'+(sub?'':'')+E(c.name)+'</b></td><td class="muted">'+(sub?'Subcategory':'Category')+'</td><td class="num">'+cnt(c.id)+'</td><td><button class="sw '+(c.on!==false?'on':'')+'" data-t="'+c.id+'" aria-label="Active"></button></td><td class="r">'+(sub?'':'<button class="btn sm ghost" data-s="'+c.id+'">+ Sub</button> ')+'<button class="btn sm ghost" data-e="'+c.id+'">Edit</button> <button class="btn sm danger" data-d="'+c.id+'">Delete</button></td></tr>';
      cc.innerHTML='<div class="card"><div class="row" style="padding:14px 16px;border-bottom:1px solid var(--line)"><div class="srch sp"><input class="inp" id="cs" placeholder="Category name"></div><button class="btn" id="add">+ Add category</button></div>'+(top.length?'<div class="tw"><table class="t"><thead><tr><th>Name</th><th>Type</th><th>Products</th><th>Active</th><th class="r">Actions</th></tr></thead><tbody id="ct">'+top.map(c=>row(c)+C.filter(s=>s.parent===c.id).map(s=>row(s,'',1)).join('')).join('')+'</tbody></table></div>':'<div class="empty"><div class="ei"><i class="fa-solid fa-folder-open"></i></div><h4>No categories</h4><p>Group products so they are easy to find.</p></div>')+'</div>';
      const form=(o,parent)=>{o=o||{};const m=AP.modal({title:o.id?'Edit category':parent?'Add subcategory':'Add category',size:'sm',body:'<div class="fld"><label class="req">Name</label><input class="inp" id="nm" value="'+E(o.name||'')+'"></div>'+(parent||o.parent?'<div class="muted" style="margin-top:8px">Under: <b>'+E(nameOf('categories',parent||o.parent))+'</b></div>':''),foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:mm=>{const n=$('#nm',m.el).value.trim();if(!n)return;AP.put('categories',Object.assign({on:true},o,{name:n,parent:o.parent||parent||''}));mm.close();draw()}}]});$('#nm',m.el).onkeydown=e=>{if(e.key==='Enter')$('.btn.pri',m.el).click()}};
      $('#add',cc).onclick=()=>form();
      $('#cs',cc).oninput=e=>{const q=e.target.value.toLowerCase();$$('#ct tr',cc).forEach(r=>r.classList.toggle('hide',q&&!r.textContent.toLowerCase().includes(q)))};
      $$('[data-s]',cc).forEach(b=>b.onclick=()=>form(null,b.dataset.s));$$('[data-e]',cc).forEach(b=>b.onclick=()=>form(AP.find('categories',b.dataset.e)));
      $$('[data-t]',cc).forEach(b=>b.onclick=()=>{const c=AP.find('categories',b.dataset.t);c.on=c.on===false;AP.put('categories',c);b.classList.toggle('on',c.on)});
      $$('[data-d]',cc).forEach(b=>b.onclick=async()=>{const c=AP.find('categories',b.dataset.d);if(cnt(c.id)){AP.toast('Move its '+cnt(c.id)+' products first','bad');return}if(await AP.confirm('Delete <b>'+E(c.name)+'</b>?','Delete',true)){AP.all('categories').filter(s=>s.parent===c.id).forEach(s=>AP.del('categories',s.id));AP.del('categories',c.id);draw()}});
    }
    if(tab==='attrs'){
      const A=AP.all('attrs');
      cc.innerHTML='<div class="card"><div class="row" style="padding:14px 16px;border-bottom:1px solid var(--line)"><b class="sp">Attributes ('+A.length+')</b><button class="btn sm" id="add">+ Add</button></div>'+(A.length?'<table class="t"><tbody>'+A.map(a=>'<tr><td class="b">'+E(a.name)+'</td><td>'+a.values.map(x=>'<span class="tag">'+E(x)+'</span>').join(' ')+'</td><td class="r"><button class="btn sm ghost" data-e="'+a.id+'">Edit</button> <button class="btn sm danger" data-d="'+a.id+'">Delete</button></td></tr>').join('')+'</tbody></table>':'<div class="empty"><p>Attributes like Size or Colour help when you add product versions.</p></div>')+'</div>';
      const form=(o)=>{o=o||{};const m=AP.modal({title:o.id?'Edit attribute':'Add attribute',size:'sm',body:'<div class="fld"><label class="req">Name</label><input class="inp" id="an" value="'+E(o.name||'')+'" placeholder="Size"></div><div class="fld" style="margin-top:10px"><label>Values (comma separated)</label><input class="inp" id="av" value="'+E((o.values||[]).join(', '))+'" placeholder="S, M, L"></div>',foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:mm=>{const n=$('#an',m.el).value.trim();if(!n)return;AP.put('attrs',Object.assign({},o,{name:n,values:$('#av',m.el).value.split(',').map(x=>x.trim()).filter(Boolean)}));mm.close();draw()}}]})};
      $('#add',cc).onclick=()=>form();$$('[data-e]',cc).forEach(b=>b.onclick=()=>form(AP.find('attrs',b.dataset.e)));$$('[data-d]',cc).forEach(b=>b.onclick=()=>{AP.del('attrs',b.dataset.d);draw()});
    }
  };
  draw();
};

/* ----- STOCK IN ----- */
P.stockin=function(v){
  const KEY='draft_stockin';
  const blank=()=>({supplier:'',ref:'',lines:[],paid:'',bt:'p',bv:'',spread:'value',extra:'',pay:'cash'});
  let d=Object.assign(blank(),AP.get(KEY,{}));
  if(AP.q.get('low')){d.lines=AP.alerts().low.map(p=>({pid:p.id,qty:Math.max(1,(+p.min||5)*3-(+p.stock||0)),cost:p.cost,dv:'',dt:'p',sell:p.price,exp:''}));AP.set(KEY,d);AP.q.delete('low')}
  const save=()=>{AP.set(KEY,d);const s=$('#ds',v);if(s)s.innerHTML='<i class="fa-solid fa-check"></i> Draft saved '+new Date().toTimeString().slice(0,5)};
  const R=x=>Math.round(x*100)/100;
  const gross=l=>(+l.qty||0)*(+l.cost||0);
  const ldisc=l=>{const g=gross(l),v=+l.dv||0;return Math.min(g,l.dt==='v'?v:g*v/100)};
  const net=l=>gross(l)-ldisc(l);
  /* compute everything: returns per-line real total + bill figures */
  const calc=()=>{
    const sub=d.lines.reduce((s,l)=>s+net(l),0);const qty=d.lines.reduce((s,l)=>s+(+l.qty||0),0);
    let bd=0;const bv=+d.bv||0;
    if(d.bt==='p')bd=sub*bv/100;else if(d.bt==='v')bd=bv;else if(d.bt==='f'&&d.bv!=='')bd=sub-bv;
    bd=Math.max(0,Math.min(sub,bd));const ex=Math.max(0,+d.extra||0);
    const per=l=>{const w=d.spread==='qty'?(qty?(+l.qty||0)/qty:0):(sub?net(l)/sub:0);return w};
    const rows=d.lines.map(l=>{const w=per(l);const tot=net(l)-bd*w+ex*w;const q=+l.qty||0;return{tot:R(tot),real:q?tot/q:0,bd:bd*w}});
    const payable=R(sub-bd+ex);
    return{sub,bd,ex,payable,rows,qty,ld:d.lines.reduce((s,l)=>s+ldisc(l),0)};
  };
  const draw=()=>{
    const S=AP.all('suppliers');
    v.innerHTML='<div class="ph"><h1>Stock in</h1><span class="muted mono" id="ds"></span><a class="btn ghost" href="#/stockins"><i class="fa-solid fa-clock-rotate-left"></i> History</a><button class="btn ghost" id="dc">Discard</button><button class="btn" id="po"><i class="fa-solid fa-check"></i> Post stock in <span class="kbd">Ctrl ⏎</span></button></div>'
    +'<div class="card pad" style="margin-bottom:14px"><div class="grid" style="grid-template-columns:1fr 1fr 1.4fr"><div class="fld"><label>Supplier</label><div class="row"><select class="sel" id="su"><option value="">No supplier</option>'+S.map(s=>'<option value="'+s.id+'"'+(d.supplier===s.id?' selected':'')+'>'+E(s.name)+'</option>').join('')+'</select><button class="ib" id="ns" title="New supplier"><i class="fa-solid fa-plus"></i></button></div></div><div class="fld"><label>Invoice / challan no.</label><input class="inp" id="rf" value="'+E(d.ref)+'" placeholder="Optional"></div><div class="fld"><label>Tip</label><div class="muted" style="font-size:12.5px;padding-top:8px">Type the <b>Line total</b> from the supplier bill — unit cost is worked out for you (total ÷ qty).</div></div></div></div>'
    +'<div class="card"><div class="tw"><table class="t gridtbl"><thead><tr><th>#</th><th>Item</th><th>Qty</th><th>Unit cost</th><th>Line total</th><th>Discount</th><th>Real cost</th><th>Selling</th><th>Margin</th><th>Expiry</th><th></th></tr></thead><tbody id="tb"></tbody></table></div><div class="row" style="padding:10px 14px;border-top:1px solid var(--line)"><span class="muted" id="ln"></span></div></div>'
    +'<div class="grid g2" style="margin-top:14px;align-items:start"><div class="card pad"><h3 style="margin:0 0 4px">Whole-bill discount</h3><p class="muted" style="font-size:12.5px;margin:0 0 10px">Spread over every line so the real cost of each item drops. Example: bill ৳5000, you paid ৳4500 → choose “Final payable” and enter 4500.</p>'
    +'<div class="row" style="gap:6px;flex-wrap:wrap"><div class="seg" id="bt"><button data-t="p">%</button><button data-t="v">৳ Amount</button><button data-t="f">Final payable</button></div><input class="inp" id="bv" type="number" min="0" step="any" style="width:130px" value="'+E(d.bv)+'"></div>'
    +'<div class="row" style="margin-top:10px;gap:10px;flex-wrap:wrap"><span class="muted">Spread</span><div class="seg" id="sp"><button data-t="value">By value</button><button data-t="qty">Equal per unit</button></div></div>'
    +'<div class="fld" style="margin-top:12px"><label>Extra cost (transport / loading) — added to cost</label><input class="inp" id="ex" type="number" min="0" step="any" value="'+E(d.extra)+'" style="max-width:160px"></div><div id="wn" style="margin-top:8px"></div></div>'
    +'<div class="card pad"><div class="sumrow"><span>Items subtotal</span><b id="st"></b></div><div class="sumrow"><span>Line discounts</span><b id="ld"></b></div><div class="sumrow"><span>Bill discount</span><b id="bd"></b></div><div class="sumrow"><span>Extra cost</span><b id="xc"></b></div><div class="sumrow"><span><b>Payable / stock value</b></span><b style="font-size:20px" id="sv"></b></div>'
    +'<div class="fld" style="margin:8px 0"><label>Paid now (৳)</label><input class="inp" type="number" min="0" step="any" id="pd" value="'+E(d.paid)+'" placeholder="Blank = paid in full"></div><div class="row"><span class="muted sp">Pay from</span><div class="seg" id="py"><button data-t="cash">Counter cash</button><button data-t="other">Bank / other</button></div></div><div class="sumrow" style="margin-top:8px"><span id="ow"></span><b class="warn" id="ob"></b></div></div></div>';
    rows();
    const seg=(id,key)=>{const el=$(id,v);const mark=()=>$$('button',el).forEach(b=>b.classList.toggle('on',b.dataset.t===d[key]));mark();$$('button',el).forEach(b=>b.onclick=()=>{d[key]=b.dataset.t;mark();save();sums()})};
    seg('#bt','bt');seg('#sp','spread');seg('#py','pay');
    $('#bv',v).oninput=e=>{d.bv=e.target.value;save();sums()};$('#ex',v).oninput=e=>{d.extra=e.target.value;save();sums()};
    $('#su',v).onchange=e=>{d.supplier=e.target.value;save()};$('#rf',v).oninput=e=>{d.ref=e.target.value;save()};
    $('#pd',v).oninput=e=>{d.paid=e.target.value;save();sums()};
    $('#ns',v).onclick=()=>{const m=AP.modal({title:'New supplier',size:'sm',body:'<div class="fld"><label class="req">Name</label><input class="inp" id="sn"></div><div class="fld" style="margin-top:10px"><label>Mobile</label><input class="inp" id="sp2"></div>',foot:[{label:'Cancel'},{label:'Add',cls:'pri',fn:mm=>{const n=$('#sn',m.el).value.trim();if(!n)return;d.supplier=AP.put('suppliers',{id:AP.uid(),name:n,phone:$('#sp2',m.el).value.trim(),due:0}).id;save();draw()}}]})};
    $('#dc',v).onclick=async()=>{if(!d.lines.length||await AP.confirm('Discard this stock-in draft?','Discard',true)){d=blank();AP.set(KEY,d);draw();sums()}};
    $('#po',v).onclick=post;
  };
  const sums=()=>{
    const c=calc();const paid=d.paid===''?c.payable:Math.min(+d.paid||0,c.payable);const owe=Math.max(0,R(c.payable-paid));
    $('#st',v).textContent=M(c.sub);$('#ld',v).textContent='− '+M(c.ld);$('#bd',v).textContent='− '+M(c.bd);$('#xc',v).textContent='+ '+M(c.ex);$('#sv',v).textContent=M(c.payable);
    $('#ow',v).textContent=owe?'Owed to supplier':'Nothing is owed';$('#ob',v).textContent=owe?M(owe):'';
    $('#ln',v).textContent=d.lines.length+' line'+(d.lines.length===1?'':'s')+' · '+c.qty+' units';
    const warn=[];d.lines.forEach((l,i)=>{if(!(+l.qty>0))warn.push('Line '+(i+1)+': enter the quantity.');const r=c.rows[i];if(+l.sell&&r&&+l.sell<r.real)warn.push('Line '+(i+1)+': selling price is below cost.')});
    if(d.bt==='f'&&d.bv!==''&&+d.bv>c.sub)warn.push('Final payable is more than the subtotal — no discount applied.');
    $('#wn',v).innerHTML=warn.length?'<div class="warn" style="font-size:13px"><i class="fa-solid fa-triangle-exclamation"></i> '+warn.join('<br><i class="fa-solid fa-triangle-exclamation"></i> ')+'</div>':'<div class="muted" style="font-size:12.5px">Search an item below, <span class="kbd">Enter</span> adds. <span class="kbd">Tab</span> moves right.</div>';
    $$('tr[data-i]',v).forEach(tr=>{const i=+tr.dataset.i,l=d.lines[i],r=c.rows[i];$('.rc',tr).textContent=AP.n(r.real);const mg=+l.sell&&r.real?((+l.sell-r.real)/r.real*100):null;$('.mg',tr).textContent=mg==null?'—':AP.n(mg,0)+'%';$('.ds',tr).textContent=(ldisc(l)+r.bd)?'− '+AP.n(ldisc(l)+r.bd):''});
  };
  const rows=()=>{
    const tb=$('#tb',v);
    tb.innerHTML=d.lines.map((l,i)=>{const p=AP.find('products',l.pid)||{name:'(deleted)',sku:'',unit:''};return'<tr data-i="'+i+'"><td class="muted">'+(i+1)+'</td><td class="b">'+E(p.name)+'<div class="muted mono" style="font-size:11px;font-weight:400">'+E(p.sku)+' · '+E(p.unit)+'</div></td><td><input data-f="qty" type="number" min="0" step="any" value="'+E(l.qty)+'" style="width:70px"></td><td><input data-f="cost" type="number" min="0" step="any" value="'+E(l.cost)+'" style="width:90px"></td><td><input data-f="lt" type="number" min="0" step="any" value="'+(gross(l)?R(gross(l)):'')+'" placeholder="Total" style="width:100px;border-color:var(--mintd)"></td><td><div class="row" style="gap:4px"><input data-f="dv" type="number" min="0" step="any" value="'+E(l.dv)+'" style="width:64px"><button class="btn sm ghost" data-dt="'+i+'" style="min-width:34px">'+(l.dt==='v'?'৳':'%')+'</button></div><div class="muted ds" style="font-size:11px"></div></td><td class="num b rc"></td><td><input data-f="sell" type="number" min="0" step="any" value="'+E(l.sell)+'" style="width:90px"></td><td class="mg muted"></td><td><input data-f="exp" type="date" value="'+E(l.exp)+'" style="width:140px"></td><td><button class="ib" data-x="'+i+'" title="Remove"><i class="fa-solid fa-xmark"></i></button></td></tr>'}).join('')
    +'<tr><td class="muted">'+(d.lines.length+1)+'</td><td colspan="10" style="position:relative"><div class="row"><span><i class="fa-solid fa-barcode"></i></span><input id="sq" placeholder="Scan or type item name, code, SKU…  (F2)" autocomplete="off" style="border:1.5px solid var(--ink);border-radius:8px;max-width:420px"><span class="muted" style="font-size:12px">Enter adds · ↑↓ choose</span></div><div id="sg" class="hide" style="position:absolute;left:34px;top:48px;z-index:20;background:var(--card);border:1px solid var(--line);border-radius:10px;box-shadow:var(--sh2);min-width:420px"></div></td></tr>';
    $$('input[data-f]',tb).forEach(i=>i.oninput=()=>{const tr=i.closest('tr'),l=d.lines[+tr.dataset.i],f=i.dataset.f;
      if(f==='lt'){const q=+l.qty||0;if(q>0){l.cost=R((+i.value||0)/q*10000)/10000;$('[data-f=cost]',tr).value=l.cost}}
      else{l[f]=i.value;if(f==='qty'||f==='cost'){const g=gross(l);$('[data-f=lt]',tr).value=g?R(g):''}}
      save();sums()});
    $$('[data-dt]',tb).forEach(b=>b.onclick=()=>{const l=d.lines[+b.dataset.dt];l.dt=l.dt==='v'?'p':'v';b.textContent=l.dt==='v'?'৳':'%';save();sums()});
    $$('[data-x]',tb).forEach(b=>b.onclick=()=>{d.lines.splice(+b.dataset.x,1);save();rows();sums()});
    const q=$('#sq',tb),sg=$('#sg',tb);let hits=[],sel=0;
    const add=p=>{const ex=d.lines.find(l=>l.pid===p.id);if(ex)ex.qty=(+ex.qty||0)+1;else d.lines.push({pid:p.id,qty:'',cost:p.cost,dv:'',dt:'p',sell:p.price,exp:''});save();rows();sums();const nq=$$('input[data-f=qty]',$('#tb',v));const t=ex?nq[d.lines.indexOf(ex)]:nq[nq.length-1];if(t){t.focus();t.select()}};
    const show=()=>{const s=q.value.trim().toLowerCase();if(!s){sg.classList.add('hide');return}hits=AP.all('products').filter(p=>p.type!=='service'&&p.on!==false&&(p.name+' '+p.sku+' '+(p.mfr||'')).toLowerCase().includes(s)).slice(0,8);sel=Math.min(sel,Math.max(0,hits.length-1));sg.classList.remove('hide');sg.innerHTML=hits.map((p,k)=>'<div data-k="'+k+'" class="row" style="padding:9px 12px;cursor:pointer;'+(k===sel?'background:var(--mint2)':'')+'"><b class="sp">'+E(p.name)+'</b><span class="muted mono" style="font-size:12px">'+E(p.sku)+' · stock '+p.stock+'</span></div>').join('')||'<div class="muted" style="padding:12px">No match</div>';$$('[data-k]',sg).forEach(r=>r.onmousedown=e=>{e.preventDefault();add(hits[+r.dataset.k])})};
    q.oninput=()=>{sel=0;show()};
    q.onkeydown=e=>{if(e.key==='ArrowDown'){sel=Math.min(hits.length-1,sel+1);show();e.preventDefault()}else if(e.key==='ArrowUp'){sel=Math.max(0,sel-1);show();e.preventDefault()}else if(e.key==='Enter'){e.preventDefault();const s=q.value.trim().toLowerCase();const ex=AP.all('products').find(p=>p.sku.toLowerCase()===s||(p.mfr||'').toLowerCase()===s);if(ex)add(ex);else if(hits[sel])add(hits[sel])}};
    q.onblur=()=>setTimeout(()=>sg.classList.add('hide'),150);
  };
  const post=async()=>{
    if(!d.lines.length){AP.toast('Add at least one item','bad');return}
    if(d.lines.some(l=>!(+l.qty>0))){AP.toast('Enter a quantity for every line','bad');return}
    const c=calc();const paid=R(d.paid===''?c.payable:Math.min(+d.paid||0,c.payable));const due=R(c.payable-paid);
    if(due>0&&!d.supplier){AP.toast('Choose a supplier to keep the unpaid amount','bad');return}
    d.lines.forEach((l,i)=>{const p=AP.find('products',l.pid);if(!p)return;const r=c.rows[i];p.stock=(+p.stock||0)+(+l.qty);p.cost=R(r.real*100)/100||p.cost;if(+l.sell)p.price=+l.sell;if(l.exp&&(!p.expiry||l.exp<p.expiry))p.expiry=l.exp;AP.put('products',p)});
    const sup=d.supplier?AP.find('suppliers',d.supplier):null;if(sup){sup.due=(sup.due||0)+due;AP.put('suppliers',sup)}
    const rec={id:AP.uid(),no:AP.seq('sti','STI-'),t:Date.now(),supplierId:d.supplier,supplierName:sup?sup.name:'—',ref:d.ref,lines:d.lines.map((l,i)=>{const p=AP.find('products',l.pid)||{};const r=c.rows[i];return{pid:l.pid,name:p.name,qty:+l.qty,gross:R(gross(l)),disc:R(ldisc(l)),billDisc:R(r.bd),cost:R(r.real*100)/100,sell:+l.sell,total:r.tot}}),subtotal:R(c.sub),lineDisc:R(c.ld),billDisc:R(c.bd),extra:R(c.ex),total:c.payable,paid,due,cashPaid:d.pay==='cash'?paid:0,by:AP.me().name};
    AP.put('stockins',rec);if(AP.log)AP.log('Stock in '+rec.no,M(c.payable)+(c.bd?' (bill discount '+M(c.bd)+')':''));
    d=blank();AP.set(KEY,d);AP.toast('Stock in '+rec.no+' posted — '+M(c.payable));location.hash='#/stockins';
  };
  draw();sums();
  const kd=e=>{if(!document.contains(v)||!$('#po',v)){document.removeEventListener('keydown',kd);return}if(e.key==='F2'){e.preventDefault();const q=$('#sq',v);if(q)q.focus()}if((e.ctrlKey||e.metaKey)&&e.key==='Enter')post()};document.addEventListener('keydown',kd);
};
P.stockins=function(v){
  AP.list(v,{title:'Stock-in history',unit:'stock-ins',rows:()=>AP.all('stockins').sort((a,b)=>b.t-a.t),search:r=>r.no+' '+r.supplierName+' '+r.ref,date:r=>r.t,
    actions:p=>{p.innerHTML='<a class="btn" href="#/stockin">+ New stock in</a>'},
    filters:[{k:'q',type:'text',ph:'Number, supplier or note',grow:1},{k:'from',type:'date',label:'From'},{k:'to',type:'date',label:'To'}],
    cols:[{h:'Number',f:r=>'<a href="#" class="mono b" data-id="'+r.id+'">'+r.no+'</a>'},{h:'Date',f:r=>AP.dt(r.t)},{h:'Supplier',f:r=>E(r.supplierName)},{h:'Items',f:r=>r.lines.length},{h:'Total',cls:'r num',f:r=>AP.n(r.total)},{h:'Paid',cls:'r num',f:r=>AP.n(r.paid)},{h:'Owed',cls:'r num',f:r=>r.due?'<b class="warn">'+AP.n(r.due)+'</b>':'—'},{h:'By',f:r=>E(r.by)}],
    empty:{icon:'<i class="fa-solid fa-arrow-down"></i>',title:'No stock-ins yet',text:'Receive goods from your supplier here.',btn:'+ New stock in',fn:()=>location.hash='#/stockin'},
    after:tw=>$$('a[data-id]',tw).forEach(a=>a.onclick=e=>{e.preventDefault();const r=AP.find('stockins',a.dataset.id);AP.modal({title:r.no,sub:AP.dt(r.t)+' · '+E(r.supplierName),size:'lg',body:'<div class="card tw"><table class="t"><thead><tr><th>Item</th><th class="r">Qty</th><th class="r">Real cost</th><th class="r">Selling</th><th class="r">Total</th></tr></thead><tbody>'+r.lines.map(l=>'<tr><td>'+E(l.name)+'</td><td class="r">'+l.qty+'</td><td class="r">'+AP.n(l.cost)+'</td><td class="r">'+AP.n(l.sell)+'</td><td class="r b">'+AP.n(l.qty*l.cost)+'</td></tr>').join('')+'</tbody></table></div><div class="row" style="margin-top:12px"><span class="sp muted">'+E(r.ref||'')+'</span><b>Total '+M(r.total)+'</b></div>',foot:[{label:'Close',cls:'pri'}]})})});
};
})();
