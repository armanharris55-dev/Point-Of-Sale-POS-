/* Amanath POS — core: data layer (localStorage now, swap for PHP/MySQL API later), helpers, sale/return logic */
(function(){
'use strict';
const A=window.AP={};
A.log=(type,msg,ref)=>{try{const l=A.get('log',[]);l.unshift({t:Date.now(),type,msg,ref:ref||'',by:(A.me()||{}).name||'—'});if(l.length>1500)l.length=1500;A.set('log',l)}catch(e){}};
const NS='amnpos:';
const jp=s=>{try{return JSON.parse(s)}catch(e){return null}};
/* ---------- storage ---------- */
A.get=(k,d)=>{let v=null;try{v=jp(localStorage.getItem(NS+k))}catch(e){}return v==null?d:v};
A.set=(k,v)=>{try{localStorage.setItem(NS+k,JSON.stringify(v))}catch(e){A.toast&&A.toast('Storage full / blocked','bad')}};
A.all=c=>A.get(c,[]);
A.uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
A.put=(c,o)=>{const a=A.all(c);if(!o.id)o.id=A.uid();const i=a.findIndex(x=>x.id===o.id);if(i<0)a.push(o);else a[i]=o;A.set(c,a);return o};
A.del=(c,id)=>A.set(c,A.all(c).filter(x=>x.id!==id));
A.find=(c,id)=>A.all(c).find(x=>x.id===id);
A.seq=(k,pre,pad)=>{const s=A.get('seq',{});s[k]=(s[k]||0)+1;A.set('seq',s);return pre+String(s[k]).padStart(pad==null?6:pad,'0')};
/* ---------- format ---------- */
A.n=(v,d)=>(+v||0).toLocaleString('en-US',{minimumFractionDigits:d==null?2:d,maximumFractionDigits:d==null?2:d});
A.money=v=>'৳'+A.n(v);
const p2=n=>String(n).padStart(2,'0');
A.dt=t=>{if(!t)return'—';const d=new Date(t);let h=d.getHours();const ap=h>=12?'PM':'AM';h=h%12||12;return p2(d.getDate())+'-'+p2(d.getMonth()+1)+'-'+d.getFullYear()+' '+p2(h)+':'+p2(d.getMinutes())+' '+ap};
A.d=t=>t?A.dt(t).slice(0,10):'—';
A.iso=t=>{const d=new Date(t);return d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate())};
A.day0=t=>{const d=new Date(t||Date.now());d.setHours(0,0,0,0);return +d};
A.esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
A.$=(s,r)=>(r||document).querySelector(s);
A.$$=(s,r)=>[...(r||document).querySelectorAll(s)];
A.ago=t=>{const d=Math.floor((Date.now()-t)/864e5);return d<=0?'today':d+' day'+(d>1?'s':'')+' ago'};
A.csv=(name,rows)=>{const q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"';const b=new Blob(['﻿'+rows.map(r=>r.map(q).join(',')).join('\n')],{type:'text/csv'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)};
A.debounce=(f,ms)=>{let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>f(...a),ms||120)}};
/* ---------- settings ---------- */
A.cfg=()=>Object.assign({shop:{name:'My Shop',addr:'',phone:'',email:''},vat:0,footer:'Thank you for shopping with us!',paper:'80',lowStock:5,ptsPer:100,ptsValue:1,wa:true},A.get('cfg',{}));
A.setCfg=c=>A.set('cfg',c);
/* ---------- auth (frontend mock; real auth arrives with the PHP backend) ---------- */
A.sha=async s=>{try{if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('amn|'+s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}}catch(e){}let h=5381;for(const c of 'amn|'+s)h=((h*33)^c.charCodeAt(0))>>>0;return'x'+h.toString(16)};
A.me=()=>{const s=A.get('session');return s?A.find('users',s.uid)||null:null};
A.guard=roles=>{const u=A.me();if(!u||u.off){location.replace('login.html');return null}if(roles&&roles.indexOf(u.role)<0){location.replace('pos.html');return null}return u};
A.logout=()=>{try{localStorage.removeItem(NS+'session')}catch(e){}location.replace('login.html')};
A.theme=()=>{const t=A.get('theme','light');document.documentElement.dataset.theme=t;return t};
A.toggleTheme=()=>{A.set('theme',A.get('theme','light')==='dark'?'light':'dark');A.theme()};
A.theme();
/* ---------- UI helpers ---------- */
A.toast=(m,t)=>{let w=A.$('#toasts');if(!w){w=document.createElement('div');w.id='toasts';document.body.appendChild(w)}const e=document.createElement('div');e.className='toast '+(t||'ok');e.textContent=m;w.appendChild(e);setTimeout(()=>{e.style.opacity=0;setTimeout(()=>e.remove(),250)},t==='bad'?4200:2600)};
A.modal=o=>{
  const mo=document.createElement('div');mo.className='mo';
  mo.innerHTML='<div class="md '+(o.size||'')+'" role="dialog" aria-modal="true"><header><div style="flex:1"><h2></h2>'+(o.sub?'<p>'+o.sub+'</p>':'')+'</div><button class="ib" aria-label="Close" data-x><i class="fa-solid fa-xmark"></i></button></header><div class="mb"></div>'+(o.foot&&o.foot.length?'<footer></footer>':'')+'</div>';
  A.$('h2',mo).innerHTML=o.title||'';
  const body=A.$('.mb',mo);if(typeof o.body==='string')body.innerHTML=o.body;else if(o.body)body.appendChild(o.body);
  const prevFocus=document.activeElement;
  const m={el:mo,body,close(v){mo.remove();document.removeEventListener('keydown',kd,true);if(o.onClose)o.onClose(v);if(prevFocus&&prevFocus.focus&&document.contains(prevFocus)&&!o.noRestore)try{prevFocus.focus()}catch(e){}}};
  const kd=e=>{if(e.key==='Escape'&&mo===[...document.querySelectorAll('.mo')].pop()){e.stopPropagation();m.close()}};
  document.addEventListener('keydown',kd,true);
  A.$('[data-x]',mo).onclick=()=>m.close();
  mo.addEventListener('mousedown',e=>{if(e.target===mo&&!o.sticky)m.close()});
  if(o.foot&&o.foot.length){const f=A.$('footer',mo);o.foot.forEach(b=>{const x=document.createElement('button');x.className='btn '+(b.cls||'ghost');x.innerHTML=b.label;x.onclick=()=>{const r=b.fn?b.fn(m,x):m.close();return r};if(b.id)x.id=b.id;f.appendChild(x)})}
  document.body.appendChild(mo);
  const f=A.$('input:not([type=hidden]),select,textarea',body);if(f&&!o.noFocus)setTimeout(()=>{try{f.focus()}catch(e){}},30);
  return m;
};
A.confirm=(msg,ok,danger)=>new Promise(res=>{let done=false;const m=A.modal({title:'Please confirm',size:'sm',body:'<p style="margin:6px 0">'+msg+'</p>',onClose:()=>{if(!done)res(false)},foot:[{label:'Cancel',cls:'ghost'},{label:ok||'Yes, continue',cls:danger?'acc':'pri',fn:m=>{done=true;res(true);m.close()}}]})});
A.pop=(btn,html,cb)=>{A.$$('.pop').forEach(p=>p.remove());const p=document.createElement('div');p.className='pop';p.innerHTML=html;btn.parentElement.style.position='relative';btn.parentElement.appendChild(p);const off=e=>{if(!p.contains(e.target)){p.remove();document.removeEventListener('mousedown',off,true)}};setTimeout(()=>document.addEventListener('mousedown',off,true),0);p.addEventListener('click',e=>{const t=e.target.closest('[data-a]');if(t){p.remove();cb&&cb(t.dataset.a,t)}});return p};
A.avatar=n=>String(n||'?').trim().split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase();
A.pwScore=p=>{let s=0;if(p.length>=8)s++;if(p.length>=12)s++;if(/[a-z]/.test(p)&&/[A-Z]/.test(p))s++;if(/\d/.test(p)&&/[^A-Za-z0-9]/.test(p))s++;return Math.min(4,s)};
A.phoneOk=p=>/^(\+?88)?01[3-9]\d{8}$/.test(String(p).replace(/[\s-]/g,''));
A.waLink=(phone,msg)=>{let p=String(phone||'').replace(/\D/g,'');if(p.startsWith('0'))p='88'+p;return 'https://wa.me/'+p+'?text='+encodeURIComponent(msg)};
/* ---------- list page builder: filters + table + pager ---------- */
A.list=(root,c)=>{
  const f={};let page=1;const PS=c.ps||15;
  root.innerHTML='<div class="ph"><h1>'+c.title+(c.info?'<i class="info" title="'+A.esc(c.info)+'">i</i>':'')+'</h1><div class="row pha"></div></div>'+(c.pre||'')+'<div class="card"><div class="fbar"></div><div class="tw"></div><div class="pgn"></div></div>';
  const pha=A.$('.pha',root);if(c.actions)c.actions(pha);
  const fb=A.$('.fbar',root);
  (c.filters||[]).forEach(x=>{
    const d=document.createElement('div');d.className='fld'+(x.grow?' grow':'');
    let h='';
    if(x.type==='text'){d.className+=' srch';h='<input class="inp" data-k="'+x.k+'" placeholder="'+A.esc(x.ph||'Search')+'">'}
    else if(x.type==='date'){h='<label>'+x.label+'</label><input class="inp" type="date" data-k="'+x.k+'">'}
    else{h='<label>'+x.label+'</label><select class="sel" data-k="'+x.k+'">'+x.opts().map(o=>'<option value="'+A.esc(o[0])+'"'+(o[0]===x.def?' selected':'')+'>'+A.esc(o[1])+'</option>').join('')+'</select>'}
    d.innerHTML=h;fb.appendChild(d);f[x.k]=x.def||'';if(x.type==='text'&&A.q&&A.q.get('q')){f[x.k]=A.q.get('q');d.querySelector('input').value=f[x.k]}
  });
  const render=()=>{
    let rows=c.rows();
    (c.filters||[]).forEach(x=>{const v=f[x.k];if(v==null||v==='')return;
      if(x.type==='text'){const q=v.toLowerCase();rows=rows.filter(r=>c.search(r).toLowerCase().includes(q))}
      else if(x.type==='date'){const t=+new Date(v+'T00:00:00');rows=rows.filter(r=>x.k==='from'?c.date(r)>=t:c.date(r)<t+864e5)}
      else if(x.test)rows=rows.filter(r=>x.test(r,v))});
    if(c.sort){const s=c.sort(f);if(s)rows.sort(s)}
    const tw=A.$('.tw',root),pg=A.$('.pgn',root);
    if(!rows.length){const e=c.empty||{};tw.innerHTML='<div class="empty"><div class="ei">'+(e.icon||'<i class="fa-solid fa-ban"></i>')+'</div><h4>'+(e.title||'Nothing here yet')+'</h4><p>'+(e.text||'')+'</p>'+(e.btn?'<button class="btn" id="emptyBtn">'+e.btn+'</button>':'')+'</div>';pg.innerHTML='';const b=A.$('#emptyBtn',root);if(b&&e.fn)b.onclick=e.fn;return}
    const pages=Math.ceil(rows.length/PS);if(page>pages)page=pages;
    const sl=rows.slice((page-1)*PS,page*PS);
    tw.innerHTML='<table class="t"><thead><tr>'+c.cols.map(x=>'<th class="'+(x.cls||'')+'">'+x.h+'</th>').join('')+'</tr></thead><tbody>'+sl.map((r,i)=>'<tr data-i="'+i+'">'+c.cols.map(x=>'<td class="'+(x.cls||'')+'">'+x.f(r,(page-1)*PS+i)+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
    pg.innerHTML='<span>Page <b>'+page+'</b> of '+pages+' ('+rows.length+' '+(c.unit||'records')+')</span><button class="ib" data-p="-1" '+(page<2?'disabled':'')+'>‹</button><button class="ib" data-p="1" '+(page>=pages?'disabled':'')+'>›</button>';
    A.$$('[data-p]',pg).forEach(b=>b.onclick=()=>{page+=+b.dataset.p;render()});
    if(c.after)c.after(tw,sl,rows);
  };
  fb.addEventListener('input',A.debounce(e=>{const k=e.target.dataset.k;if(!k)return;f[k]=e.target.value;page=1;render()},100));
  fb.addEventListener('change',e=>{const k=e.target.dataset.k;if(!k)return;f[k]=e.target.value;page=1;render()});
  render();return{render,filters:f};
};
/* ---------- counters / shifts ---------- */
A.openShift=()=>A.all('shifts').find(s=>!s.closedAt&&s.by===(A.me()||{}).id);
A.shiftOf=cid=>A.all('shifts').find(s=>!s.closedAt&&s.counterId===cid);
A.shiftCash=sid=>{
  const s=A.find('shifts',sid);if(!s)return{open:0,sales:0,manual:0,recv:0,ref:0,exp:0,in:0,out:0,expected:0};
  let sales=0,recv=0,ref=0,exp=0,ci=0,co=0,man=0;
  A.all('invoices').forEach(i=>{if(i.shiftId!==sid)return;(i.pay||[]).forEach(p=>{if(p.m==='cash')sales+=p.amt});sales-=i.change||0});
  A.all('receipts').forEach(r=>{if(r.shiftId===sid&&r.method==='cash'&&r.status!=='void')recv+=r.amount});
  A.all('returns').forEach(r=>{if(r.shiftId===sid&&r.method==='cash')ref+=r.refund});
  A.all('expenses').forEach(e=>{if(e.shiftId===sid&&e.drawer)exp+=e.amount});
  A.all('cashmoves').forEach(m=>{if(m.shiftId===sid){if(m.type==='in')ci+=m.amt;else co+=m.amt}});
  A.all('manualsales').forEach(m=>{if(m.shiftId===sid)man+=m.amount});
  const open=s.openCash||0;
  return{open,sales,manual:man,recv,ref,exp,in:ci,out:co,expected:open+sales+man+recv+ci-ref-exp-co};
};
/* ---------- customers ---------- */
A.custDue=cid=>A.all('invoices').filter(i=>i.customerId===cid&&i.due>0).reduce((a,i)=>a+i.due,0);
A.syncCust=cid=>{const c=A.find('customers',cid);if(!c)return;c.due=A.custDue(cid);A.put('customers',c);return c};
A.newCustCode=()=>A.seq('cus','CUS-',3);
/* ---------- products / stock ---------- */
A.stockOf=p=>p.type==='service'?Infinity:(+p.stock||0);
A.adjustStock=(pid,delta)=>{const p=A.find('products',pid);if(!p||p.type==='service')return;p.stock=(+p.stock||0)+delta;A.put('products',p)};
A.catName=id=>{const c=A.find('categories',id);if(!c)return'';const par=c.parent?A.find('categories',c.parent):null;return par?par.name+' › '+c.name:c.name};
/* ---------- SALE ---------- */
A.totals=(cart,invDisc,vatPct)=>{
  const sub=cart.reduce((a,l)=>a+Math.max(0,l.price*l.qty-(+l.disc||0)),0);
  const disc=Math.min(+invDisc||0,sub);
  const vat=Math.round((sub-disc)*(+vatPct||0))/100;
  return{sub,disc,vat,total:Math.round((sub-disc+vat)*100)/100};
};
A.makeSale=o=>{
  const t=A.totals(o.cart,o.invDisc,o.vatPct);
  const pay=(o.pay||[]).filter(p=>p.amt>0);
  const paidAll=pay.reduce((a,p)=>a+p.amt,0);
  const cashAmt=pay.filter(p=>p.m==='cash').reduce((a,p)=>a+p.amt,0);
  const change=Math.max(0,Math.min(cashAmt,paidAll-t.total));
  const paid=Math.min(paidAll,t.total);
  const due=Math.max(0,Math.round((t.total-paid)*100)/100);
  const cust=o.customer?A.find('customers',o.customer.id):null;
  if(due>0&&!cust)return{err:'Select a customer to sell on due'};
  const inv={id:A.uid(),no:A.seq('inv','INV-'),t:Date.now(),customerId:cust?cust.id:null,customerName:cust?cust.name:'Walk-in',
    customerCat:cust?cust.cat:'',items:o.cart.map(l=>({pid:l.pid,name:l.name,sku:l.sku,unit:l.unit,qty:l.qty,price:l.price,cost:l.cost||0,disc:+l.disc||0})),
    sub:t.sub,invDisc:t.disc,vat:t.vat,total:t.total,pay,paid,change,due,by:o.user.id,byName:o.user.name,salesperson:o.salesperson||'',
    shiftId:o.shift?o.shift.id:null,counterId:o.shift?o.shift.counterId:null,note:o.note||'',status:due>0?(paid>0?'partial':'due'):'paid'};
  A.put('invoices',inv);A.log('sale',inv.no+' · '+A.money(inv.total)+(due?' · due '+A.money(due):''),inv.no);
  inv.items.forEach(l=>A.adjustStock(l.pid,-l.qty));
  if(cust){
    pay.forEach(p=>{if(p.m==='advance')cust.advance=Math.max(0,(cust.advance||0)-p.amt)});
    const cfg=A.cfg();cust.points=(cust.points||0)+Math.floor(t.total/(cfg.ptsPer||100));
    if(o.redeem)cust.points=Math.max(0,(cust.points||0)-o.redeem);cust.last=Date.now();cust.spent=(cust.spent||0)+t.total;A.put('customers',cust);A.syncCust(cust.id);
  }
  pay.filter(p=>p.m==='gift'&&p.code).forEach(p=>{const g=A.all('giftcards').find(x=>x.code===p.code);if(g){g.balance=Math.max(0,g.balance-p.amt);A.put('giftcards',g)}});
  return{inv};
};
A.makeReturn=o=>{
  const inv=o.invoice;const items=o.items.filter(x=>x.qty>0);if(!items.length)return{err:'Select at least one item'};
  const refund=Math.round(items.reduce((a,x)=>a+x.qty*x.net,0)*100)/100;
  const r={id:A.uid(),no:A.seq('ret','RET-'),t:Date.now(),invoiceId:inv.id,invoiceNo:inv.no,customerId:inv.customerId,customerName:inv.customerName,items,refund,method:o.method,reason:o.reason||'',by:o.user.id,byName:o.user.name,shiftId:(A.openShift()||{}).id||null,status:'posted'};
  A.put('returns',r);A.log('return',r.no+' · refund '+A.money(refund)+' ('+inv.no+')',r.no);
  items.forEach(x=>A.adjustStock(x.pid,x.qty));
  inv.returned=(inv.returned||0)+refund;
  items.forEach(x=>{const l=inv.items.find(i=>i.pid===x.pid);if(l)l.ret=(l.ret||0)+x.qty});
  if(o.method==='due'){const take=Math.min(inv.due||0,refund);inv.due=(inv.due||0)-take}
  else if(o.method==='advance'&&inv.customerId){const c=A.find('customers',inv.customerId);if(c){c.advance=(c.advance||0)+refund;A.put('customers',c)}}
  A.put('invoices',inv);if(inv.customerId)A.syncCust(inv.customerId);
  return{ret:r};
};
/* ---------- print ---------- */
A.printInv=(inv,mode)=>{
  const cfg=A.cfg(),s=cfg.shop,a4=mode==='a4';
  const rows=inv.items.map((l,i)=>a4?'<tr><td>'+(i+1)+'</td><td>'+A.esc(l.name)+'</td><td class=r>'+l.qty+' '+A.esc(l.unit||'')+'</td><td class=r>'+A.n(l.price)+'</td><td class=r>'+(l.disc?A.n(l.disc):'—')+'</td><td class=r>'+A.n(l.price*l.qty-l.disc)+'</td></tr>':'<tr><td colspan=3>'+A.esc(l.name)+'</td></tr><tr><td>'+l.qty+' × '+A.n(l.price)+'</td><td></td><td class=r>'+A.n(l.price*l.qty-l.disc)+'</td></tr>').join('');
  const tot='<table class=tot><tr><td>Subtotal</td><td class=r>'+A.n(inv.sub)+'</td></tr>'+(inv.invDisc?'<tr><td>Discount</td><td class=r>-'+A.n(inv.invDisc)+'</td></tr>':'')+(inv.vat?'<tr><td>VAT</td><td class=r>'+A.n(inv.vat)+'</td></tr>':'')+'<tr class=g><td>TOTAL</td><td class=r>'+A.money(inv.total)+'</td></tr>'+(inv.pay||[]).map(p=>'<tr><td>Paid · '+p.m+'</td><td class=r>'+A.n(p.amt)+'</td></tr>').join('')+(inv.change?'<tr><td>Change</td><td class=r>'+A.n(inv.change)+'</td></tr>':'')+(inv.due?'<tr><td><b>DUE</b></td><td class=r><b>'+A.n(inv.due)+'</b></td></tr>':'')+'</table>';
  const css='*{box-sizing:border-box}body{font:'+(a4?'13px':'11px')+'/1.4 system-ui,"Noto Sans Bengali",Arial,sans-serif;margin:0;padding:'+(a4?'18mm':'3mm')+';width:'+(a4?'auto':'72mm')+';color:#000}h1{font-size:'+(a4?'24px':'15px')+';margin:0}.c{text-align:center}.r{text-align:right}table{width:100%;border-collapse:collapse}th{text-align:left;border-bottom:1px solid #000;padding:5px 3px}'+(a4?'td{padding:7px 3px;border-bottom:1px solid #ddd}':'td{padding:1px 0}')+'.tot{margin-top:8px;'+(a4?'width:300px;margin-left:auto':'')+'}.g td{border-top:1px dashed #000;font-weight:800;font-size:'+(a4?'16px':'13px')+'}hr{border:0;border-top:1px dashed #000;margin:7px 0}.sm{color:#444;font-size:'+(a4?'12px':'10px')+'}';
  const html='<!doctype html><meta charset=utf-8><title>'+inv.no+'</title><style>'+css+'</style><div class=c><h1>'+A.esc(s.name)+'</h1><div class=sm>'+A.esc(s.addr||'')+'<br>'+A.esc(s.phone||'')+'</div></div><hr><div class=sm><b>'+inv.no+'</b> · '+A.dt(inv.t)+'<br>Customer: '+A.esc(inv.customerName)+' · Cashier: '+A.esc(inv.byName)+'</div><hr><table>'+(a4?'<tr><th>#<th>Item<th class=r>Qty<th class=r>Price<th class=r>Disc<th class=r>Total</tr>':'')+rows+'</table><hr>'+tot+'<hr><div class="c sm">'+A.esc(cfg.footer||'')+'</div>';
  const fr=document.createElement('iframe');fr.style.cssText='position:fixed;right:0;bottom:0;width:0;height:0;border:0';document.body.appendChild(fr);fr.contentDocument.open();fr.contentDocument.write(html);fr.contentDocument.close();
  setTimeout(()=>{try{fr.contentWindow.focus();fr.contentWindow.print()}catch(e){}setTimeout(()=>fr.remove(),4000)},250);
};
A.invHTML=inv=>{
  const cfg=A.cfg(),s=cfg.shop;
  return'<div style="font-size:13px"><b style="font-size:17px">'+A.esc(s.name)+'</b><div class="muted">'+A.esc(s.addr||'')+(s.phone?' · '+A.esc(s.phone):'')+'</div>'
  +'<div class="row" style="margin:14px 0;align-items:flex-start"><div class="sp"><div class="lbl">Bill to</div>'+A.esc(inv.customerName)+'</div><div style="text-align:right"><div class="lbl">Invoice</div><b class="mono">'+inv.no+'</b><br>'+A.dt(inv.t)+'<br><span class="tag '+(inv.due>0?'warn':'ok')+'">'+(inv.due>0?'Due '+A.money(inv.due):'Paid')+'</span></div></div>'
  +'<div class="tw card"><table class="t"><thead><tr><th>#</th><th>Item</th><th class="r">Qty</th><th class="r">Price</th><th class="r">Disc</th><th class="r">Total</th></tr></thead><tbody>'+inv.items.map((l,i)=>'<tr><td>'+(i+1)+'</td><td><b>'+A.esc(l.name)+'</b>'+(l.ret?' <span class="tag warn">returned '+l.ret+'</span>':'')+'<div class="muted mono" style="font-size:11px">'+A.esc(l.sku||'')+'</div></td><td class="r">'+l.qty+' '+A.esc(l.unit||'')+'</td><td class="r">'+A.n(l.price)+'</td><td class="r">'+(l.disc?A.n(l.disc):'—')+'</td><td class="r b">'+A.n(l.price*l.qty-l.disc)+'</td></tr>').join('')+'</tbody></table></div>'
  +'<div style="max-width:300px;margin-left:auto;margin-top:12px"><div class="sumrow"><span>Subtotal</span><b>'+A.n(inv.sub)+'</b></div>'+(inv.invDisc?'<div class="sumrow"><span>Invoice discount</span><b>-'+A.n(inv.invDisc)+'</b></div>':'')+(inv.vat?'<div class="sumrow"><span>VAT</span><b>'+A.n(inv.vat)+'</b></div>':'')+'<div class="sumrow"><span><b>Total</b></span><b style="font-size:17px">'+A.money(inv.total)+'</b></div>'+(inv.pay||[]).map(p=>'<div class="sumrow"><span>Paid · '+p.m+'</span><b>'+A.n(p.amt)+'</b></div>').join('')+(inv.returned?'<div class="sumrow"><span>Returned</span><b class="bad">-'+A.n(inv.returned)+'</b></div>':'')+'</div>'
  +'<div class="muted" style="margin-top:10px">Cashier: '+A.esc(inv.byName)+(inv.salesperson?' · Salesperson: '+A.esc(inv.salesperson):'')+(inv.note?'<br>Note: '+A.esc(inv.note):'')+'</div></div>';
};
/* ---------- demo data ---------- */
A.seedDemo=()=>{
  const me=A.me()||{id:'u0',name:'Owner'};
  const cats=[['Medicine',['Tab','Syrup','Cap']],['Grocery',['Noodles','Oil & Spices','Snacks']],['Baby Care',['Diapers','Lotion']],['Stationery',[]],['Fashion Accessories',['Churi']]];
  const cid={};
  cats.forEach(([n,subs])=>{const p=A.put('categories',{id:A.uid(),name:n,on:true});cid[n]=p.id;subs.forEach(s=>{cid[n+'/'+s]=A.put('categories',{id:A.uid(),name:s,parent:p.id,on:true}).id})});
  const br={};['Square Pharma','Beximco','Mama','Pran','Soldiers Shop','Himalaya','Local'].forEach(n=>br[n]=A.put('brands',{id:A.uid(),name:n,on:true}).id);
  const un={};['pcs','pack','box','kg','ltr','strip'].forEach(n=>un[n]=A.put('units',{id:A.uid(),name:n,on:true}).id);
  A.put('attrs',{id:A.uid(),name:'Size',values:['S','M','L','XL']});A.put('attrs',{id:A.uid(),name:'Colour',values:['Red','Blue','Black']});
  const P=[
   ['Napa 500 mg tab','Medicine/Tab','Square Pharma','strip',9,12,120,'2027-06-30'],['Olmesan 20 mg tab','Medicine/Tab','Beximco','strip',7,10,45,'2026-12-05'],['Neuro-B 30 tab','Medicine/Tab','Square Pharma','box',220,300,3,'2027-03-01'],
   ['Ace Syrup 60 ml','Medicine/Syrup','Square Pharma','pcs',38,55,28,'2026-11-28'],['Maxpro 20 mg cap','Medicine/Cap','Beximco','strip',48,70,60,'2027-09-12'],
   ['Mama Hot & Spicy Noodles 8 pack','Grocery/Noodles','Mama','pack',165,185,24,''],['Mama Chicken Noodles single','Grocery/Noodles','Mama','pcs',18,25,90,''],
   ['Pran Mustard Oil 1 ltr','Grocery/Oil & Spices','Pran','ltr',185,210,16,'2027-02-14'],['Pran Turmeric 200 g','Grocery/Oil & Spices','Pran','pack',60,78,22,'2027-05-10'],['Chanachur 150 g','Grocery/Snacks','Pran','pack',28,40,41,''],
   ['Thai Diaper XXXL 24 pcs','Baby Care/Diapers','Local','pack',520,600,1,''],['Baby Lotion 200 ml','Baby Care/Lotion','Himalaya','pcs',210,265,12,'2027-01-20'],
   ['My Melody Sticker Notebook','Stationery','Soldiers Shop','pcs',110,148,16,''],['2 Hole Pencil Sharpener','Stationery','Local','pcs',80,133,40,''],['Ball Pen Blue (box 50)','Stationery','Local','box',230,320,9,''],
   ['Jumka Churi Medium','Fashion Accessories/Churi','Soldiers Shop','pcs',150,220,4,''],['Future Music Car Toy','Baby Care','Local','pcs',290,520,6,''],['Napkin Tissue Pack','Grocery/Snacks','Local','pack',22,30,3,'']
  ];
  const prods=P.map((x,i)=>A.put('products',{id:A.uid(),sku:'AMN'+String(100000+i*37),mfr:'',name:x[0],cat:cid[x[1]],brand:br[x[2]],unit:x[3],cost:x[4],price:x[5],stock:x[6],min:5,expiry:x[7],tax:0,type:'stock',on:true,t:Date.now()-i*1000}));
  const names=[['Rahim Uddin','01711107238','Regular'],['Mafuj Rahman','01711107211','General'],['Selina Parvin','01621809183','Regular'],['MD Rasel','01674737301','General'],['Israt Jahan','01303735356','VIP'],['Sukur Alli','01763773686','General'],['Elias Uddin','01734587339','Regular'],['Saiful Mama','01938884531','Wholesale']];
  const custs=names.map(n=>A.put('customers',{id:A.uid(),code:A.newCustCode(),name:n[0],phone:n[1],cat:n[2],due:0,advance:0,points:0,spent:0,on:true,t:Date.now()}));
  ['Square Distributors','Pran Agency','Dhaka Wholesale Mart'].forEach((n,i)=>A.put('suppliers',{id:A.uid(),name:n,phone:'0171110'+(1000+i),addr:'Dhaka',due:i?0:1800,on:true}));
  const c1=A.put('counters',{id:A.uid(),code:'CTR-001',name:'First'});const c2=A.put('counters',{id:A.uid(),code:'CTR-002',name:'Second'});
  const mk=(daysAgo,hh,n,cu,onDue)=>{
    const lines=[];for(let k=0;k<n;k++){const p=prods[(Math.random()*prods.length)|0];if(lines.find(l=>l.pid===p.id))continue;lines.push({pid:p.id,name:p.name,sku:p.sku,unit:p.unit,qty:1+((Math.random()*3)|0),price:p.price,cost:p.cost,disc:0})}
    const t=A.totals(lines,0,0);const d=new Date();d.setDate(d.getDate()-daysAgo);d.setHours(hh,(Math.random()*59)|0);
    const inv={id:A.uid(),no:A.seq('inv','INV-'),t:+d,customerId:cu?cu.id:null,customerName:cu?cu.name:'Walk-in',customerCat:cu?cu.cat:'',items:lines,sub:t.sub,invDisc:0,vat:0,total:t.total,pay:onDue?[]:[{m:'cash',amt:t.total}],paid:onDue?0:t.total,change:0,due:onDue?t.total:0,by:me.id,byName:me.name,salesperson:'',shiftId:null,counterId:c1.id,note:'',status:onDue?'due':'paid'};
    A.put('invoices',inv);return inv};
  for(let d=6;d>=0;d--){const k=3+((Math.random()*5)|0);for(let j=0;j<k;j++)mk(d,9+((Math.random()*11)|0),1+((Math.random()*3)|0),Math.random()<.4?custs[(Math.random()*custs.length)|0]:null,false)}
  mk(2,15,2,custs[5],true);mk(1,18,3,custs[7],true);
  custs.forEach(c=>A.syncCust(c.id));
  [['Shop rent',12000],['Electricity',1800],['Tea & snacks',350]].forEach((e,i)=>A.put('expenses',{id:A.uid(),no:A.seq('exp','EXP-',5),t:Date.now()-i*864e5,cat:e[0],amount:e[1],method:'cash',note:'',by:me.name,drawer:false}));
  A.put('giftcards',{id:A.uid(),code:'GC-1000',balance:1000});
  A.toast('Demo data loaded');
};
A.wipe=()=>{Object.keys(localStorage).filter(k=>k.startsWith(NS)&&k!==NS+'theme').forEach(k=>localStorage.removeItem(k))};

/* activity logging wrappers */
(function(){const ms=A.makeSale;A.makeSale=function(o){const r=ms(o);if(r&&r.inv)A.log('Sale',r.inv.no+' · '+A.money(r.inv.total),r.inv.id);return r};
const mr=A.makeReturn;if(mr)A.makeReturn=function(o){const r=mr(o);if(r&&!r.err)A.log('Return',(r.ret&&r.ret.no||'')+' '+(r.ret?A.money(r.ret.total||0):''));return r};
const put=A.put;A.put=function(c,o){const isNew=!o.id||!A.find(c,o.id);const r=put(c,o);if(isNew&&{expenses:'Expense',receipts:'Customer receipt',manualsales:'Manual sale',shifts:'Counter opened'}[c])A.log({expenses:'Expense',receipts:'Customer receipt',manualsales:'Manual sale',shifts:'Counter opened'}[c],(r&&(r.no||r.amount||r.amt))||'');return r}})();
})();
