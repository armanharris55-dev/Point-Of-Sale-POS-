/* Amanath POS — selling screen */
(function(){
'use strict';
const me=AP.guard();if(!me)return;
const $=AP.$,$$=AP.$$,E=AP.esc,M=AP.money;
AP.refresh=()=>{};
const cfg=AP.cfg();
const S={cart:[],cust:null,invDisc:0,method:'cash',paid:'',splits:null,note:'',mul:1,sel:-1,sp:'',redeem:0};
let shift=null,counter=null;
const isStaff=me.role!=='cashier';

/* ---------- top bar ---------- */
function bar(){
  const sh=shift;
  $('#pbar').innerHTML=(isStaff?'<a class="pb" href="dashboard.html">← Back</a>':'<button class="pb" id="lo"><i class="fa-solid fa-right-from-bracket"></i> Log out</button>')
  +'<a class="logo" href="#" style="font-size:18px">Amanath<sup>®</sup><span class="pos">POS</span></a>'
  +'<span class="pinfo hm"><b>'+E(cfg.shop.name)+'</b> · '+(counter?E(counter.name):'—')+(sh?' <span class="muted">· Shift</span> <b class="mono">'+sh.no+'</b> <span class="ob">opened '+AP.dt(sh.openedAt).slice(11)+' by '+E(sh.byName)+'</span>':'')+'</span>'
  +'<span class="sp"></span><span class="on" id="on">Online</span>'
  +'<button class="pb" id="b-calc"><i class="fa-solid fa-calculator"></i> Calculator</button><button class="pb" id="b-exp"><i class="fa-solid fa-money-bill-transfer"></i> Expense</button><button class="pb" id="b-lock"><i class="fa-solid fa-lock"></i> Lock</button><button class="pb" id="b-close"><i class="fa-solid fa-power-off"></i> Close shift</button><button class="ib" id="b-th" style="background:transparent;border-color:#ffffff30;color:#fff"><i class="fa-solid fa-moon"></i></button>'
  +'<span class="clock" id="clk"></span><span class="av" title="'+E(me.name)+'">'+AP.avatar(me.name)+'</span>';
  const lo=$('#lo');if(lo)lo.onclick=AP.logout;
  $('#b-calc').onclick=calc;$('#b-exp').onclick=()=>AP.expenseForm(()=>AP.toast('Expense recorded'));$('#b-lock').onclick=lock;$('#b-close').onclick=closeShift;$('#b-th').onclick=AP.toggleTheme;
  tick();
}
function tick(){const d=new Date();const c=$('#clk');if(c)c.innerHTML=AP.d(+d)+'<b>'+AP.dt(+d).slice(11)+'</b>';const o=$('#on');if(o){o.textContent=navigator.onLine?'Online':'Offline — data is saved on this device';o.classList.toggle('off',!navigator.onLine)}}
setInterval(tick,15000);addEventListener('online',tick);addEventListener('offline',tick);

/* ---------- shift ---------- */
function ensureShift(){
  shift=AP.openShift();
  if(shift){counter=AP.find('counters',shift.counterId);return true}
  let C=AP.all('counters');
  if(!C.length){C=[AP.put('counters',{id:AP.uid(),code:AP.seq('ctr','CTR-',3),name:'Counter 1'})]}
  const free=C.filter(c=>!AP.shiftOf(c.id));
  if(!free.length){AP.modal({title:'No free counter',sticky:true,body:'<p>All counters are open by other users. Ask the manager to add or free a counter.</p>',foot:[{label:'Back',cls:'pri',fn:()=>isStaff?location.href='dashboard.html':AP.logout()}]});return false}
  const pre=new URLSearchParams(location.search).get('c');
  const m=AP.modal({title:'Open counter',sub:'Choose a counter and count the opening cash in the drawer.',sticky:true,body:'<div class="fld"><label class="req">Counter</label><select class="sel" id="oc">'+free.map(c=>'<option value="'+c.id+'"'+(c.id===pre?' selected':'')+'>'+E(c.name)+' · '+c.code+'</option>').join('')+'</select></div>',foot:[{label:isStaff?'← Dashboard':'Log out',fn:()=>isStaff?location.href='dashboard.html':AP.logout()},{label:'Count cash & open',cls:'pri',fn:mm=>{
    const cid=$('#oc',m.el).value;
    const c=AP.countModal('Opening cash','Count the cash in the drawer to start.',null,(amt,m2)=>{
      const s=AP.put('shifts',{id:AP.uid(),no:AP.seq('csn','CSN-'),counterId:cid,by:me.id,byName:me.name,openedAt:Date.now(),openCash:amt});
      m2.close();mm.close();shift=s;counter=AP.find('counters',cid);bar();AP.toast('Counter opened');$('#sq').focus()},'Open counter');
  }}]});
  return false;
}
function closeShift(){
  if(!shift)return;
  const run=()=>AP.closeShift(shift.id,()=>{isStaff?location.href='dashboard.html':AP.logout()});
  if(S.cart.length){AP.confirm('You have items in the cart. Close the shift anyway?','Close shift',true).then(y=>y&&run())}else run();
}

/* ---------- cart ---------- */
const T=()=>AP.totals(S.cart,S.invDisc+S.redeem*(cfg.ptsValue||1),cfg.vat);
function addProduct(p,qty){
  qty=qty||S.mul||1;
  if(p.on===false){AP.toast('This product is inactive','bad');return}
  const ex=S.cart.find(l=>l.pid===p.id);const have=AP.stockOf(p);
  const want=(ex?ex.qty:0)+qty;
  if(want>have){AP.toast('Only '+have+' '+(p.unit||'')+' of “'+p.name+'” in stock','bad');if(have<=0||(ex&&ex.qty>=have))return;qty=have-(ex?ex.qty:0)}
  if(ex){ex.qty+=qty;S.sel=S.cart.indexOf(ex)}
  else{const wp=+p.wprice||0,w=S.cust&&S.cust.cat==='Wholesale'&&wp;S.cart.push({pid:p.id,name:p.name,sku:p.sku,unit:p.unit,price:w?wp:+p.price,rp:+p.price,wp,cost:+p.cost||0,qty,disc:0,dv:'',dt:'p',stock:have,tax:p.tax});S.sel=S.cart.length-1}
  S.mul=1;S.paid='';S.splits=null;render();
}
const dsc=l=>{const g=l.price*l.qty,v=+l.dv||0;l.disc=Math.round(Math.max(0,Math.min(g,l.dt==='v'?v:g*v/100))*100)/100;return l.disc};
function reprice(){let ch=false;S.cart.forEach(l=>{if(l.manual)return;const np=(S.cust&&S.cust.cat==='Wholesale'&&l.wp)?l.wp:(l.rp||l.price);if(np!==l.price){l.price=np;ch=true}});return ch}
function render(){
  const L=$('#lines');S.cart.forEach(dsc);
  if(!S.cart.length){
    L.innerHTML='<div class="ready"><div><div class="ic"><i class="fa-solid fa-barcode"></i></div><h3>Ready for the next customer</h3><div>Scan an item, tap a tile, or press <span class="kbd">F2</span> and type a name.</div><div class="keys"><span><span class="kbd">F4</span> customer</span><span><span class="kbd">F8</span> payment</span><span><span class="kbd">Enter</span> finish sale</span><span><span class="kbd">5</span><span class="kbd">*</span> then scan adds 5</span><span><span class="kbd">↑</span><span class="kbd">↓</span> pick a line</span><span><span class="kbd">+</span><span class="kbd">−</span> qty</span></div></div></div>';
  }else{
    L.innerHTML=S.cart.map((l,i)=>'<div class="cl '+(i===S.sel?'sel':'')+'" data-i="'+i+'"><div class="r1"><div class="nm"><b>'+E(l.name)+'</b><div class="muted mono" style="font-size:11px">'+E(l.sku)+' · '+E(l.unit||'')+'</div></div><b class="t">'+AP.n(Math.max(0,l.price*l.qty-l.disc))+'</b><button class="ib" data-x aria-label="Remove"><i class="fa-solid fa-xmark"></i></button></div>'
    +'<div class="r2"><span class="qs"><button data-q="-1" aria-label="Less"><i class="fa-solid fa-minus"></i></button><input data-f="qty" type="number" min="1" value="'+l.qty+'"><button data-q="1" aria-label="More"><i class="fa-solid fa-plus"></i></button></span><span class="lb">×</span>'
    +(isStaff?'<input data-f="price" type="number" min="0" step="0.01" value="'+l.price+'" title="Unit price">':'<span class="mono">'+AP.n(l.price)+'</span>')
    +'<span class="sp"></span><span class="lb">Disc</span><input data-f="dv" type="number" min="0" step="0.01" value="'+(l.dv||'')+'" placeholder="0"><button class="dtg" data-dt title="Switch % / ৳">'+(l.dt==='v'?'৳':'%')+'</button></div></div>').join('');
    $$('.cl',L).forEach(tr=>{const i=+tr.dataset.i;
      tr.onclick=e=>{if(S.sel!==i){S.sel=i;$$('.cl',L).forEach(x=>x.classList.toggle('sel',+x.dataset.i===i))}};
      $$('[data-q]',tr).forEach(b=>b.onclick=e=>{e.stopPropagation();chg(i,+b.dataset.q)});
      $('[data-dt]',tr).onclick=e=>{e.stopPropagation();const l=S.cart[i];l.dt=l.dt==='v'?'p':'v';e.currentTarget.textContent=l.dt==='v'?'৳':'%';S.paid='';S.splits=null;partial()};
      $$('input',tr).forEach(inp=>inp.oninput=()=>{const l=S.cart[i],f=inp.dataset.f;let v=+inp.value;if(f==='qty'){if(!(v>=1))return;if(v>l.stock){AP.toast('Only '+l.stock+' in stock','bad');v=l.stock;inp.value=v}l.qty=v}else if(f==='price'){l.price=Math.max(0,v||0);l.manual=true}else l.dv=inp.value;S.paid='';S.splits=null;partial()});
      $('[data-x]',tr).onclick=e=>{e.stopPropagation();S.cart.splice(i,1);S.sel=Math.min(S.sel,S.cart.length-1);S.paid='';render()};
    });
  }
  $('#lc').textContent=S.cart.length+' line'+(S.cart.length===1?'':'s')+' · '+S.cart.reduce((a,l)=>a+l.qty,0)+' pcs';
  right();
}
function chg(i,d){const l=S.cart[i];const n=l.qty+d;if(n<1){S.cart.splice(i,1);S.sel=Math.min(S.sel,S.cart.length-1)}else if(n>l.stock){AP.toast('Only '+l.stock+' in stock','bad');return}else l.qty=n;S.paid='';S.splits=null;render()}
function partial(){/* update totals without rebuilding line inputs (keeps focus) */
  S.cart.forEach((l,i)=>{dsc(l);const tr=$('.cl[data-i="'+i+'"] b.t',$('#lines'));if(tr)tr.textContent=AP.n(Math.max(0,l.price*l.qty-l.disc))});right(true)}

/* ---------- right panel ---------- */
const PM=[['cash','Cash','1'],['card','Card','2'],['mobile','Mobile','3'],['bank','Bank','4'],['gift','Gift','5'],['multiple','Multiple','6'],['advance','Advance','7'],['due','Due','8']];
function payState(){
  const t=T();let pays=[],paid=0,change=0;
  if(S.method==='due'){pays=[]}
  else if(S.method==='advance'){const a=Math.min(S.cust?S.cust.advance||0:0,t.total);pays=a>0?[{m:'advance',amt:a}]:[]}
  else if(S.splits){pays=S.splits.filter(p=>p.amt>0)}
  else{const amt=S.paid===''?t.total:Math.max(0,+S.paid||0);pays=amt>0?[{m:S.method,amt}]:[]}
  paid=pays.reduce((a,p)=>a+p.amt,0);
  const cash=pays.filter(p=>p.m==='cash').reduce((a,p)=>a+p.amt,0);
  change=Math.max(0,Math.min(cash,paid-t.total));
  const remaining=Math.max(0,Math.round((t.total-Math.min(paid,t.total))*100)/100);
  return{t,pays,paid:Math.min(paid,t.total+change),remaining,change};
}
function right(keep){
  if(!keep&&reprice()){render();return}
  const t=T(),ps=payState(),c=S.cust,due=c?AP.custDue(c.id):0;
  const canSale=S.cart.length>0&&shift&&(ps.remaining===0||(c&&S.method!=='gift'||(c&&ps.remaining>0)));
  const lim=c&&c.limit&&(due+ps.remaining>c.limit);
  const R=$('#pr');
  if(keep&&$('#tt',R)){
    $('#st',R).textContent=AP.n(t.sub);$('#vt',R).textContent=AP.n(t.vat);$('#id',R).textContent=AP.n(t.disc);$('#tt',R).textContent=M(t.total);
    $('#rm',R).textContent=AP.n(ps.remaining);$('#ch',R).textContent=AP.n(ps.change);
    const pi=$('#pd',R);if(pi&&document.activeElement!==pi)pi.value=S.method==='due'?'0.00':AP.n(ps.paid);
    $$('.sale,.sale2 button',R).forEach(b=>b.disabled=!canSale||lim);$('#rm',R).style.color=ps.remaining>0?'var(--bad)':'';return}
  R.innerHTML='<div class="card"><div class="row" style="margin-bottom:8px"><span class="lbl sp">Customer <span class="kbd">F4</span></span><a href="#" id="rcv" class="b" style="font-size:12.5px"><i class="fa-solid fa-hand-holding-dollar"></i> Receive money <span class="kbd">F3</span></a></div>'
   +(c?'<div class="cust has" id="cu"><span class="av" style="width:32px;height:32px;font-size:12px">'+AP.avatar(c.name)+'</span><div class="sp" style="min-width:0"><b>'+E(c.name)+'</b><div class="muted" style="font-size:12px">'+E(c.phone)+' · '+E(c.cat)+'</div><div style="font-size:12px">'+(due?'<span class="bad">Due '+M(due)+'</span> · ':'')+(c.advance?'<span class="ok">Advance '+M(c.advance)+'</span> · ':'')+'<i class="fa-solid fa-star"></i> '+(c.points||0)+'</div></div><button class="ib" id="cx" aria-label="Remove customer">×</button></div>':'<div class="cust" id="cu"><span><i class="fa-solid fa-user"></i></span><span class="muted sp">Phone or name</span><span class="tag">Walk-in</span></div>')+'</div>'
   +'<div class="card tots"><div class="row2"><span>Subtotal</span><b class="mono" id="st">'+AP.n(t.sub)+'</b></div><div class="row2"><a href="#" id="rd">'+(c&&c.points&&cfg.ptsValue?'<i class="fa-solid fa-star"></i> Redeem points ('+c.points+')':'')+'</a><span></span></div><div class="row2"><a href="#" id="idc"><i class="fa-solid fa-percent"></i> Invoice discount</a><b class="mono" id="id">'+AP.n(t.disc)+'</b></div><div class="row2"><span>VAT'+(cfg.vat?' ('+cfg.vat+'%)':'')+'</span><b class="mono" id="vt">'+AP.n(t.vat)+'</b></div></div>'
   +'<div class="big"><span>TOTAL TO PAY</span><b id="tt">'+M(t.total)+'</b></div>'
   +'<div class="card"><div class="lbl">Payment <span class="kbd">F8</span></div><div class="pgrid">'+PM.map(p=>'<button class="pm '+(S.method===p[0]||(p[0]==='multiple'&&S.splits&&S.method==='multiple')?'on':'')+'" data-m="'+p[0]+'" '+(!S.cart.length?'disabled':'')+'>'+p[1]+'<span class="kbd">'+p[2]+'</span></button>').join('')+'</div>'+(S.cart.length?'':'<div class="muted" style="font-size:12.5px;margin-bottom:8px">Add an item to take payment.</div>')
   +'<div class="pstat"><div><small>PAID</small><input id="pd" inputmode="decimal" value="'+(S.method==='due'?'0.00':AP.n(ps.paid))+'" '+(S.method==='due'||S.method==='advance'||S.splits||!S.cart.length?'readonly':'')+'></div><div><small>REMAINING</small><b id="rm" style="color:'+(ps.remaining>0?'var(--bad)':'')+'">'+AP.n(ps.remaining)+'</b></div><div><small>CHANGE</small><b id="ch">'+AP.n(ps.change)+'</b></div></div>'
   +(ps.remaining>0&&c?'<div class="warn" style="font-size:12.5px;margin-top:8px">'+M(ps.remaining)+' will be added to '+E(c.name)+'’s due.'+(lim?' <b class="bad">Over credit limit!</b>':'')+'</div>':ps.remaining>0&&S.cart.length?'<div class="bad" style="font-size:12.5px;margin-top:8px">Full payment needed — or choose a customer to keep the rest as due.</div>':'')
   +'</div><div><button class="sale" id="sale" '+(!canSale||lim?'disabled':'')+'>✓ Sale <span class="kbd">Enter</span></button><div class="sale2"><button id="sp80" '+(!canSale||lim?'disabled':'')+'><i class="fa-solid fa-print"></i> Sale &amp; Print <span class="kbd">Ctrl+⏎</span></button><button id="spa4" '+(!canSale||lim?'disabled':'')+'><i class="fa-solid fa-file-lines"></i> A4 Print <span class="kbd">Shift+⏎</span></button></div></div>';
  $('#cu',R).onclick=e=>{if(e.target.closest('#cx'))return;pickCustomer()};
  const cx=$('#cx',R);if(cx)cx.onclick=e=>{e.stopPropagation();S.cust=null;S.redeem=0;if(S.method==='due'||S.method==='advance')S.method='cash';right()};
  $('#rcv',R).onclick=e=>{e.preventDefault();quickReceive()};
  $('#idc',R).onclick=e=>{e.preventDefault();discModal()};
  $('#rd',R).onclick=e=>{e.preventDefault();redeemModal()};
  $$('.pm',R).forEach(b=>b.onclick=()=>setMethod(b.dataset.m));
  const pd=$('#pd',R);pd.oninput=()=>{S.paid=pd.value.replace(/[^\d.]/g,'');const p=payState();$('#rm',R).textContent=AP.n(p.remaining);$('#ch',R).textContent=AP.n(p.change);$('#rm',R).style.color=p.remaining>0?'var(--bad)':'';const ok=S.cart.length&&shift&&(p.remaining===0||c);$$('.sale,.sale2 button',R).forEach(b=>b.disabled=!ok)};
  pd.onfocus=()=>pd.select();
  $('#sale',R).onclick=()=>finish();$('#sp80',R).onclick=()=>finish('80');$('#spa4',R).onclick=()=>finish('a4');
}
function setMethod(m){
  if(!S.cart.length)return;
  if((m==='due'||m==='advance')&&!S.cust){AP.toast('Select a customer first','bad');pickCustomer(()=>setMethod(m));return}
  if(m==='advance'&&!(S.cust.advance>0)){AP.toast('This customer has no advance','bad');return}
  if(m==='gift'){giftModal();return}
  if(m==='multiple'){multiModal();return}
  S.method=m;S.splits=null;S.paid='';right();
  if(m!=='due'&&m!=='advance'){const pd=$('#pd');if(pd){pd.focus()}}
}
/* ---------- modals ---------- */
function discModal(){
  const t=T();
  const m=AP.modal({title:'Invoice discount',size:'sm',body:'<div class="seg" id="dm" style="margin-bottom:10px"><button class="on" data-k="amt">৳ Amount</button><button data-k="pct">% Percent</button></div><div class="fld"><label>Discount</label><input class="inp" type="number" min="0" step="0.01" id="dv" value="'+(S.invDisc||'')+'" placeholder="0"></div><div class="muted" style="margin-top:8px">Subtotal '+M(t.sub)+'</div>',foot:[{label:'Remove',fn:mm=>{S.invDisc=0;S.paid='';mm.close();right()}},{label:'Apply',cls:'pri',fn:mm=>{let v=+$('#dv',m.el).value||0;if($('#dm .on',m.el).dataset.k==='pct')v=t.sub*Math.min(100,v)/100;S.invDisc=Math.min(Math.max(0,v),t.sub);S.paid='';mm.close();right()}}]});
  $$('#dm button',m.el).forEach(b=>b.onclick=()=>{$$('#dm button',m.el).forEach(x=>x.classList.toggle('on',x===b))});
  $('#dv',m.el).onkeydown=e=>{if(e.key==='Enter')$('.btn.pri',m.el).click()};
}
function redeemModal(){
  const c=S.cust;if(!c||!c.points)return;const maxPts=Math.min(c.points,Math.floor(T().total/(cfg.ptsValue||1)));
  const m=AP.modal({title:'Redeem points',size:'sm',body:'<p>'+E(c.name)+' has <b><i class="fa-solid fa-star"></i> '+c.points+'</b> points (1 point = '+M(cfg.ptsValue||1)+').</p><div class="fld"><label>Points to use (max '+maxPts+')</label><input class="inp" type="number" min="0" max="'+maxPts+'" id="rp" value="'+(S.redeem||maxPts)+'"></div>',foot:[{label:'Remove',fn:mm=>{S.redeem=0;S.paid='';mm.close();right()}},{label:'Use points',cls:'pri',fn:mm=>{S.redeem=Math.max(0,Math.min(maxPts,Math.floor(+$('#rp',m.el).value||0)));S.paid='';mm.close();right()}}]});
}
function giftModal(){
  const t=T().total;
  const m=AP.modal({title:'Gift card',size:'sm',body:'<div class="fld"><label class="req">Gift card code</label><input class="inp mono" id="gc" placeholder="GC-1000" autocomplete="off"></div><div class="muted" id="gi" style="margin-top:8px"></div>',foot:[{label:'Cancel'},{label:'Apply',cls:'pri',fn:mm=>{
    const code=$('#gc',m.el).value.trim().toUpperCase();const g=AP.all('giftcards').find(x=>x.code===code);
    if(!g||g.balance<=0){$('#gi',m.el).innerHTML='<span class="bad">Card not found or empty.</span>';return}
    const use=Math.min(g.balance,t);S.method='gift';S.splits=[{m:'gift',amt:use,code}];if(t-use>0)S.splits.push({m:'cash',amt:t-use});S.paid='';mm.close();AP.toast('Gift card '+M(use)+' applied'+(t-use>0?' — rest in cash':''));right();
  }}]});
  $('#gc',m.el).onkeydown=e=>{if(e.key==='Enter')$('.btn.pri',m.el).click()};
}
function multiModal(){
  const t=T().total;const cur={cash:0,card:0,mobile:0,bank:0};if(S.splits)S.splits.forEach(p=>{if(cur[p.m]!=null)cur[p.m]=p.amt});
  const m=AP.modal({title:'Split payment',sub:'Total to pay '+M(t),size:'sm',body:['cash','card','mobile','bank'].map(k=>'<div class="row" style="margin-bottom:8px"><b style="width:70px">'+AP.PAY[k]+'</b><input class="inp mp" data-m="'+k+'" type="number" min="0" step="0.01" value="'+(cur[k]||'')+'" placeholder="0"></div>').join('')+'<div class="row"><span class="lbl sp">Entered</span><b id="me">৳0.00</b></div><div class="row"><span class="lbl sp">Remaining</span><b id="mr">'+M(t)+'</b></div>',foot:[{label:'Cancel'},{label:'Apply',cls:'pri',fn:mm=>{const a=$$('.mp',m.el).map(i=>({m:i.dataset.m,amt:+i.value||0})).filter(x=>x.amt>0);if(!a.length)return;S.method='multiple';S.splits=a;S.paid='';mm.close();right()}}]});
  const up=()=>{const s=$$('.mp',m.el).reduce((a,i)=>a+(+i.value||0),0);$('#me',m.el).textContent=M(s);$('#mr',m.el).textContent=M(Math.max(0,t-s))};m.el.addEventListener('input',up);up();
}
function pickCustomer(after){
  const m=AP.modal({title:'Customer',size:'md',body:'<div class="srch"><input class="inp" id="cq" placeholder="Phone or name" autocomplete="off"></div><div id="cr" style="margin-top:10px;max-height:46vh;overflow:auto"></div>',foot:[{label:'Walk-in (no customer)',fn:mm=>{S.cust=null;mm.close();right()}},{label:'+ New customer',cls:'pri',fn:mm=>{mm.close();AP.customerForm(null,c=>{S.cust=c;right();after&&after()})}}]});
  const cr=$('#cr',m.el),cq=$('#cq',m.el);let sel=0,hits=[];
  const draw=()=>{const q=cq.value.trim().toLowerCase();hits=AP.all('customers').filter(c=>c.on!==false&&(!q||(c.name+' '+c.phone+' '+c.code).toLowerCase().includes(q))).slice(0,30);sel=Math.min(sel,Math.max(0,hits.length-1));cr.innerHTML=hits.map((c,k)=>'<div class="row it" data-k="'+k+'" style="padding:10px 12px;cursor:pointer;border-radius:9px;'+(k===sel?'background:var(--mint2)':'')+'"><span class="av" style="width:30px;height:30px;font-size:11px">'+AP.avatar(c.name)+'</span><div class="sp"><b>'+E(c.name)+'</b><div class="muted" style="font-size:12px">'+E(c.phone)+' · '+E(c.cat)+'</div></div>'+(AP.custDue(c.id)?'<span class="tag warn">Due '+AP.n(AP.custDue(c.id),0)+'</span>':'')+'</div>').join('')||'<div class="muted c" style="padding:20px">No customer found</div>';$$('.it',cr).forEach(r=>r.onclick=()=>{S.cust=hits[+r.dataset.k];S.redeem=0;m.close();right();after&&after()})};
  cq.oninput=()=>{sel=0;draw()};cq.onkeydown=e=>{if(e.key==='ArrowDown'){sel=Math.min(hits.length-1,sel+1);draw();e.preventDefault()}else if(e.key==='ArrowUp'){sel=Math.max(0,sel-1);draw();e.preventDefault()}else if(e.key==='Enter'&&hits[sel]){S.cust=hits[sel];S.redeem=0;m.close();right();after&&after()}};draw();
}
function quickReceive(){
  const c=S.cust;if(!c){AP.toast('Select a customer first','bad');pickCustomer(quickReceive);return}
  const due=AP.custDue(c.id);
  const m=AP.modal({title:'Receive money — '+E(c.name),sub:'Due now '+M(due)+' · Advance '+M(c.advance||0),size:'sm',body:'<div class="fld"><label class="req">Amount received (৳)</label><input class="inp" type="number" min="0" step="0.01" id="ra" value="'+(due||'')+'" style="font-size:18px;height:46px"></div><div class="fld" style="margin-top:10px"><label>Into</label><select class="sel" id="rmth"><option value="cash">Cash drawer</option><option value="bkash">bKash</option><option value="nagad">Nagad</option><option value="bank">Bank</option><option value="card">Card</option></select></div><div class="muted" style="margin-top:8px">Oldest bills are paid first. Extra becomes advance.</div>',foot:[{label:'Cancel'},{label:'Post receipt',cls:'pri',fn:mm=>{
    let amt=+$('#ra',m.el).value||0;if(!(amt>0))return;const total=amt;const bills=AP.all('invoices').filter(i=>i.customerId===c.id&&i.due>0).sort((a,b)=>a.t-b.t),nos=[];
    bills.forEach(i=>{if(amt<=0)return;const x=Math.min(i.due,amt);i.due=Math.round((i.due-x)*100)/100;i.paid=(i.paid||0)+x;i.status=i.due>0?'partial':'paid';AP.put('invoices',i);nos.push(i.no);amt-=x});
    const cc=AP.find('customers',c.id);if(amt>0)cc.advance=(cc.advance||0)+amt;AP.put('customers',cc);S.cust=AP.syncCust(c.id);
    const r={id:AP.uid(),no:AP.seq('crc','CRC-'),t:Date.now(),customerId:c.id,customerName:c.name,phone:c.phone,type:nos.length?'Due collected':'Advance received',amount:total,discount:0,method:$('#rmth',m.el).value,bills:nos,shiftId:shift?shift.id:null,by:me.id,byName:me.name,status:'posted'};
    AP.put('receipts',r);mm.close();AP.toast('Receipt '+r.no+' posted');right()}}]});
}
function calc(){
  let cur='0',acc=null,op=null,fresh=true;
  const m=AP.modal({title:'Calculator',size:'sm',body:'<div class="calc"><div class="disp" id="cd">0</div>'+['C','⌫','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','0','.','='].map(k=>'<button class="'+('÷×−+'.includes(k)?'op':k==='='?'eq':'')+'" data-k="'+k+'" '+(k==='='?'style="grid-column:span 2"':'')+'>'+k+'</button>').join('')+'</div>'});
  const show=()=>{$('#cd',m.el).textContent=cur.length>14?(+cur).toExponential(6):cur};
  const run=()=>{const b=parseFloat(cur),a=acc;if(op==='+')return a+b;if(op==='−')return a-b;if(op==='×')return a*b;if(op==='÷')return b===0?0:a/b;return b};
  const press=k=>{
    if(/\d/.test(k)){cur=fresh?k:(cur==='0'?k:cur+k);fresh=false}
    else if(k==='.'){if(fresh){cur='0.';fresh=false}else if(!cur.includes('.'))cur+='.'}
    else if(k==='C'){cur='0';acc=null;op=null;fresh=true}
    else if(k==='⌫'){cur=cur.length>1?cur.slice(0,-1):'0'}
    else if(k==='%'){cur=String(parseFloat(cur)/100)}
    else if('÷×−+'.includes(k)){if(op&&!fresh){cur=String(+run().toFixed(10));acc=parseFloat(cur)}else acc=parseFloat(cur);op=k;fresh=true}
    else if(k==='='){if(op){cur=String(+run().toFixed(10));op=null;acc=null;fresh=true}}
    show();
  };
  m.el.addEventListener('click',e=>{const b=e.target.closest('[data-k]');if(b)press(b.dataset.k)});
  m.el.addEventListener('keydown',e=>{const map={'*':'×','/':'÷','-':'−','Enter':'=','Backspace':'⌫',Escape:null};const k=map[e.key]!==undefined?map[e.key]:e.key;if(k&&/^[\d.+×÷−=C⌫%]$/.test(k)){press(k);e.preventDefault()}});
  m.el.tabIndex=-1;m.el.focus();
}
function lock(){
  const d=document.createElement('div');d.className='lock';d.innerHTML='<div class="bx"><div class="av" style="width:64px;height:64px;font-size:22px;margin:0 auto">'+AP.avatar(me.name)+'</div><h2>'+E(me.name)+'</h2><div style="color:#ffffffa0">Counter locked — enter your password</div><input class="inp" id="lp" type="password" autocomplete="current-password" placeholder="Password"><div id="le" class="bad" style="min-height:20px;color:#ff8a70"></div><button class="btn mint" style="width:100%" id="lu">Unlock</button></div>';
  document.body.appendChild(d);const i=$('#lp',d);i.focus();
  const go=async()=>{const h=await AP.sha(i.value);if(h===AP.find('users',me.id).pass){d.remove();$('#sq').focus()}else{$('#le',d).textContent='Wrong password';i.value='';i.focus()}};
  $('#lu',d).onclick=go;i.onkeydown=e=>{if(e.key==='Enter')go()};
}
/* ---------- hold / held / bills ---------- */
function hold(){
  if(!S.cart.length){AP.toast('Nothing to hold','bad');return}
  AP.put('held',{id:AP.uid(),t:Date.now(),cart:S.cart,cust:S.cust,invDisc:S.invDisc,note:S.note,by:me.name});
  AP.toast('Bill held — total '+M(T().total));reset(true);hc();
}
function held(){
  const L=AP.all('held').sort((a,b)=>b.t-a.t);
  const m=AP.modal({title:'Held bills',size:'lg',body:L.length?'<div class="card tw"><table class="t"><thead><tr><th>Held at</th><th>Customer</th><th>Items</th><th class="r">Total</th><th></th></tr></thead><tbody>'+L.map(h=>'<tr><td>'+AP.dt(h.t)+'</td><td>'+(h.cust?E(h.cust.name):'Walk-in')+'</td><td>'+h.cart.length+' lines</td><td class="r num">'+AP.n(AP.totals(h.cart,h.invDisc,cfg.vat).total)+'</td><td class="r"><button class="btn sm" data-r="'+h.id+'">Resume</button> <button class="btn sm danger" data-d="'+h.id+'">Delete</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty"><div class="ei"><i class="fa-solid fa-pause"></i></div><h4>No held bills</h4><p>Press F6 to hold the current bill while you serve someone else.</p></div>',foot:[{label:'Close',cls:'pri'}]});
  $$('[data-r]',m.el).forEach(b=>b.onclick=()=>{if(S.cart.length){AP.toast('Hold or reset the current bill first','bad');return}const h=AP.find('held',b.dataset.r);S.cart=h.cart;S.cust=h.cust;S.invDisc=h.invDisc;S.note=h.note;S.sel=0;AP.del('held',h.id);m.close();render()});
  $$('[data-d]',m.el).forEach(b=>b.onclick=()=>{AP.del('held',b.dataset.d);m.close();held()});
}
function bills(){
  const L=AP.all('invoices').filter(i=>i.t>=AP.day0()).sort((a,b)=>b.t-a.t);
  const m=AP.modal({title:'Today’s bills',size:'lg',body:L.length?'<div class="card tw"><table class="t"><thead><tr><th>Invoice</th><th>Time</th><th>Customer</th><th>Paid by</th><th class="r">Total</th><th></th></tr></thead><tbody>'+L.map(i=>'<tr><td class="mono b">'+i.no+'</td><td>'+AP.dt(i.t).slice(11)+'</td><td>'+E(i.customerName)+'</td><td>'+AP.payLabel(i)+'</td><td class="r num">'+AP.n(i.total)+'</td><td class="r"><button class="btn sm ghost" data-v="'+i.id+'">View</button> <button class="btn sm ghost" data-p="'+i.id+'"><i class="fa-solid fa-print"></i></button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty"><div class="ei"><i class="fa-solid fa-receipt"></i></div><h4>No bills today</h4></div>',foot:[{label:'Close',cls:'pri'}]});
  $$('[data-v]',m.el).forEach(b=>b.onclick=()=>AP.showInvoice(AP.find('invoices',b.dataset.v),()=>{}));
  $$('[data-p]',m.el).forEach(b=>b.onclick=()=>AP.printInv(AP.find('invoices',b.dataset.p),cfg.paper));
}
function noteModal(){const m=AP.modal({title:'Bill note',size:'sm',body:'<div class="fld"><label>Note (printed on invoice record)</label><textarea class="inp" id="nt" rows="3">'+E(S.note)+'</textarea></div>',foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:mm=>{S.note=$('#nt',m.el).value.trim();mm.close();AP.toast('Note saved')}}]})}
function keys(){AP.modal({title:'Keyboard shortcuts',size:'md',body:'<div class="grid g2" style="gap:6px 24px">'+[['F2','Search / scan'],['F3','Receive money'],['F4','Customer'],['F6','Hold bill'],['F7','Held bills'],['F8','Payment field'],['F9','Today’s bills'],['F10','Gift card'],['1 – 8','Choose payment'],['Enter','Finish sale'],['Ctrl + Enter','Sale & print 80 mm'],['Shift + Enter','Sale & print A4'],['5 *','Next scan adds 5'],['↑ ↓','Pick a line'],['+ / −','Line quantity'],['Delete','Remove line'],['Ctrl + Del','Reset bill'],['?','This help']].map(k=>'<div class="row"><span class="kbd" style="min-width:90px;text-align:center">'+k[0]+'</span><span>'+k[1]+'</span></div>').join('')+'</div>',foot:[{label:'Close',cls:'pri'}]})}
async function reset(silent){
  if(!silent&&S.cart.length&&!await AP.confirm('Clear this bill?','Clear',true))return;
  Object.assign(S,{cart:[],cust:null,invDisc:0,method:'cash',paid:'',splits:null,note:'',mul:1,sel:-1,redeem:0});$('#qv').textContent=1;$('#qb').classList.remove('hot');render();$('#sq').focus();
}
function acts(){
  const B=(id,ic,t,cls)=>'<button class="pa '+(cls||'')+'" id="a-'+id+'" title="'+t.replace(/<[^>]*>/g,'')+'"><i class="fa-solid fa-'+ic+'"></i>'+t+'</button>';
  $('#acts').innerHTML=B('hold','pause','Hold')+B('held','clipboard-list','Held <span class="tag" id="hc">0</span>')+B('bills','receipt','Bills')+B('note','note-sticky','Note')+B('cash','right-left','Cash in/out')+B('gift','gift','Gift card','gift')+'<span class="rsp"></span>'+B('reset','rotate-right','Reset')+B('keys','keyboard','Keys');
  $('#a-hold').onclick=hold;$('#a-held').onclick=held;$('#a-bills').onclick=bills;$('#a-note').onclick=noteModal;$('#a-cash').onclick=cashio;$('#a-reset').onclick=()=>reset();$('#a-keys').onclick=keys;$('#a-gift').onclick=()=>{if(!S.cart.length){AP.toast('Add an item first','bad');return}giftModal()};
  hc();
}
function cashio(){
  if(!shift){AP.toast('Open a counter first','bad');return}
  let ty='in';
  const m=AP.modal({title:'Cash in / out',sub:'Record money added to or taken from the drawer (not a sale).',size:'sm',body:'<div class="seg" id="cty" style="margin-bottom:12px"><button data-t="in" class="on">Cash in</button><button data-t="out">Cash out</button></div><div class="fld"><label class="req">Amount (৳)</label><input class="inp" id="cam" type="number" min="0" step="any"></div><div class="fld" style="margin-top:10px"><label class="req">Reason</label><input class="inp" id="cno" placeholder="e.g. change float, tea, supplier payment"></div>',foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:mm=>{const a=+$('#cam',m.el).value,n=$('#cno',m.el).value.trim();if(!(a>0)||!n){AP.toast('Enter amount and reason','bad');return false}AP.put('cashmoves',{id:AP.uid(),shiftId:shift.id,type:ty,amt:a,note:n,t:Date.now(),by:me.name});AP.log('Cash '+ty,M(a)+' · '+n);AP.toast('Cash '+ty+' saved');mm.close()}}]});
  $$('#cty button',m.el).forEach(b=>b.onclick=()=>{ty=b.dataset.t;$$('#cty button',m.el).forEach(x=>x.classList.toggle('on',x===b))});
  setTimeout(()=>$('#cam',m.el).focus(),50);
}
const hc=()=>{const e=$('#hc');if(e)e.textContent=AP.all('held').length};
/* ---------- product tiles ---------- */
let gcat='all';
function tiles(){
  const P=AP.all('products').filter(p=>p.on!==false);
  const cats=AP.all('categories').filter(c=>!c.parent&&c.on!==false&&P.some(p=>p.cat===c.id||(AP.find('categories',p.cat)||{}).parent===c.id));
  const favs=P.filter(p=>p.fav);
  const ch=[['all','All']].concat(favs.length?[['fav','★ Favorites']]:[]).concat(cats.map(c=>[c.id,c.name]));
  $('#chips').innerHTML=ch.map(c=>'<button data-c="'+E(c[0])+'" class="'+(gcat===c[0]?'on':'')+'">'+E(c[1])+'</button>').join('');
  $$('#chips button').forEach(b=>b.onclick=()=>{gcat=b.dataset.c;tiles()});
  let L=P;if(gcat==='fav')L=favs;else if(gcat!=='all')L=P.filter(p=>p.cat===gcat||(AP.find('categories',p.cat)||{}).parent===gcat);
  L=L.slice().sort((a,b)=>(b.fav?1:0)-(a.fav?1:0)||a.name.localeCompare(b.name)).slice(0,120);
  $('#grid').innerHTML=L.map(p=>{const st=p.type==='service'?null:AP.stockOf(p);return'<button class="tile'+(st!==null&&st<=0?' out':'')+'" data-p="'+p.id+'">'+(p.fav?'<i class="fa-solid fa-star fv"></i>':'')+'<b>'+E(p.name)+'</b><small>'+(st===null?'Service':st<=0?'Out of stock':st+' '+E(p.unit||''))+'</small><span class="pz">'+M(S.cust&&S.cust.cat==='Wholesale'&&p.wprice?p.wprice:p.price)+'</span></button>'}).join('')||'<div class="muted" style="padding:20px;grid-column:1/-1">No products here yet.</div>';
  $$('#grid .tile').forEach(b=>b.onclick=()=>{addProduct(AP.find('products',b.dataset.p));$('#qv').textContent=1;$('#qb').classList.remove('hot')});
}
/* ---------- finish sale ---------- */
let busy=false;
function finish(print){
  if(busy||!S.cart.length||!shift)return;
  const ps=payState();
  if(ps.remaining>0&&!S.cust){AP.toast('Choose a customer to keep the rest as due','bad');return}
  if(S.cust&&S.cust.limit&&AP.custDue(S.cust.id)+ps.remaining>S.cust.limit){AP.toast('Credit limit exceeded','bad');return}
  busy=true;
  const r=AP.makeSale({cart:S.cart,customer:S.cust,invDisc:S.invDisc+S.redeem*(cfg.ptsValue||1),vatPct:cfg.vat,pay:ps.pays,note:S.note,salesperson:S.sp,shift,user:me,redeem:S.redeem});
  busy=false;
  if(r.err){AP.toast(r.err,'bad');return}
  const inv=r.inv;
  $('#lastsale').innerHTML='Last: <b class="mono">'+inv.no+'</b> · '+M(inv.total)+(inv.change?' · change <b>'+M(inv.change)+'</b>':'');
  if(inv.change>0)AP.toast('Give change '+M(inv.change));else AP.toast('Sale complete — '+inv.no);
  if(print)AP.printInv(inv,print);
  reset(true);hc();tiles();
}
/* ---------- search ---------- */
const sq=$('#sq'),sg=$('#sg');let hits=[],hsel=0;
function suggest(){
  const raw=sq.value.trim();
  const mm=raw.match(/^(\d+)\s*\*$/);
  if(mm){S.mul=Math.max(1,+mm[1]);sq.value='';$('#qv').textContent=S.mul;$('#qb').classList.toggle('hot',S.mul>1);sg.classList.add('hide');return}
  const q=raw.toLowerCase();if(!q){sg.classList.add('hide');return}
  hits=AP.all('products').filter(p=>p.on!==false&&(p.name+' '+p.sku+' '+(p.mfr||'')).toLowerCase().includes(q)).sort((a,b)=>(a.sku.toLowerCase()===q?-1:0)-(b.sku.toLowerCase()===q?-1:0)).slice(0,8);
  hsel=Math.min(hsel,Math.max(0,hits.length-1));
  sg.classList.remove('hide');
  sg.innerHTML=hits.map((p,k)=>'<div class="it '+(k===hsel?'on':'')+'" data-k="'+k+'"><b>'+E(p.name)+'</b><span class="mono">'+E(p.sku)+'</span><span class="muted">'+(p.type==='service'?'service':(p.stock<=0?'<span class="bad">out</span>':p.stock+' '+E(p.unit||'')))+'</span><b class="mono">'+M(p.price)+'</b></div>').join('')||'<div class="it" style="color:var(--muted)">No product found for “'+E(raw)+'”</div>';
  $$('.it[data-k]',sg).forEach(r=>r.onmousedown=e=>{e.preventDefault();pick(hits[+r.dataset.k])});
}
function pick(p){sq.value='';sg.classList.add('hide');addProduct(p);$('#qv').textContent=1;$('#qb').classList.remove('hot');sq.focus()}
sq.oninput=()=>{hsel=0;suggest()};
sq.onblur=()=>setTimeout(()=>sg.classList.add('hide'),150);
sq.onkeydown=e=>{
  if(e.key==='ArrowDown'&&!sg.classList.contains('hide')){hsel=Math.min(hits.length-1,hsel+1);suggest();e.preventDefault()}
  else if(e.key==='ArrowUp'&&!sg.classList.contains('hide')){hsel=Math.max(0,hsel-1);suggest();e.preventDefault()}
  else if(e.key==='Enter'){
    const q=sq.value.trim().toLowerCase();
    if(q){e.preventDefault();e.stopPropagation();const ex=AP.all('products').find(p=>p.sku.toLowerCase()===q||(p.mfr||'').toLowerCase()===q);const p=ex||hits[hsel];if(p)pick(p);else AP.toast('No product found','bad')}
  }
};
$('#sp').innerHTML='<option value="">Choose</option>'+AP.all('users').filter(u=>!u.off).map(u=>'<option>'+E(u.name)+'</option>').join('');
$('#sp').onchange=e=>S.sp=e.target.value;
/* ---------- keyboard ---------- */
document.addEventListener('keydown',e=>{
  if(document.querySelector('.mo,.lock'))return;
  const tag=(e.target.tagName||'').toLowerCase(),typing=tag==='input'||tag==='textarea'||tag==='select';
  const k=e.key;
  const F={F2:()=>{sq.focus();sq.select()},F3:quickReceive,F4:()=>pickCustomer(),F6:hold,F7:held,F8:()=>{const p=$('#pd');if(p&&!p.readOnly){p.focus()}else if(S.cart.length)setMethod('cash')},F9:bills,F10:()=>{if(S.cart.length)giftModal()}};
  if(F[k]){e.preventDefault();F[k]();return}
  if(k==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();finish('80');return}
  if(k==='Enter'&&e.shiftKey){e.preventDefault();finish('a4');return}
  if(k==='Delete'&&e.ctrlKey){e.preventDefault();reset();return}
  if(typing){if(k==='Enter'&&e.target.id==='pd'){e.preventDefault();finish()}return}
  if(k==='Enter'){e.preventDefault();finish();return}
  if(k==='?'){keys();return}
  if(/^[1-8]$/.test(k)&&S.cart.length){setMethod(PM[+k-1][0]);return}
  if(k==='ArrowDown'&&S.cart.length){S.sel=Math.min(S.cart.length-1,S.sel+1);render();e.preventDefault()}
  else if(k==='ArrowUp'&&S.cart.length){S.sel=Math.max(0,S.sel-1);render();e.preventDefault()}
  else if((k==='+'||k==='=')&&S.sel>=0){chg(S.sel,1)}
  else if((k==='-'||k==='_')&&S.sel>=0){chg(S.sel,-1)}
  else if(k==='Delete'&&S.sel>=0){S.cart.splice(S.sel,1);S.sel=Math.min(S.sel,S.cart.length-1);S.paid='';render()}
  else if(/^\d$/.test(k)||k==='*'){sq.focus()}
});
window.addEventListener('beforeunload',e=>{if(S.cart.length){e.preventDefault();e.returnValue=''}});
/* ---------- boot ---------- */
bar();acts();render();tiles();
if(ensureShift()){bar();sq.focus()}else{bar()}
})();
