/* Dashboard pages: customers, receipts, receive money, suppliers */
(function(){
const P=AP.pages=AP.pages||{};const $=AP.$,$$=AP.$$,E=AP.esc,M=AP.money;
const CATS=['General','Regular','VIP','Wholesale'];

AP.customerForm=function(c,done){
  c=c||{};const isNew=!c.id;
  const m=AP.modal({title:isNew?'Add customer':'Edit customer',body:
   '<div class="grid g2"><div class="fld" id="n"><label class="req">Name</label><input class="inp" id="cn" value="'+E(c.name||'')+'"></div><div class="fld" id="p"><label class="req">Mobile</label><input class="inp" id="cp" inputmode="tel" value="'+E(c.phone||'')+'" placeholder="01XXXXXXXXX"></div>'
   +'<div class="fld"><label>Category</label><select class="sel" id="cc">'+CATS.map(x=>'<option'+(c.cat===x?' selected':'')+'>'+x+'</option>').join('')+'</select></div><div class="fld"><label>Email</label><input class="inp" id="ce" value="'+E(c.email||'')+'"></div>'
   +'<div class="fld"><label>Birthday</label><input class="inp" type="date" id="cb" value="'+E(c.bday||'')+'"></div><div class="fld"><label>Credit limit (৳)</label><input class="inp" type="number" min="0" id="cl" value="'+(c.limit||'')+'" placeholder="No limit"></div></div>'
   +'<div class="fld" style="margin-top:12px"><label>Address / note</label><textarea class="inp" id="ca" rows="2">'+E(c.addr||'')+'</textarea></div>',
   foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:mm=>{
     const name=$('#cn',m.el).value.trim(),phone=$('#cp',m.el).value.replace(/[\s-]/g,'');
     $$('.fld.err',m.el).forEach(x=>x.classList.remove('err'));
     if(!name){$('#n',m.el).classList.add('err');return}
     if(!AP.phoneOk(phone)){$('#p',m.el).classList.add('err');AP.toast('Enter a valid mobile number','bad');return}
     if(AP.all('customers').some(x=>x.phone===phone&&x.id!==c.id)){AP.toast('This mobile already exists','bad');return}
     const o=Object.assign({due:0,advance:0,points:0,spent:0,on:true,t:Date.now()},c,{name,phone,cat:$('#cc',m.el).value,email:$('#ce',m.el).value.trim(),bday:$('#cb',m.el).value,limit:+$('#cl',m.el).value||0,addr:$('#ca',m.el).value.trim()});
     if(isNew)o.code=AP.newCustCode();AP.put('customers',o);mm.close();AP.toast('Customer saved');if(done)done(o);else AP.refresh()}}]});
};
function ledger(c){
  const inv=AP.all('invoices').filter(i=>i.customerId===c.id).sort((a,b)=>b.t-a.t),rc=AP.all('receipts').filter(r=>r.customerId===c.id).sort((a,b)=>b.t-a.t);
  const due=AP.custDue(c.id);const cfg=AP.cfg();
  const m=AP.modal({title:E(c.name),sub:E(c.phone)+' · '+c.code+' · '+E(c.cat),size:'lg',body:
   '<div class="grid g4" style="margin-bottom:14px"><div class="card pad"><div class="lbl">Due</div><b class="'+(due?'bad':'')+'" style="font-size:20px">'+M(due)+'</b></div><div class="card pad"><div class="lbl">Advance</div><b style="font-size:20px">'+M(c.advance||0)+'</b></div><div class="card pad"><div class="lbl">Total bought</div><b style="font-size:20px">'+M(c.spent||0)+'</b></div><div class="card pad"><div class="lbl">Points</div><b style="font-size:20px"><i class="fa-solid fa-star"></i> '+(c.points||0)+'</b></div></div>'
   +'<div class="tabs"><button class="on" data-t="i">Invoices ('+inv.length+')</button><button data-t="r">Receipts ('+rc.length+')</button></div><div class="card tw" id="lt" style="max-height:300px"></div>',
   foot:[{label:'Edit',fn:mm=>{mm.close();AP.customerForm(c)}},due&&cfg.wa?{label:'<i class="fa-brands fa-whatsapp"></i> WhatsApp reminder',fn:()=>window.open(AP.waLink(c.phone,'আসসালামু আলাইকুম '+c.name+', '+cfg.shop.name+'-এ আপনার বকেয়া '+M(due)+'। অনুগ্রহ করে পরিশোধ করুন। ধন্যবাদ।'),'_blank')}:{label:''},{label:'<i class="fa-solid fa-hand-holding-dollar"></i> Receive money',cls:'pri',fn:mm=>{mm.close();location.hash='#/receipts/new?c='+c.id}}].filter(b=>b.label!=='')});
  const show=t=>{$$('.tabs button',m.el).forEach(b=>b.classList.toggle('on',b.dataset.t===t));$('#lt',m.el).innerHTML=t==='i'?(inv.length?'<table class="t"><tbody>'+inv.map(i=>'<tr><td class="mono b">'+i.no+'</td><td>'+AP.dt(i.t)+'</td><td class="r num">'+AP.n(i.total)+'</td><td>'+(i.due>0?'<span class="tag warn">Due '+AP.n(i.due)+'</span>':'<span class="tag ok">Paid</span>')+'</td></tr>').join('')+'</tbody></table>':'<div class="empty">No invoices</div>'):(rc.length?'<table class="t"><tbody>'+rc.map(r=>'<tr><td class="mono b">'+r.no+'</td><td>'+AP.d(r.t)+'</td><td>'+E(r.type)+'</td><td class="r num">'+AP.n(r.amount)+'</td></tr>').join('')+'</tbody></table>':'<div class="empty">No receipts</div>')};
  $$('.tabs button',m.el).forEach(b=>b.onclick=()=>show(b.dataset.t));show('i');
}
P.customers=function(v){
  const imp=()=>{const inp=document.createElement('input');inp.type='file';inp.accept='.csv,text/csv';inp.onchange=()=>{const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{
    const lines=String(r.result).replace(/^﻿/,'').split(/\r?\n/).filter(Boolean);let n=0,sk=0;
    lines.forEach((ln,i)=>{const c=ln.split(',').map(x=>x.replace(/^"|"$/g,'').trim());if(i===0&&/name/i.test(c[0]))return;const phone=(c[1]||'').replace(/[\s-]/g,'');if(!c[0]||!AP.phoneOk(phone)||AP.all('customers').some(x=>x.phone===phone)){sk++;return}AP.put('customers',{id:AP.uid(),code:AP.newCustCode(),name:c[0],phone,cat:CATS.includes(c[2])?c[2]:'General',due:0,advance:0,points:0,spent:0,on:true,t:Date.now()});n++});
    AP.toast(n+' imported'+(sk?', '+sk+' skipped':''));AP.refresh()};r.readAsText(f)};inp.click()};
  AP.list(v,{title:'Customers',unit:'customers',info:'Import a CSV with columns: name, mobile, category',
    rows:()=>AP.all('customers').map(c=>Object.assign({},c,{due:AP.custDue(c.id)})),search:r=>r.name+' '+r.phone+' '+r.code,
    sort:f=>f.sort==='due'?(a,b)=>b.due-a.due:(a,b)=>(b.t||0)-(a.t||0),
    actions:p=>{p.innerHTML='<button class="btn ghost" id="i"><i class="fa-solid fa-arrow-up-from-bracket"></i> Import</button><button class="btn" id="a">+ Add customer</button>';$('#i',p).onclick=imp;$('#a',p).onclick=()=>AP.customerForm()},
    filters:[{k:'q',type:'text',ph:'Name, mobile or code',grow:1},{k:'cat',label:'Category',opts:()=>[['','All']].concat(CATS.map(c=>[c,c])),test:(r,v)=>r.cat===v},
      {k:'st',label:'Status',opts:()=>[['','All'],['on','Active'],['off','Inactive']],test:(r,v)=>v==='on'?r.on!==false:r.on===false},
      {k:'show',label:'Show',opts:()=>[['','All'],['due','With due'],['adv','With advance']],test:(r,v)=>v==='due'?r.due>0:r.advance>0},
      {k:'sort',label:'Sort',opts:()=>[['','Newest'],['due','Highest due']]}],
    cols:[{h:'#',f:(r,i)=>'<span class="muted">'+(i+1)+'</span>'},{h:'Code',f:r=>'<span class="mono muted">'+r.code+'</span>'},{h:'Name',f:r=>'<a href="#" data-id="'+r.id+'" class="b">'+E(r.name)+'</a>'+(r.on===false?' <span class="tag">inactive</span>':'')},{h:'Mobile',f:r=>'<span class="mono">'+E(r.phone)+'</span>'},{h:'Category',f:r=>E(r.cat)},
      {h:'Due',cls:'r num',f:r=>r.due?'<b class="bad">'+M(r.due)+'</b>':M(0)},{h:'Advance',cls:'r num',f:r=>M(r.advance||0)},{h:'<i class="fa-solid fa-star"></i>',cls:'r',f:r=>r.points||0}],
    empty:{icon:'<i class="fa-solid fa-users"></i>',title:'No customers yet',text:'Add customers to track due, advance and loyalty points.',btn:'+ Add customer',fn:()=>AP.customerForm()},
    after:tw=>$$('a[data-id]',tw).forEach(a=>a.onclick=e=>{e.preventDefault();ledger(AP.find('customers',a.dataset.id))})});
};

/* ----- RECEIPTS ----- */
const ACCTS=[['cash','Cash drawer'],['bkash','bKash'],['nagad','Nagad'],['bank','Bank'],['card','Card']];
P.receipts=function(v){
  AP.list(v,{title:'Customer receipts',unit:'receipts',info:'Money received from customers: due collected or advance.',
    rows:()=>AP.all('receipts').sort((a,b)=>b.t-a.t),search:r=>r.no+' '+r.customerName+' '+r.phone+' '+(r.bills||[]).join(' '),date:r=>r.t,
    actions:p=>{p.innerHTML='<a class="btn" href="#/receipts/new">+ Receive money</a>'},
    filters:[{k:'q',type:'text',ph:'Receipt no., customer, mobile or bill no.',grow:1},{k:'type',label:'Type',opts:()=>[['','All'],['Due collected','Due collected'],['Advance received','Advance received'],['Advance returned','Advance returned']],test:(r,v)=>r.type===v},{k:'from',type:'date',label:'From'},{k:'to',type:'date',label:'To'}],
    cols:[{h:'Number',f:r=>'<b class="mono">'+r.no+'</b><div class="muted">'+AP.d(r.t)+'</div>'},{h:'Customer',f:r=>E(r.customerName)},{h:'Type',f:r=>E(r.type)},{h:'Amount',cls:'r num',f:r=>AP.n(r.amount)},{h:'Discount',cls:'r num',f:r=>r.discount?AP.n(r.discount):'—'},{h:'Into',f:r=>E((ACCTS.find(a=>a[0]===r.method)||[0,r.method])[1])},{h:'Bills',f:r=>(r.bills||[]).map(b=>'<span class="mono">'+b+'</span>').join(', ')||'—'},{h:'Status',f:r=>'<span class="tag ok">Posted</span>'},{h:'By',f:r=>E(r.byName)}],
    empty:{icon:'<i class="fa-solid fa-hand-holding-dollar"></i>',title:'No receipts yet',text:'Collect due or take an advance from a customer.',btn:'+ Receive money',fn:()=>location.hash='#/receipts/new'}});
};
P.receiptNew=function(v){
  const cu=AP.all('customers').sort((a,b)=>a.name.localeCompare(b.name));
  let kind='bills',cid=AP.q.get('c')||'',alloc={};
  v.innerHTML='<div class="ph"><a href="#/receipts" class="muted">‹ Customer receipts</a><h1 style="margin-left:6px">Receive money</h1><button class="btn ghost" id="dis">Discard</button><button class="btn" id="post">Post receipt <span class="kbd">Ctrl ⏎</span></button></div>'
  +'<div class="card pad" style="margin-bottom:14px"><div class="lbl" style="margin-bottom:6px">Receipt for</div><div class="seg" id="kd"><button data-k="bills" class="on">Bills</button><button data-k="adv">Advance only</button><button data-k="ret">Advance returned</button></div>'
  +'<div class="grid g4" style="margin-top:12px"><div class="fld"><label class="req">Customer</label><select class="sel" id="cu"><option value="">Choose customer…</option>'+cu.map(c=>'<option value="'+c.id+'"'+(c.id===cid?' selected':'')+'>'+E(c.name)+' · '+E(c.phone)+'</option>').join('')+'</select></div><div class="fld"><label>Date</label><input class="inp" type="date" id="dd" value="'+AP.iso(Date.now())+'"></div><div class="fld"><label class="req">Received into</label><select class="sel" id="ac">'+ACCTS.map(a=>'<option value="'+a[0]+'">'+a[1]+'</option>').join('')+'</select></div><div class="fld"><label>Reference</label><input class="inp" id="rf" placeholder="TrxID, cheque no."></div></div><div class="muted" id="ci" style="margin-top:10px"></div></div>'
  +'<div class="grid" style="grid-template-columns:1fr 300px;align-items:start" id="rg"><div class="card" id="bl"></div><div class="card pad"><div class="fld"><label>Amount received</label><input class="inp" id="am" type="number" min="0" step="0.01" placeholder="0.00" style="font-size:18px;height:46px;text-align:right"></div><div class="fld" style="margin-top:10px"><label>Remarks</label><input class="inp" id="rm" placeholder="Optional — discount note, who brought it"></div><div style="margin-top:12px"><div class="sumrow"><span>Applied to bills</span><b id="s1">৳0.00</b></div><div class="sumrow"><span>Goes to advance</span><b id="s2">৳0.00</b></div><div class="sumrow"><span><b>Owes after</b></span><b id="s3">৳0.00</b></div></div></div></div>';
  if(innerWidth<900)$('#rg',v).style.gridTemplateColumns='1fr';
  let bills=[];
  const calc=()=>{
    const amt=+$('#am',v).value||0;let left=amt,ap=0;
    if(kind==='bills'){bills.forEach(b=>{b.pay=0});const manual=Object.keys(alloc).length;
      if(manual){bills.forEach(b=>{b.pay=Math.min(b.due,alloc[b.id]||0)})}else{bills.forEach(b=>{const x=Math.min(b.due,left);b.pay=x;left-=x})}
      ap=bills.reduce((s,b)=>s+b.pay,0)}
    const adv=kind==='bills'?Math.max(0,amt-ap):amt;
    const owed=bills.reduce((s,b)=>s+b.due,0);
    $('#s1',v).textContent=M(kind==='bills'?ap:0);$('#s2',v).textContent=M(kind==='ret'?-amt:adv);$('#s3',v).textContent=M(Math.max(0,owed-ap));
    if(kind==='bills')$$('.bp',v).forEach(i=>{const b=bills.find(x=>x.id===i.dataset.id);if(document.activeElement!==i)i.value=b.pay?b.pay:'';$('#l'+b.id,v).textContent=AP.n(b.due-b.pay)});
    return{amt,ap,adv};
  };
  const drawBills=()=>{
    const c=cid?AP.find('customers',cid):null;
    $('#ci',v).innerHTML=c?'Owes <b class="bad">'+M(AP.custDue(c.id))+'</b> · Advance <b class="ok">'+M(c.advance||0)+'</b> · '+c.code+' · '+E(c.phone):'';
    const box=$('#bl',v);alloc={};
    if(kind!=='bills'){box.innerHTML='<div class="empty" style="padding:30px"><div class="ei">'+(kind==='adv'?'<i class="fa-solid fa-plus"></i>':'−')+'</div><h4>'+(kind==='adv'?'Advance only':'Advance returned')+'</h4><p>'+(kind==='adv'?'The amount is kept as advance and can be used on future bills.':'Money given back to the customer from their advance.')+'</p></div>';bills=[];calc();return}
    bills=c?AP.all('invoices').filter(i=>i.customerId===cid&&i.due>0).sort((a,b)=>a.t-b.t).map(i=>({id:i.id,no:i.no,t:i.t,due:i.due,pay:0})):[];
    box.innerHTML=!c?'<div class="empty" style="padding:30px"><p>Choose a customer to see open bills.</p></div>':bills.length?'<div class="row" style="padding:12px 16px"><b class="sp">Open bills · '+bills.length+' · oldest first</b><a href="#" id="pa">Pay all</a><a href="#" id="cl">Clear</a></div><div class="tw"><table class="t"><thead><tr><th>Bill</th><th>Date</th><th class="r">Owed (৳)</th><th class="r" style="width:130px">Pay</th><th class="r">Left</th></tr></thead><tbody>'+bills.map(b=>'<tr><td class="mono b">'+b.no+'</td><td>'+AP.d(b.t)+' <span class="muted">· '+AP.ago(b.t)+'</span></td><td class="r num">'+AP.n(b.due)+'</td><td><input class="inp bp" type="number" min="0" step="0.01" data-id="'+b.id+'" style="text-align:right"></td><td class="r num" id="l'+b.id+'">'+AP.n(b.due)+'</td></tr>').join('')+'</tbody></table></div>':'<div class="empty" style="padding:30px"><div class="ei">✓</div><h4>No open bills</h4><p>This customer has nothing due. Use "Advance only" to take advance money.</p></div>';
    const pa=$('#pa',v);if(pa)pa.onclick=e=>{e.preventDefault();$('#am',v).value=bills.reduce((s,b)=>s+b.due,0);alloc={};calc()};
    const cl=$('#cl',v);if(cl)cl.onclick=e=>{e.preventDefault();$('#am',v).value='';alloc={};calc();$$('.bp',v).forEach(i=>i.value='')};
    $$('.bp',v).forEach(i=>i.oninput=()=>{alloc[i.dataset.id]=Math.max(0,+i.value||0);$('#am',v).value=Object.values(alloc).reduce((s,x)=>s+x,0)||'';const k=calc();});
    calc();
  };
  $$('#kd button',v).forEach(b=>b.onclick=()=>{kind=b.dataset.k;$$('#kd button',v).forEach(x=>x.classList.toggle('on',x===b));drawBills()});
  $('#cu',v).onchange=()=>{cid=$('#cu',v).value;drawBills()};
  $('#am',v).oninput=()=>{alloc={};calc()};
  $('#dis',v).onclick=()=>location.hash='#/receipts';
  const post=()=>{
    if(!cid){AP.toast('Choose a customer','bad');return}
    const {amt,ap,adv}=calc();if(!(amt>0)){AP.toast('Enter the amount received','bad');return}
    const c=AP.find('customers',cid);
    if(kind==='ret'&&amt>(c.advance||0)){AP.toast('Customer advance is only '+M(c.advance||0),'bad');return}
    const method=$('#ac',v).value,sh=AP.openShift();
    if(method==='cash'&&!sh&&kind!=='ret'){/* allowed — recorded without a counter */}
    bills.forEach(b=>{if(!b.pay)return;const i=AP.find('invoices',b.id);i.due=Math.round((i.due-b.pay)*100)/100;i.paid=(i.paid||0)+b.pay;i.status=i.due>0?'partial':'paid';AP.put('invoices',i)});
    if(kind==='bills'&&adv>0)c.advance=(c.advance||0)+adv;if(kind==='adv')c.advance=(c.advance||0)+amt;if(kind==='ret')c.advance=(c.advance||0)-amt;
    AP.put('customers',c);AP.syncCust(cid);
    const r={id:AP.uid(),no:AP.seq('crc','CRC-'),t:+new Date($('#dd',v).value+'T'+new Date().toTimeString().slice(0,8)),customerId:cid,customerName:c.name,phone:c.phone,type:kind==='bills'?'Due collected':kind==='adv'?'Advance received':'Advance returned',amount:amt,discount:0,method,ref:$('#rf',v).value.trim(),remarks:$('#rm',v).value.trim(),bills:bills.filter(b=>b.pay).map(b=>b.no),shiftId:sh?sh.id:null,by:AP.me().id,byName:AP.me().name,status:'posted'};
    AP.put('receipts',r);AP.toast('Receipt '+r.no+' posted');location.hash='#/receipts';
  };
  $('#post',v).onclick=post;
  const kd=e=>{if(!document.contains(v)||!$('#post',v)){document.removeEventListener('keydown',kd);return}if((e.ctrlKey||e.metaKey)&&e.key==='Enter')post()};document.addEventListener('keydown',kd);
  drawBills();
};

/* ----- SUPPLIERS ----- */
P.suppliers=function(v){
  const form=s=>{s=s||{};const m=AP.modal({title:s.id?'Edit supplier':'Add supplier',body:'<div class="grid g2"><div class="fld"><label class="req">Name</label><input class="inp" id="sn" value="'+E(s.name||'')+'"></div><div class="fld"><label>Mobile</label><input class="inp" id="sp" value="'+E(s.phone||'')+'"></div><div class="fld"><label>Opening payable (৳)</label><input class="inp" type="number" id="sd" value="'+(s.due||'')+'"></div><div class="fld"><label>Address</label><input class="inp" id="sa" value="'+E(s.addr||'')+'"></div></div>',foot:[{label:'Cancel'},{label:'Save',cls:'pri',fn:mm=>{const n=$('#sn',m.el).value.trim();if(!n)return;AP.put('suppliers',Object.assign({on:true},s,{name:n,phone:$('#sp',m.el).value.trim(),addr:$('#sa',m.el).value.trim(),due:+$('#sd',m.el).value||0}));mm.close();AP.refresh()}}]})};
  const pay=s=>{const m=AP.modal({title:'Pay '+E(s.name),sub:'Payable now '+M(s.due),size:'sm',body:'<div class="fld"><label class="req">Amount (৳)</label><input class="inp" type="number" min="0" id="pa" value="'+s.due+'"></div><div class="fld" style="margin-top:10px"><label>From</label><select class="sel" id="pm"><option value="cash">Cash</option><option value="bank">Bank</option><option value="bkash">bKash</option></select></div>',foot:[{label:'Cancel'},{label:'Pay',cls:'pri',fn:mm=>{const a=Math.min(+$('#pa',m.el).value||0,s.due);if(a<=0)return;s.due-=a;AP.put('suppliers',s);AP.put('expenses',{id:AP.uid(),no:AP.seq('exp','EXP-',5),t:Date.now(),cat:'Supplier payment',amount:a,method:$('#pm',m.el).value,note:s.name,by:AP.me().name,drawer:false});mm.close();AP.toast('Paid '+M(a));AP.refresh()}}]})};
  AP.list(v,{title:'Suppliers',unit:'suppliers',rows:()=>AP.all('suppliers'),search:r=>r.name+' '+r.phone,
    actions:p=>{p.innerHTML='<button class="btn" id="a">+ Add supplier</button>';$('#a',p).onclick=()=>form()},
    filters:[{k:'q',type:'text',ph:'Name or mobile',grow:1},{k:'due',label:'Show',opts:()=>[['','All'],['due','With payable']],test:r=>r.due>0}],
    cols:[{h:'Supplier',f:r=>'<b>'+E(r.name)+'</b>'},{h:'Mobile',f:r=>E(r.phone||'—')},{h:'Address',f:r=>E(r.addr||'—')},{h:'Payable',cls:'r num',f:r=>r.due?'<b class="warn">'+M(r.due)+'</b>':M(0)},{h:'',cls:'r',f:r=>(r.due>0?'<button class="btn sm" data-p="'+r.id+'">Pay</button> ':'')+'<button class="btn sm ghost" data-e="'+r.id+'">Edit</button>'}],
    empty:{icon:'<i class="fa-solid fa-truck"></i>',title:'No suppliers yet',text:'Add the people you buy stock from.',btn:'+ Add supplier',fn:()=>form()},
    after:tw=>{$$('[data-e]',tw).forEach(b=>b.onclick=()=>form(AP.find('suppliers',b.dataset.e)));$$('[data-p]',tw).forEach(b=>b.onclick=()=>pay(AP.find('suppliers',b.dataset.p)))}});
};
})();
