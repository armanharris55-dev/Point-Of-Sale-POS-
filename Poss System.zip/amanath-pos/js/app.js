/* Amanath POS — dashboard shell, router, global search, alerts */
(function(){
'use strict';
const me=AP.guard(['owner','manager']);if(!me)return;
const $=AP.$,$$=AP.$$,E=AP.esc;
AP.pages=AP.pages||{};
const I=c=>'<i class="fa-solid fa-'+c+'"></i>';
/* [route, label, icon] ; route '' = group heading */
const NAV=[
 ['','Overview'],['home','Dashboard','gauge-high'],['reports','Reports','chart-column'],
 ['','Sell'],['pos.html','Open POS','cart-shopping'],['invoices','Invoices','receipt'],['returns','Returns','rotate-left'],['counters','Counter sessions','cash-register'],
 ['','People'],['customers','Customers','users'],['receipts','Customer receipts','hand-holding-dollar'],['suppliers','Suppliers','truck-field'],
 ['','Inventory'],['products','Products','box'],['catalog','Product setup','tags'],['stockin','Stock in','boxes-packing'],['stockins','Stock-in history','clock-rotate-left'],
 ['','Money'],['expenses','Expenses','money-bill-transfer'],
 ['','Admin'],['users','Users','user-shield'],['activity','Activity log','list-check'],['settings','Settings','gear']
];
const TITLES={home:['Overview','Dashboard'],reports:['Insights','Reports'],invoices:['Sell','Invoices'],returns:['Sell','Returns'],counters:['Sell','Counter sessions'],customers:['People','Customers'],receipts:['People','Customer receipts'],suppliers:['People','Suppliers'],products:['Inventory','Products'],catalog:['Inventory','Product setup'],stockin:['Inventory','Stock in'],stockins:['Inventory','Stock-in history'],expenses:['Money','Expenses'],users:['Admin','Users'],activity:['Admin','Activity log'],settings:['Admin','Settings']};
const ROUTES=[
 [/^\/home$/,'home'],[/^\/invoices$/,'invoices'],[/^\/returns$/,'returns'],[/^\/counters$/,'counters'],
 [/^\/customers$/,'customers'],[/^\/receipts$/,'receipts'],[/^\/receipts\/new$/,'receiptNew'],[/^\/suppliers$/,'suppliers'],
 [/^\/products$/,'products'],[/^\/products\/new$/,'productForm'],[/^\/products\/edit\/(.+)$/,'productForm'],
 [/^\/catalog(?:\/(\w+))?$/,'catalog'],[/^\/stockin$/,'stockin'],[/^\/stockins$/,'stockins'],
 [/^\/expenses$/,'expenses'],[/^\/reports(?:\/(\w+))?$/,'reports'],[/^\/users$/,'users'],[/^\/activity$/,'activity'],[/^\/settings$/,'settings']
];
function alerts(){
  const cfg=AP.cfg(),P=AP.all('products').filter(p=>p.on!==false&&p.type!=='service');
  const low=P.filter(p=>(+p.stock||0)<=(+p.min||cfg.lowStock||0));
  const soon=P.filter(p=>p.expiry&&+new Date(p.expiry)<Date.now()+30*864e5&&(+p.stock||0)>0);
  const dues=AP.all('customers').filter(c=>AP.custDue(c.id)>0);
  const open=AP.all('shifts').filter(s=>!s.closedAt);
  const review=AP.all('shifts').filter(s=>s.closedAt&&s.diff&&!s.reviewed);
  return{low,soon,dues,open,review};
}
AP.alerts=alerts;
function buildSide(){
  const a=alerts();const badge={products:a.low.length,customers:a.dues.length,counters:a.review.length};
  $('#side').innerHTML=NAV.map(n=>n[0]===''?'<div class="gh">'+n[1]+'</div>':'<a href="'+(n[0].endsWith('.html')?n[0]:'#/'+n[0])+'" data-r="'+n[0]+'" title="'+n[1]+'"><span class="ic">'+I(n[2])+'</span><span class="t">'+n[1]+'</span>'+(badge[n[0]]?'<span class="n">'+badge[n[0]]+'</span>':'')+'</a>').join('');
  const bn=a.low.length+a.soon.length+a.review.length;const b=$('#bn');b.textContent=bn;b.classList.toggle('hide',!bn);
}
function route(){
  const raw=location.hash.replace(/^#/,'')||'/home';const h=raw.split('?')[0];AP.q=new URLSearchParams(raw.split('?')[1]||'');
  let hit=null;
  for(const [re,fn] of ROUTES){const m=h.match(re);if(m){hit=[fn,m.slice(1)];break}}
  if(!hit){location.hash='#/home';return}
  const first=h.split('/')[1];
  buildSide();$$('#side a').forEach(a=>a.classList.toggle('on',a.dataset.r===first));
  const t=TITLES[first]||['Overview','Dashboard'];$('#pt').textContent=t[1];$('#shopname').textContent=t[0];
  const v=$('#view');v.innerHTML='';window.scrollTo(0,0);
  try{AP.pages[hit[0]](v,...hit[1])}catch(e){console.error(e);v.innerHTML='<div class="card pad"><h3>Something went wrong</h3><p class="muted">'+E(e.message)+'</p></div>'}
  document.title=t[1]+' — Amanath POS';document.body.classList.remove('sd');
}
window.addEventListener('hashchange',route);
AP.go=h=>{if(location.hash==='#'+h)route();else location.hash='#'+h};
AP.refresh=route;
/* header */
$('#av').textContent=AP.avatar(me.name);$('#mn').textContent=me.name;$('#mr').textContent=me.role[0].toUpperCase()+me.role.slice(1);
$('#lo').onclick=AP.logout;
$('#burger').onclick=()=>{if(innerWidth<=960)document.body.classList.toggle('sd');else{document.body.classList.toggle('nosd');try{AP.set('nosd',document.body.classList.contains('nosd'))}catch(e){}}};
if(AP.get('nosd')&&innerWidth>960)document.body.classList.add('nosd');
document.addEventListener('mousedown',e=>{if(document.body.classList.contains('sd')&&!e.target.closest('#sb,#burger'))document.body.classList.remove('sd')});
$('#theme').onclick=()=>{AP.toggleTheme()};
$('#newb').onclick=()=>AP.pop($('#newb'),'<a href="pos.html" data-a="x">'+I('cart-shopping')+' New sale</a><a href="#/products/new" data-a="x">'+I('box')+' Add product</a><a href="#/stockin" data-a="x">'+I('boxes-packing')+' Stock in</a><a href="#/receipts/new" data-a="x">'+I('hand-holding-dollar')+' Receive money</a><a href="#/customers?new=1" data-a="c">'+I('user-plus')+' Add customer</a><button data-a="e">'+I('money-bill-transfer')+' Add expense</button>',a=>{if(a==='e')AP.expenseForm(()=>AP.refresh());if(a==='c')AP.customerForm()});
$('#bell').onclick=()=>{
  const a=alerts();let h='';
  if(a.low.length)h+='<a href="#/reports/low" data-a="x">'+I('arrow-trend-down')+' <span><b>'+a.low.length+'</b> items low on stock</span></a>';
  if(a.soon.length)h+='<a href="#/reports/expiry" data-a="x">'+I('hourglass-half')+' <span><b>'+a.soon.length+'</b> expiring in 30 days</span></a>';
  if(a.dues.length)h+='<a href="#/reports/due" data-a="x">'+I('credit-card')+' <span><b>'+a.dues.length+'</b> customers have due</span></a>';
  if(a.review.length)h+='<a href="#/counters?t=r" data-a="x">'+I('cash-register')+' <span><b>'+a.review.length+'</b> shifts need review</span></a>';
  if(a.open.length)h+='<a href="#/counters" data-a="x">'+I('circle')+' <span><b>'+a.open.length+'</b> counter(s) open now</span></a>';
  AP.pop($('#bell'),h||'<div class="muted" style="padding:14px">'+I('circle-check')+' All clear</div>',()=>{});
};
/* global search (Ctrl+K) */
function gsearch(){
  const m=AP.modal({title:'Search',size:'lg',body:'<div class="srch"><input class="inp" id="gq" placeholder="Page, product, customer or invoice no…" autocomplete="off"></div><div id="gr" style="margin-top:10px;max-height:52vh;overflow:auto"></div>'});
  const gr=$('#gr',m.el),gq=$('#gq',m.el);let sel=0;
  const draw=()=>{
    const q=gq.value.trim().toLowerCase();let items=[];
    NAV.filter(n=>n[0]!==''&&(!q||n[1].toLowerCase().includes(q))).forEach(n=>items.push({i:n[2],t:n[1],s:'Page',h:n[0].endsWith('.html')?n[0]:'#/'+n[0]}));
    if(q.length>=2){
      AP.all('products').filter(p=>(p.name+' '+p.sku+' '+(p.mfr||'')).toLowerCase().includes(q)).slice(0,6).forEach(p=>items.push({i:'box',t:p.name,s:'Product · '+AP.money(p.price)+' · stock '+p.stock,h:'#/products/edit/'+p.id}));
      AP.all('customers').filter(c=>(c.name+' '+c.phone+' '+c.code).toLowerCase().includes(q)).slice(0,5).forEach(c=>items.push({i:'user',t:c.name,s:'Customer · '+c.phone,h:'#/customers?q='+encodeURIComponent(c.phone)}));
      AP.all('invoices').filter(i=>i.no.toLowerCase().includes(q)).slice(0,4).forEach(i=>items.push({i:'receipt',t:i.no,s:'Invoice · '+AP.money(i.total),h:'#/invoices?q='+i.no}));
    }
    sel=Math.min(sel,Math.max(0,items.length-1));
    gr.innerHTML=items.map((x,k)=>'<a href="'+x.h+'" style="display:flex;gap:12px;align-items:center;padding:9px 11px;border-radius:9px;color:var(--ink);text-decoration:none;'+(k===sel?'background:var(--mint2)':'')+'"><span style="width:26px;text-align:center;color:var(--mintd)">'+I(x.i)+'</span><b>'+E(x.t)+'</b><span class="muted" style="margin-left:auto;font-size:12px">'+E(x.s)+'</span></a>').join('')||'<div class="muted c" style="padding:20px">No matches</div>';
    gr._items=items;
  };
  gq.oninput=()=>{sel=0;draw()};
  gq.onkeydown=e=>{const n=(gr._items||[]).length;if(e.key==='ArrowDown'){sel=(sel+1)%n;draw();e.preventDefault()}else if(e.key==='ArrowUp'){sel=(sel-1+n)%n;draw();e.preventDefault()}else if(e.key==='Enter'&&gr._items[sel]){location.hash=gr._items[sel].h;m.close()}};
  gr.onclick=()=>m.close();draw();
}
$('#gsb').onclick=gsearch;
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();gsearch()}});
AP.gsearch=gsearch;
route();
})();
