/* Dashboard pages: home, invoices, returns, counters */
(function(){
const P=AP.pages=AP.pages||{};const $=AP.$,$$=AP.$$,E=AP.esc,M=AP.money;
const PAY={cash:'Cash',card:'Card',mobile:'Mobile',bank:'Bank',gift:'Gift',advance:'Advance',due:'Due',multiple:'Multiple'};
const payLabel=i=>{const m=[...new Set((i.pay||[]).map(p=>p.m))];return m.length>1?'Multiple':m.length?PAY[m[0]]:'Due'};
AP.payLabel=payLabel;AP.PAY=PAY;

/* ----- invoice modal (shared) ----- */
AP.showInvoice=function(inv,after){
  const cfg=AP.cfg();
  const m=AP.modal({title:'Invoice',size:'lg',body:AP.invHTML(inv),foot:[
    {label:'<i class="fa-solid fa-print"></i> Reprint 80 mm',fn:()=>AP.printInv(inv,'80')},{label:'<i class="fa-solid fa-file-lines"></i> Reprint A4',fn:()=>AP.printInv(inv,'a4')},
    inv.customerId&&AP.find('customers',inv.customerId)&&cfg.wa?{label:'WhatsApp',fn:()=>{const c=AP.find('customers',inv.customerId);window.open(AP.waLink(c.phone,cfg.shop.name+' — Invoice '+inv.no+'\nTotal: '+M(inv.total)+(inv.due?'\nDue: '+M(inv.due):'')+'\nThank you!'),'_blank')}}:{label:'',fn:()=>{}},
    {label:'<i class="fa-solid fa-rotate-left"></i> Return',fn:mm=>{mm.close();P.returnForm(inv,after)}},{label:'Close',cls:'pri'}].filter(b=>b.label)});
};

/* ----- HOME ----- */
const I=c=>'<i class="fa-solid fa-'+c+'"></i>';
const dl=(c,p,inv)=>{const d=AP.an.delta(c,p);const z=Math.abs(d)<.5;return'<span class="dlt '+(z?'z':(d>0)!==!!inv?'up':'dn')+'">'+(z?'':'<i class="fa-solid fa-arrow-'+(d>0?'up':'down')+'" style="font-size:9px"></i>')+AP.n(Math.abs(d),0)+'%</span>'};
AP.dl=dl;
P.home=function(v){
  const an=AP.an;let per=AP.get('home_per','7d');
  const draw=()=>{
    const [a,b]=an.range(per),[pa,pb]=an.prev(a,b);
    const cur=an.sum(a,b),prv=an.sum(pa,pb),days=an.days(a,b);
    const daily=an.daily(a,Math.min(b,a+92*864e5));
    const prods=AP.all('products'),al=AP.alerts(),cfg=AP.cfg();
    const dueAll=AP.all('customers').reduce((s,c)=>s+AP.custDue(c.id),0),payable=AP.all('suppliers').reduce((s,x)=>s+(x.due||0),0);
    const open=AP.all('shifts').filter(s=>!s.closedAt);const cashNow=open.reduce((s,x)=>s+AP.shiftCash(x.id).expected,0);
    const sv=an.stockValue(),svSell=prods.filter(p=>p.type!=='service').reduce((s,p)=>s+(+p.stock||0)*(+p.price||0),0);
    const R=an.rows(a,b);
    const cat=an.items(a,b,(l,p)=>p.cat?AP.catName(p.cat):'Uncategorised').filter(x=>x.r>0).sort((x,y)=>y.r-x.r);
    const catParts=cat.slice(0,5).map(x=>({l:x.k,v:x.r}));if(cat.length>5)catParts.push({l:'Others',v:cat.slice(5).reduce((s,x)=>s+x.r,0)});
    const items=an.items(a,b).sort((x,y)=>y.r-x.r).slice(0,6);
    const pm={};R.inv.forEach(i=>(i.pay||[]).forEach(p=>{const k=AP.PAY[p.m]||p.m;pm[k]=(pm[k]||0)+p.amt-(p.m==='cash'?i.change||0:0)}));if(cur.due>0)pm['Due']=cur.due;if(cur.man>0)pm['Manual sales']=cur.man;
    const pmParts=Object.keys(pm).filter(k=>pm[k]>0).map(k=>({l:k,v:pm[k]}));
    const hr=an.hourly(a,b);
    const cu={};R.inv.filter(i=>i.customerId).forEach(i=>{const x=cu[i.customerId]||(cu[i.customerId]={n:i.customerName,r:0,k:0});x.r+=i.total;x.k++});
    const topC=Object.values(cu).sort((x,y)=>y.r-x.r).slice(0,5);
    const todayS=an.sum(AP.day0(),AP.day0()+864e5),tgt=+cfg.target||0;
    const hour=new Date().getHours();const g=hour<12?'Good morning':hour<17?'Good afternoon':'Good evening';
    const lab=daily.map(d=>{const x=new Date(d.d);return x.getDate()+'/'+(x.getMonth()+1)});
    const log=AP.get('log',[]).slice(0,8);
    const fi={sale:['receipt',''],return:['rotate-left','r'],stockin:['boxes-packing','k'],shift:['cash-register','s'],receipt:['hand-holding-dollar',''],expense:['money-bill-transfer','s'],manual:['pen-to-square','s']};
    v.innerHTML='<div class="row w" style="margin-bottom:18px"><div class="sp"><h1 style="margin:0;font-size:26px;letter-spacing:-.02em">'+g+', '+E(AP.me().name.split(' ')[0])+'</h1><div class="muted">Here is how <b>'+E(cfg.shop.name)+'</b> is doing.</div></div><div class="chips" id="per">'+[['today','Today'],['yest','Yesterday'],['7d','7 days'],['30d','30 days'],['mtd','This month'],['lm','Last month']].map(x=>'<button data-p="'+x[0]+'" class="'+(per===x[0]?'on':'')+'">'+x[1]+'</button>').join('')+'</div></div>'
    +(!prods.length?'<div class="card pad" style="margin-bottom:18px;background:var(--mint2);border-color:var(--ink)"><div class="row w"><div class="sp"><b>Your shop is empty — start here</b><div class="muted">Add your first product, or load sample data to explore every screen.</div></div><a class="btn" href="#/products/new">'+I('plus')+' Add product</a><button class="btn ghost" id="demo">'+I('wand-magic-sparkles')+' Load demo data</button></div></div>':'')
    +'<div class="grid g4" style="margin-bottom:16px">'
    +'<div class="card kpi2 hero"><div class="k"><i class="fa-solid fa-sack-dollar"></i>Net sales</div><div class="v">'+M(cur.net)+'</div><div class="s">'+dl(cur.net,prv.net)+' vs previous · '+cur.n+' invoices</div><span class="sk">'+AP.chart.spark(daily.map(d=>d.net),'currentColor')+'</span></div>'
    +'<div class="card kpi2"><div class="k"><i class="fa-solid fa-chart-line"></i>Gross profit</div><div class="v">'+M(cur.gp)+'</div><div class="s">'+dl(cur.gp,prv.gp)+' · margin '+AP.n(cur.margin,1)+'%</div><span class="sk">'+AP.chart.spark(daily.map(d=>d.gp))+'</span></div>'
    +'<div class="card kpi2"><div class="k"><i class="fa-solid fa-scale-balanced"></i>Net profit</div><div class="v '+(cur.np<0?'bad':'')+'">'+M(cur.np)+'</div><div class="s">'+dl(cur.np,prv.np)+' · expenses '+M(cur.exp)+'</div></div>'
    +'<div class="card kpi2"><div class="k"><i class="fa-solid fa-basket-shopping"></i>Avg. basket</div><div class="v">'+M(cur.basket)+'</div><div class="s">'+dl(cur.basket,prv.basket)+' · '+AP.n(cur.qty,0)+' items sold</div></div></div>'
    +'<div class="grid g4" style="margin-bottom:16px">'
    +'<div class="card kpi2"><div class="k"><i class="fa-solid fa-cash-register"></i>Cash in counters</div><div class="v">'+M(cashNow)+'</div><div class="s">'+open.length+' counter(s) open</div></div>'
    +'<div class="card kpi2"><div class="k"><i class="fa-solid fa-hand-holding-dollar"></i>Customers owe you</div><div class="v '+(dueAll?'bad':'')+'">'+M(dueAll)+'</div><div class="s"><a href="#/reports/due">'+al.dues.length+' customers · view</a></div></div>'
    +'<div class="card kpi2"><div class="k"><i class="fa-solid fa-truck-field"></i>You owe suppliers</div><div class="v '+(payable?'warn':'')+'">'+M(payable)+'</div><div class="s"><a href="#/reports/payable">view payable</a></div></div>'
    +'<div class="card kpi2"><div class="k"><i class="fa-solid fa-warehouse"></i>Stock value</div><div class="v">'+M(sv)+'</div><div class="s">Worth '+M(svSell)+' at selling price</div></div></div>'
    +'<div class="grid" style="grid-template-columns:2fr 1fr;margin-bottom:16px" id="g1"><div class="card pad"><div class="ch"><h3>Sales &amp; profit</h3><span class="sub">'+days+' day'+(days>1?'s':'')+'</span></div>'+(daily.length>1?AP.chart.line(lab,[{name:'Net sales',color:'var(--mintd)',vals:daily.map(d=>d.net),area:1},{name:'Gross profit',color:'var(--acc)',vals:daily.map(d=>d.gp)}]):'<p class="muted">Pick a longer period to see the trend.</p>')+'<div class="row" style="margin-top:6px;font-size:12.5px"><span class="row"><i style="width:10px;height:10px;border-radius:3px;background:var(--mintd)"></i>Net sales</span><span class="row"><i style="width:10px;height:10px;border-radius:3px;background:var(--acc)"></i>Gross profit</span></div></div>'
    +'<div class="card pad"><div class="ch"><h3>Daily target</h3></div>'+(tgt?'<div style="font-size:28px;font-weight:800;letter-spacing:-.02em">'+M(todayS.net)+'</div><div class="muted" style="margin-bottom:10px">of '+M(tgt)+' target today</div><div class="prog"><i style="width:'+Math.min(100,todayS.net/tgt*100)+'%"></i></div><div class="muted" style="margin-top:8px">'+(todayS.net>=tgt?'<span class="ok"><i class="fa-solid fa-circle-check"></i> Target reached!</span>':M(tgt-todayS.net)+' to go')+'</div>':'<p class="muted" style="margin-top:0">Set a daily sales target and track it live here.</p><a class="btn sm" href="#/settings">Set target</a>')
    +'<hr style="border:0;border-top:1px solid var(--line);margin:16px 0"><div class="ch"><h3>Payment mix</h3></div>'+(pmParts.length?AP.chart.donut(pmParts):'<p class="muted">No payments yet.</p>')+'</div></div>'
    +'<div class="grid g3" style="margin-bottom:16px"><div class="card pad"><div class="ch"><h3>Peak hours</h3><span class="sub">sales by hour</span></div>'+AP.chart.bars([...Array(24)].map((_,i)=>i%12===0?(i===0?'12a':'12p'):String(i%12)),hr.h,{h:170,step:3,hot:(i,v)=>v===Math.max(...hr.h)&&v>0?'var(--acc)':null})+'</div>'
    +'<div class="card pad"><div class="ch"><h3>Sales by category</h3></div>'+(catParts.length?AP.chart.donut(catParts):'<p class="muted">No sales in this period.</p>')+'</div>'
    +'<div class="card pad"><div class="ch"><h3>Top items</h3><a href="#/reports/items">All</a></div>'+(items.length?AP.chart.hbars(items.map(x=>({l:x.n,v:x.r}))):'<p class="muted">No sales in this period.</p>')+'</div></div>'
    +'<div class="grid g3" style="margin-bottom:16px"><div class="card pad"><div class="ch"><h3>Top customers</h3></div>'+(topC.length?'<div class="feed">'+topC.map((x,k)=>'<div><span class="fi">'+(k+1)+'</span><div class="sp"><b>'+E(x.n)+'</b><small>'+x.k+' bill'+(x.k>1?'s':'')+'</small></div><b>'+M(x.r)+'</b></div>').join('')+'</div>':'<p class="muted">No customer sales yet.</p>')+'</div>'
    +'<div class="card pad"><div class="ch"><h3>Low stock</h3>'+(al.low.length?'<a href="#/stockin?low=1" class="btn sm">'+I('boxes-packing')+' Reorder</a>':'')+'</div>'+(al.low.length?'<div class="feed">'+al.low.slice(0,5).map(p=>'<div><span class="fi s">'+I('triangle-exclamation')+'</span><div class="sp"><b>'+E(p.name)+'</b><small>alert at '+(p.min||cfg.lowStock)+'</small></div><b class="'+(p.stock<=0?'bad':'warn')+'">'+AP.n(p.stock,0)+'</b></div>').join('')+'</div>':'<p class="muted">Stock levels look healthy.</p>')+'</div>'
    +'<div class="card pad"><div class="ch"><h3>Expiring soon</h3><a href="#/reports/expiry">All</a></div>'+(al.soon.length?'<div class="feed">'+al.soon.slice(0,5).map(p=>'<div><span class="fi r">'+I('hourglass-half')+'</span><div class="sp"><b>'+E(p.name)+'</b><small>stock '+p.stock+'</small></div><b>'+E(p.expiry)+'</b></div>').join('')+'</div>':'<p class="muted">Nothing expiring in 30 days.</p>')+'</div></div>'
    +'<div class="grid g2"><div class="card pad"><div class="ch"><h3>Recent activity</h3><a href="#/activity">All</a></div>'+(log.length?'<div class="feed">'+log.map(l=>{const f=fi[l.type]||['circle-info','k'];return'<div><span class="fi '+f[1]+'">'+I(f[0])+'</span><div class="sp"><b>'+E(l.msg)+'</b><small>'+E(l.by)+' · '+AP.dt(l.t)+'</small></div></div>'}).join('')+'</div>':'<p class="muted">Activity will appear here.</p>')+'</div>'
    +'<div class="card pad"><div class="ch"><h3>Quick actions</h3></div><div class="qa"><a href="pos.html"><i class="fa-solid fa-cart-shopping"></i>New sale</a><a href="#/products/new"><i class="fa-solid fa-plus"></i>Add product</a><a href="#/stockin"><i class="fa-solid fa-boxes-packing"></i>Stock in</a><a href="#/receipts/new"><i class="fa-solid fa-hand-holding-dollar"></i>Receive money</a><a href="#/reports"><i class="fa-solid fa-chart-column"></i>Reports</a><a href="#/counters"><i class="fa-solid fa-cash-register"></i>Counters</a></div></div></div>';
    $$('#per button',v).forEach(x=>x.onclick=()=>{per=x.dataset.p;AP.set('home_per',per);draw()});
    const d=$('#demo',v);if(d)d.onclick=()=>{AP.seedDemo();AP.refresh()};
    if(innerWidth<960)$$('#g1',v).forEach(x=>x.style.gridTemplateColumns='1fr');
  };
  draw();
};

/* ----- INVOICES ----- */
P.invoices=function(v){
  AP.list(v,{title:'Invoices',info:'Every bill made at the POS. Click an invoice number to view or reprint.',unit:'invoices',
    rows:()=>AP.all('invoices').sort((a,b)=>b.t-a.t),search:r=>r.no+' '+r.customerName+' '+((AP.find('customers',r.customerId)||{}).phone||''),date:r=>r.t,
    actions:p=>{p.innerHTML='<button class="btn ghost" id="x"><i class="fa-solid fa-file-csv"></i> CSV</button>';$('#x',p).onclick=()=>AP.csv('invoices.csv',[['Invoice','Date','Customer','Sold by','Payment','Total','Due']].concat(AP.all('invoices').map(i=>[i.no,AP.dt(i.t),i.customerName,i.byName,payLabel(i),i.total,i.due])))},
    filters:[{k:'q',type:'text',ph:'Invoice no., customer or phone',grow:1},{k:'from',type:'date',label:'From'},{k:'to',type:'date',label:'To'},
      {k:'cust',label:'Customer',opts:()=>[['','All'],['walk','Walk-in'],['reg','Registered']],test:(r,v)=>v==='walk'?!r.customerId:!!r.customerId},
      {k:'by',label:'Sold by',opts:()=>[['','All']].concat([...new Set(AP.all('invoices').map(i=>i.byName))].map(n=>[n,n])),test:(r,v)=>r.byName===v},
      {k:'pay',label:'Payment',opts:()=>[['','All'],['cash','Cash'],['card','Card'],['mobile','Mobile'],['due','Due']],test:(r,v)=>v==='due'?r.due>0:(r.pay||[]).some(p=>p.m===v)}],
    cols:[{h:'Invoice',f:r=>'<a href="#" class="inv" data-id="'+r.id+'">'+r.no+'</a>'},{h:'Date and time',f:r=>AP.dt(r.t)},{h:'Customer',f:r=>E(r.customerName)+(r.customerCat?' <span class="muted">· '+E(r.customerCat)+'</span>':'')},
      {h:'Sold by',f:r=>E(r.byName)},{h:'Paid by',f:r=>payLabel(r)},{h:'Total',cls:'r num',f:r=>AP.n(r.total)},{h:'Payment',f:r=>r.returned&&r.returned>=r.total?'<span class="tag warn">Returned</span>':r.due>0?'<span class="tag warn">Due '+AP.n(r.due)+'</span>':'<span class="tag ok">Paid</span>'}],
    empty:{icon:'<i class="fa-solid fa-receipt"></i>',title:'No invoices yet',text:'Sales made at the POS appear here.',btn:'Open POS',fn:()=>location.href='pos.html'},
    after:tw=>{$$('a.inv',tw).forEach(a=>a.onclick=e=>{e.preventDefault();AP.showInvoice(AP.find('invoices',a.dataset.id),()=>AP.refresh())})}});
};

/* ----- RETURNS ----- */
P.returnForm=function(inv,after){
  if(!inv){
    const m=AP.modal({title:'New return',sub:'Find the invoice first',body:'<div class="fld"><label>Invoice number</label><input class="inp mono" id="rn" placeholder="INV-000123"></div><div id="rl" style="margin-top:10px"></div>',foot:[{label:'Cancel'},{label:'Find invoice',cls:'pri',fn:mm=>{const q=$('#rn',m.el).value.trim().toUpperCase();const i=AP.all('invoices').find(x=>x.no===q||x.no==='INV-'+q.replace(/\D/g,'').padStart(6,'0'));if(!i){$('#rl',m.el).innerHTML='<div class="alert bad">No invoice found.</div>';return}mm.close();P.returnForm(i,after)}}]});
    $('#rn',m.el).onkeydown=e=>{if(e.key==='Enter')$('.btn.pri',m.el).click()};return}
  const lines=inv.items.map(l=>({...l,left:l.qty-(l.ret||0),net:(l.price*l.qty-l.disc)/l.qty*(1-(inv.invDisc&&inv.sub?inv.invDisc/inv.sub:0))})).filter(l=>l.left>0);
  if(!lines.length){AP.toast('Everything on this invoice is already returned','bad');return}
  const m=AP.modal({title:'Return — '+inv.no,sub:E(inv.customerName)+' · '+AP.dt(inv.t),size:'lg',body:
    '<div class="tw card"><table class="t"><thead><tr><th>Item</th><th class="r">Sold</th><th class="r">Net price</th><th style="width:110px">Return qty</th></tr></thead><tbody>'+lines.map((l,i)=>'<tr><td>'+E(l.name)+'</td><td class="r">'+l.left+'</td><td class="r">'+AP.n(l.net)+'</td><td><input class="inp rq" type="number" min="0" max="'+l.left+'" step="1" value="0" data-i="'+i+'"></td></tr>').join('')+'</tbody></table></div>'
    +'<div class="grid g2" style="margin-top:12px"><div class="fld"><label>Refund by</label><select class="sel" id="rm"><option value="cash">Cash from drawer</option><option value="advance"'+(inv.customerId?'':' disabled')+'>Keep as customer advance</option><option value="due"'+(inv.due>0?'':' disabled')+'>Reduce invoice due</option></select></div><div class="fld"><label>Reason</label><select class="sel" id="rr"><option>Customer changed mind</option><option>Damaged / defective</option><option>Wrong item</option><option>Expired</option><option>Other</option></select></div></div>'
    +'<div class="row" style="margin-top:14px"><span class="sp lbl">Refund total</span><b style="font-size:22px" id="rt">৳0.00</b></div>',
    foot:[{label:'Cancel'},{label:'Post return',cls:'acc',fn:mm=>{
      const items=$$('.rq',m.el).map(i=>{const l=lines[+i.dataset.i];return{pid:l.pid,name:l.name,qty:Math.min(l.left,Math.max(0,+i.value||0)),net:l.net}});
      const r=AP.makeReturn({invoice:inv,items,method:$('#rm',m.el).value,reason:$('#rr',m.el).value,user:AP.me()});
      if(r.err){AP.toast(r.err,'bad');return}mm.close();AP.toast('Return '+r.ret.no+' posted — refund '+M(r.ret.refund));if(after)after();else AP.refresh()}}]});
  m.el.addEventListener('input',()=>{let t=0;$$('.rq',m.el).forEach(i=>{const l=lines[+i.dataset.i];t+=Math.min(l.left,Math.max(0,+i.value||0))*l.net});$('#rt',m.el).textContent=M(t)});
};
P.returns=function(v){
  AP.list(v,{title:'Returns',info:'Returns made at the POS or here show up in this list.',unit:'returns',
    rows:()=>AP.all('returns').sort((a,b)=>b.t-a.t),search:r=>r.no+' '+r.invoiceNo+' '+r.customerName,date:r=>r.t,
    actions:p=>{p.innerHTML='<button class="btn" id="n">+ New return</button>';$('#n',p).onclick=()=>P.returnForm(null)},
    filters:[{k:'q',type:'text',ph:'Return no., bill no. or customer',grow:1},{k:'from',type:'date',label:'From'},{k:'to',type:'date',label:'To'}],
    cols:[{h:'Return',f:r=>'<b class="mono">'+r.no+'</b><div class="muted">'+AP.d(r.t)+'</div>'},{h:'Bill',f:r=>'<span class="mono">'+r.invoiceNo+'</span>'},{h:'Customer',f:r=>E(r.customerName)},{h:'Items',f:r=>r.items.map(i=>E(i.name)+' ×'+i.qty).join(', ')},{h:'Refund',cls:'r num',f:r=>AP.n(r.refund)},{h:'Method',f:r=>PAY[r.method]||r.method},{h:'Reason',f:r=>E(r.reason)},{h:'By',f:r=>E(r.byName)}],
    empty:{icon:'<i class="fa-solid fa-rotate-left"></i>',title:'No returns yet',text:'Returns made at the POS or here show up in this list.',btn:'+ New return',fn:()=>P.returnForm(null)}});
};

/* ----- COUNTERS ----- */
AP.countModal=function(title,sub,expected,onDone,okLabel,opt){
  opt=opt||{};const D=[1000,500,200,100,50,20,10,5,2,1];let mode='notes';
  const m=AP.modal({title,sub,size:'lg',sticky:!!opt.sticky,body:
    '<div class="grid g4" id="ct" style="margin-bottom:12px"></div>'+(opt.extra||'')
    +'<div class="row" style="margin:6px 0 8px"><div class="lbl req sp">Counted cash</div><div class="seg"><button data-md="notes" class="on">By notes</button><button data-md="total">Total</button></div></div>'
    +'<div class="grid g2" id="nt">'+D.map(d=>'<div class="row"><b class="mono" style="width:60px">৳'+AP.n(d,0)+'</b><span class="muted">×</span><input class="inp dn" type="number" min="0" data-d="'+d+'" placeholder="0"></div>').join('')+'</div>'
    +'<div class="fld hide" id="tt"><label>Total counted (৳)</label><input class="inp" type="number" min="0" id="tv" placeholder="0.00"></div>'
    +'<div class="row" style="margin-top:14px"><span class="lbl">Total</span><b id="tc" style="font-size:20px">—</b><span class="sp"></span><span class="lbl">Difference</span><b id="df" style="font-size:20px">—</b></div>',
    foot:[{label:opt.backLabel||'Back',fn:opt.onBack?(mm=>{opt.onBack(mm)}):undefined},{label:okLabel||'Confirm',cls:'pri',fn:mm=>{const c=get();if(c==null){AP.toast('Count the cash first','bad');return}onDone(c,mm,m.el)}}]});
  const get=()=>{if(mode==='total'){const v=$('#tv',m.el).value;return v===''?null:+v}const a=$$('.dn',m.el);if(a.every(i=>i.value===''))return null;return a.reduce((s,i)=>s+(+i.value||0)*+i.dataset.d,0)};
  const exp=()=>opt.expectedFn?opt.expectedFn(m.el):expected;
  const upd=()=>{const c=get();$('#tc',m.el).textContent=c==null?'—':M(c);const ex=exp();if(opt.onUpd)opt.onUpd(m.el,ex);if(ex==null){$('#df',m.el).textContent='';return}const d=c==null?null:Math.round((c-ex)*100)/100;const e=$('#df',m.el);e.textContent=d==null?'—':(d>0?'+':'')+AP.n(d);e.className=d==null||d===0?'':d<0?'bad':'warn'};
  m.el.addEventListener('input',upd);
  $$('[data-md]',m.el).forEach(b=>b.onclick=()=>{mode=b.dataset.md;$$('[data-md]',m.el).forEach(x=>x.classList.toggle('on',x===b));$('#nt',m.el).classList.toggle('hide',mode!=='notes');$('#tt',m.el).classList.toggle('hide',mode!=='total');upd()});
  m.upd=upd;return m;
};
AP.zReport=function(s){
  const c=AP.shiftCash(s.id),inv=AP.all('invoices').filter(i=>i.shiftId===s.id),ctr=AP.find('counters',s.counterId)||{name:'—'};
  const tot=inv.reduce((a,i)=>a+i.total,0);
  const rows=[['Opening cash',c.open],['Cash sales',c.sales],['Manual sales',c.manual],['Dues collected',c.recv],['Cash in',c.in],['Refunds',-c.ref],['Expenses',-c.exp],['Cash out',-c.out],['Expected cash',s.expected],['Counted cash',s.counted],['Difference',s.diff]];
  const html='<!doctype html><meta charset=utf-8><title>Shift '+s.no+'</title><style>body{font:12px system-ui,Arial;margin:0;padding:3mm;width:72mm}h1{font-size:15px;text-align:center;margin:0}td{padding:2px 0}.r{text-align:right}hr{border:0;border-top:1px dashed #000}.b td{font-weight:700;border-top:1px solid #000}</style><h1>'+E(AP.cfg().shop.name)+'</h1><div style="text-align:center">SHIFT REPORT · '+s.no+'</div><hr><div>Counter: '+E(ctr.name)+'<br>Cashier: '+E(s.byName)+'<br>Opened: '+AP.dt(s.openedAt)+'<br>Closed: '+AP.dt(s.closedAt)+'</div><hr><table width=100%>'+rows.map((r,i)=>'<tr class="'+(i>=8?'b':'')+'"><td>'+r[0]+'</td><td class=r>'+AP.n(r[1])+'</td></tr>').join('')+'</table><hr><div>Invoices: '+inv.length+' · Sales: '+AP.n(tot)+'</div>';
  const fr=document.createElement('iframe');fr.style.cssText='position:fixed;width:0;height:0;border:0';document.body.appendChild(fr);fr.contentDocument.open();fr.contentDocument.write(html);fr.contentDocument.close();
  setTimeout(()=>{try{fr.contentWindow.print()}catch(e){}setTimeout(()=>fr.remove(),3000)},200);
};
AP.closeShift=function(sid,cb,force){
  const s=AP.find('shifts',sid),c=AP.shiftCash(sid);
  const extra='<div class="card pad" style="margin-bottom:14px;background:var(--bg)"><div class="row" style="margin-bottom:8px"><b class="sp"><i class="fa-solid fa-pen-to-square"></i> Manual sales <span class="muted" style="font-weight:400">(sold on paper / without the POS)</span></b></div><div class="grid g2"><div class="fld"><label>Manual sales amount (৳)</label><input class="inp" type="number" min="0" step="0.01" id="msa" placeholder="0.00" value="'+(c.manual||'')+'"></div><div class="fld"><label>Note</label><input class="inp" id="msn" placeholder="e.g. rush hour, bill book no. 12"></div></div><div class="hint muted" style="margin-top:6px;font-size:12px">Counted as cash received into this drawer. Shown in reports as “Manual sales”.</div></div>';
  const m=AP.countModal('Close shift '+s.no,'Count the cash in the drawer.',null,(counted,mm,el)=>{
    const man=+$('#msa',el).value||0;const base=AP.shiftCash(sid);
    const exMan=Math.max(0,man-(base.manual||0));
    if(exMan>0)AP.put('manualsales',{id:AP.uid(),t:Date.now(),shiftId:sid,amount:exMan,note:$('#msn',el).value.trim(),by:AP.me().name});
    const cc=AP.shiftCash(sid);
    s.closedAt=Date.now();s.counted=counted;s.expected=cc.expected;s.diff=Math.round((counted-cc.expected)*100)/100;s.manual=cc.manual;s.closedBy=AP.me().id;s.force=!!force;s.reviewed=s.diff===0;AP.put('shifts',s);
    AP.log('shift','Shift '+s.no+' closed · counted '+M(counted)+(s.diff?' · diff '+AP.n(s.diff):''),s.no);
    mm.close();AP.toast('Shift closed'+(s.diff?' — difference '+AP.n(s.diff):''));
    const z=AP.modal({title:'Shift closed',size:'sm',sticky:true,body:'<div class="alist"><div><span class="sp">Expected</span><b>'+M(s.expected)+'</b></div><div><span class="sp">Counted</span><b>'+M(s.counted)+'</b></div><div><span class="sp">Difference</span><b class="'+(s.diff<0?'bad':s.diff>0?'warn':'ok')+'">'+(s.diff>0?'+':'')+AP.n(s.diff)+'</b></div></div>',foot:[{label:'<i class="fa-solid fa-print"></i> Print shift report',fn:()=>AP.zReport(s)},{label:'Done',cls:'pri',fn:mz=>{mz.close();if(cb)cb(s)}}],onClose:()=>{}});
  },'Close shift',{extra,expectedFn:el=>{const base=AP.shiftCash(sid);const man=+$('#msa',el).value||0;return base.expected+Math.max(0,man-(base.manual||0))},onUpd:(el,ex)=>{const b=AP.shiftCash(sid);const man=Math.max(+$('#msa',el).value||0,b.manual||0);$('#ct',el).innerHTML=[['Start (counted)',b.open],['Cash in',b.sales+b.recv+b.in+man],['Cash out',b.ref+b.exp+b.out],['Expected',ex]].map((x,i)=>'<div><div class="lbl">'+x[0]+'</div><b style="font-size:'+(i===3?20:16)+'px">'+M(x[1])+'</b></div>').join('')}});
  m.upd();
};
P.counters=function(v){
  let tab=AP.q.get('t')||'c';
  const draw=()=>{
    const C=AP.all('counters'),S=AP.all('shifts'),rev=S.filter(s=>s.closedAt&&s.diff&&!s.reviewed),hist=S.filter(s=>s.closedAt).sort((a,b)=>b.closedAt-a.closedAt);
    const meId=AP.me().id;
    v.innerHTML='<div class="ph"><h1>Counter sessions<i class="info" title="Each counter is a cash drawer. Open a shift to sell, close it to count cash.">i</i></h1><button class="btn" id="ac">+ Add counter</button></div>'
    +'<div class="tabs"><button data-t="c" class="'+(tab==='c'?'on':'')+'">Counters</button><button data-t="r" class="'+(tab==='r'?'on':'')+'">Review'+(rev.length?'<span class="n">'+rev.length+'</span>':'')+'</button><button data-t="h" class="'+(tab==='h'?'on':'')+'">History</button></div><div class="card tw" id="tb"></div>';
    $$('.tabs button',v).forEach(b=>b.onclick=()=>{tab=b.dataset.t;draw()});
    $('#ac',v).onclick=()=>{const m=AP.modal({title:'Add counter',size:'sm',body:'<div class="fld"><label class="req">Counter name</label><input class="inp" id="cn" placeholder="e.g. Front desk"></div>',foot:[{label:'Cancel'},{label:'Add',cls:'pri',fn:mm=>{const n=$('#cn',m.el).value.trim();if(!n)return;AP.put('counters',{id:AP.uid(),code:AP.seq('ctr','CTR-',3),name:n});mm.close();draw()}}]})};
    const tb=$('#tb',v);
    if(tab==='c'){
      tb.innerHTML=C.length?'<table class="t"><thead><tr><th>Counter</th><th>Status</th><th>Cashier</th><th>Since</th><th class="r">Cash now</th><th class="r">Action</th></tr></thead><tbody>'+C.map(c=>{const s=AP.shiftOf(c.id);const mine=s&&s.by===meId;return'<tr><td><b>'+E(c.name)+'</b><div class="mono muted">'+c.code+'</div></td><td>'+(s?'<span class="tag ok">Open</span>':'<span class="tag">Closed</span>')+'</td><td>'+(s?E(s.byName):'—')+'</td><td>'+(s?AP.dt(s.openedAt):'—')+'</td><td class="r num">'+(s?M(AP.shiftCash(s.id).expected):'—')+'</td><td class="r">'+(s?(mine?'<a class="btn sm" href="pos.html">Open in POS</a> ':'')+'<button class="btn sm ghost" data-v="'+s.id+'">View</button> <button class="btn sm danger" data-f="'+s.id+'">'+(mine?'Close shift':'Emergency close')+'</button>':'<a class="btn sm" href="pos.html?c='+c.id+'">Open shift</a>')+'</td></tr>'}).join('')+'</tbody></table>':'<div class="empty"><div class="ei"><i class="fa-solid fa-money-bill-wave"></i></div><h4>No counters yet</h4><p>Add a counter (cash drawer) to start selling.</p></div>';
      $$('[data-v]',tb).forEach(b=>b.onclick=()=>shiftView(b.dataset.v));
      $$('[data-f]',tb).forEach(b=>b.onclick=()=>{const s=AP.find('shifts',b.dataset.f);AP.closeShift(s.id,draw,s.by!==meId)});
    }else{
      const L=tab==='r'?rev:hist;
      tb.innerHTML=L.length?'<table class="t"><thead><tr><th>Shift</th><th>Counter</th><th>Cashier</th><th>Opened</th><th>Closed</th><th class="r">Expected</th><th class="r">Counted</th><th class="r">Difference</th><th></th></tr></thead><tbody>'+L.map(s=>{const c=AP.find('counters',s.counterId)||{name:'?'};return'<tr><td class="mono b">'+s.no+'</td><td>'+E(c.name)+'</td><td>'+E(s.byName)+'</td><td>'+AP.dt(s.openedAt)+'</td><td>'+AP.dt(s.closedAt)+(s.force?' <span class="tag warn">emergency</span>':'')+'</td><td class="r num">'+AP.n(s.expected)+'</td><td class="r num">'+AP.n(s.counted)+'</td><td class="r num '+(s.diff<0?'bad':s.diff>0?'warn':'ok')+'">'+(s.diff>0?'+':'')+AP.n(s.diff)+'</td><td class="r"><button class="btn sm ghost" data-v="'+s.id+'">View</button>'+(tab==='r'?' <button class="btn sm" data-ok="'+s.id+'">Mark reviewed</button>':'')+'</td></tr>'}).join('')+'</tbody></table>':'<div class="empty"><div class="ei">✓</div><h4>'+(tab==='r'?'Nothing to review':'No history yet')+'</h4><p>'+(tab==='r'?'Shifts with a cash difference appear here.':'Closed shifts appear here.')+'</p></div>';
      $$('[data-v]',tb).forEach(b=>b.onclick=()=>shiftView(b.dataset.v));
      $$('[data-ok]',tb).forEach(b=>b.onclick=()=>{const s=AP.find('shifts',b.dataset.ok);s.reviewed=true;AP.put('shifts',s);draw()});
    }
  };
  const shiftView=sid=>{const s=AP.find('shifts',sid),c=AP.shiftCash(sid),inv=AP.all('invoices').filter(i=>i.shiftId===sid);
    AP.modal({title:'Shift '+s.no,size:'lg',body:'<div class="grid g4" style="margin-bottom:12px">'+[['Opening',c.open],['Cash sales',c.sales],['Dues collected',c.recv],['Refunds',-c.ref],['Expenses',-c.exp],['Cash in',c.in],['Cash out',-c.out],['Expected',c.expected]].map(x=>'<div class="card pad"><div class="lbl">'+x[0]+'</div><b>'+M(x[1])+'</b></div>').join('')+'</div><div class="muted">'+inv.length+' invoice(s) · '+M(inv.reduce((a,i)=>a+i.total,0))+' sales</div>',foot:[{label:'Close',cls:'pri'}]})};
  draw();
};
})();
