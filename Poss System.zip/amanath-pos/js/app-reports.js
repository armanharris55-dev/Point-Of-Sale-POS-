/* Report centre: 30+ reports with date ranges, charts, CSV and print */
(function(){
const P=AP.pages=AP.pages||{};const $=AP.$,$$=AP.$$,E=AP.esc,M=AP.money,N=AP.n,an=AP.an;
const I=c=>'<i class="fa-solid fa-'+c+'"></i>';
const sg=v=>'<span class="'+(v<0?'bad':v>0?'ok':'')+'">'+(v>0?'+':'')+N(v)+'</span>';
const pc=(a,b)=>b?N(a/b*100,1)+'%':'—';
const dd=t=>AP.d(t);
const MENU=[
 ['Sales',[['daily','Date-wise sales & profit','calendar-day',1],['monthly','Month-wise sales','calendar',1],['items','Item-wise sales','box',1],['category','Category-wise','folder-open',1],['brand','Brand-wise','tags',1],['cashier','Cashier-wise','user-tie',1],['customer','Customer-wise','users',1],['payment','Payment methods','credit-card',1],['hourly','Hour-wise','clock',1],['invprofit','Invoice-wise profit','receipt',1],['discounts','Discount report','percent',1],['returns','Returns report','rotate-left',1],['manual','Manual sales','pen-to-square',1]]],
 ['Profit & loss',[['pnl','Profit & loss statement','scale-balanced',1],['margin','Product margins','arrow-trend-up',0]]],
 ['Stock',[['stock','Stock valuation','warehouse',0],['low','Low stock / reorder','arrow-trend-down',0],['expiry','Expiry','hourglass-half',0],['dead','Dead stock','skull-crossbones',0],['movement','Stock movement ledger','arrows-up-down',1],['adjust','Stock adjustments','sliders',1]]],
 ['Purchases',[['purchases','Stock-in report','boxes-packing',1],['supplierwise','Supplier-wise purchase','truck-field',1],['payable','Supplier payable','file-invoice-dollar',0]]],
 ['Money',[['due','Customer due & ageing','hand-holding-dollar',0],['custledger','Customer summary','address-book',0],['expenses','Expense report','money-bill-transfer',1],['cashbook','Cash book','book',1],['shifts','Shift / counter report','cash-register',1],['receipts','Receipts collected','inbox',1],['vat','VAT report','landmark',1]]]
];
const ALIAS={day:'daily',sales:'daily',profit:'pnl',stockval:'stock'};
const R={};
const dayLabel=t=>{const d=new Date(t);return d.getDate()+'/'+(d.getMonth()+1)};
/* ---------- SALES ---------- */
R.daily=(a,b)=>{
  const D=an.daily(a,b),T=an.sum(a,b);
  return{kpis:[['Net sales',M(T.net)],['Gross profit',M(T.gp)+' · '+N(T.margin,1)+'%'],['Expenses',M(T.exp)],['Net profit / loss',M(T.np),T.np<0?'bad':'ok']],
    chart:D.length>1?AP.chart.line(D.map(d=>dayLabel(d.d)),[{name:'Net sales',color:'var(--mintd)',vals:D.map(d=>d.net),area:1},{name:'Gross profit',color:'var(--acc)',vals:D.map(d=>d.gp)},{name:'Net profit',color:'var(--ink)',vals:D.map(d=>d.np)}]):'',
    cols:[['Date'],['Bills','r'],['Gross sales','r'],['Discount','r'],['Returns','r'],['Manual','r'],['Net sales','r'],['Cost','r'],['Gross profit','r'],['Margin','r'],['Expenses','r'],['Profit / Loss','r']],
    rows:D.map(d=>[dd(d.d),d.n,N(d.gross),N(d.disc),N(d.ret),N(d.man),'<b>'+N(d.net)+'</b>',N(d.cost+d.manCost),N(d.gp),pc(d.gp,d.revenue),N(d.exp),sg(d.np)]),
    foot:['Total',T.n,N(T.gross),N(T.disc),N(T.ret),N(T.man),N(T.net),N(T.cost+T.manCost),N(T.gp),pc(T.gp,T.revenue),N(T.exp),sg(T.np)]};
};
R.monthly=(a,b)=>{
  const D=an.daily(a,b),mo={};D.forEach(d=>{const x=new Date(d.d),k=x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0');const o=mo[k]||(mo[k]={k,n:0,net:0,gp:0,exp:0,np:0,disc:0});o.n+=d.n;o.net+=d.net;o.gp+=d.gp;o.exp+=d.exp;o.np+=d.np;o.disc+=d.disc});
  const L=Object.values(mo);const T=L.reduce((s,x)=>({n:s.n+x.n,net:s.net+x.net,gp:s.gp+x.gp,exp:s.exp+x.exp,np:s.np+x.np,disc:s.disc+x.disc}),{n:0,net:0,gp:0,exp:0,np:0,disc:0});
  return{chart:L.length>1?AP.chart.bars(L.map(x=>x.k.slice(2)),L.map(x=>x.net),{h:170}):'',cols:[['Month'],['Bills','r'],['Net sales','r'],['Discount','r'],['Gross profit','r'],['Expenses','r'],['Profit / Loss','r']],rows:L.map(x=>[x.k,x.n,N(x.net),N(x.disc),N(x.gp),N(x.exp),sg(x.np)]),foot:['Total',T.n,N(T.net),N(T.disc),N(T.gp),N(T.exp),sg(T.np)]};
};
const grp=(a,b,keyFn,label)=>{const L=an.items(a,b,keyFn).sort((x,y)=>y.r-x.r);const T=L.reduce((s,x)=>({q:s.q+x.q,r:s.r+x.r,c:s.c+x.c,d:s.d+x.d}),{q:0,r:0,c:0,d:0});
  return{chart:L.length?AP.chart.hbars(L.slice(0,8).map(x=>({l:x.n||x.k,v:x.r}))):'',cols:[[label],['Qty sold','r'],['Revenue','r'],['Discount','r'],['Cost','r'],['Profit','r'],['Margin','r'],['Share','r']],rows:L.map(x=>[E(x.n||x.k),N(x.q,0),N(x.r),N(x.d),N(x.c),sg(x.r-x.c),pc(x.r-x.c,x.r),pc(x.r,T.r)]),foot:['Total',N(T.q,0),N(T.r),N(T.d),N(T.c),sg(T.r-T.c),pc(T.r-T.c,T.r),'100%']}};
R.items=(a,b)=>grp(a,b,null,'Item');
R.category=(a,b)=>grp(a,b,(l,p)=>p.cat?AP.catName(p.cat):'Uncategorised','Category');
R.brand=(a,b)=>grp(a,b,(l,p)=>(AP.find('brands',p.brand)||{}).name||'No brand','Brand');
R.cashier=(a,b)=>{const o={};an.rows(a,b).inv.forEach(i=>{const x=o[i.byName]||(o[i.byName]={n:i.byName,k:0,r:0,d:0,due:0});x.k++;x.r+=i.total;x.d+=(i.invDisc||0)+i.items.reduce((s,l)=>s+l.disc,0);x.due+=i.due});const L=Object.values(o).sort((x,y)=>y.r-x.r);
  return{chart:L.length?AP.chart.hbars(L.map(x=>({l:x.n,v:x.r}))):'',cols:[['Cashier'],['Bills','r'],['Sales','r'],['Avg. bill','r'],['Discount given','r'],['Sold on due','r']],rows:L.map(x=>[E(x.n),x.k,N(x.r),N(x.r/x.k),N(x.d),N(x.due)]),foot:['Total',L.reduce((s,x)=>s+x.k,0),N(L.reduce((s,x)=>s+x.r,0)),'',N(L.reduce((s,x)=>s+x.d,0)),N(L.reduce((s,x)=>s+x.due,0))]};};
R.customer=(a,b)=>{const o={};an.rows(a,b).inv.forEach(i=>{const k=i.customerId||'walk';const x=o[k]||(o[k]={n:i.customerName,k:0,r:0,p:0,due:0});x.k++;x.r+=i.total;x.due+=i.due;x.p+=i.total-i.items.reduce((s,l)=>s+l.cost*l.qty,0)});const L=Object.values(o).sort((x,y)=>y.r-x.r);
  return{chart:L.length?AP.chart.hbars(L.slice(0,8).map(x=>({l:x.n,v:x.r}))):'',cols:[['Customer'],['Bills','r'],['Sales','r'],['Profit','r'],['Due','r']],rows:L.map(x=>[E(x.n),x.k,N(x.r),sg(x.p),N(x.due)]),foot:['Total',L.reduce((s,x)=>s+x.k,0),N(L.reduce((s,x)=>s+x.r,0)),sg(L.reduce((s,x)=>s+x.p,0)),N(L.reduce((s,x)=>s+x.due,0))]};};
R.payment=(a,b)=>{const R0=an.rows(a,b),pm={};let due=0;R0.inv.forEach(i=>{(i.pay||[]).forEach(p=>{const k=AP.PAY[p.m]||p.m;const x=pm[k]||(pm[k]={n:0,v:0});x.n++;x.v+=p.amt-(p.m==='cash'?i.change||0:0)});due+=i.due});const man=R0.man.reduce((s,m)=>s+m.amount,0);if(man)pm['Manual sales']={n:R0.man.length,v:man};if(due)pm['Sold on due']={n:R0.inv.filter(i=>i.due>0).length,v:due};
  const L=Object.keys(pm).map(k=>({k,...pm[k]})).sort((x,y)=>y.v-x.v),tot=L.reduce((s,x)=>s+x.v,0);
  return{chart:L.length?AP.chart.donut(L.map(x=>({l:x.k,v:x.v}))):'',cols:[['Method'],['Transactions','r'],['Amount','r'],['Share','r']],rows:L.map(x=>[x.k,x.n,N(x.v),pc(x.v,tot)]),foot:['Total','',N(tot),'100%']};};
R.hourly=(a,b)=>{const h=an.hourly(a,b);const rows=h.h.map((v,i)=>[(i%12||12)+(i<12?' AM':' PM'),h.c[i],N(v),h.c[i]?N(v/h.c[i]):'—']);
  return{chart:AP.chart.bars(h.h.map((_,i)=>String(i)),h.h,{step:2}),cols:[['Hour'],['Bills','r'],['Sales','r'],['Avg. bill','r']],rows:rows.filter((r,i)=>h.c[i]),foot:['Total',h.c.reduce((s,x)=>s+x,0),N(h.h.reduce((s,x)=>s+x,0)),'']};};
R.invprofit=(a,b)=>{const L=an.rows(a,b).inv.sort((x,y)=>y.t-x.t).map(i=>{const c=i.items.reduce((s,l)=>s+l.cost*l.qty,0);return{i,c,p:i.total-(i.vat||0)-c}});
  return{cols:[['Invoice'],['Date'],['Customer'],['Sales','r'],['Cost','r'],['Profit','r'],['Margin','r']],rows:L.map(x=>['<span class="mono b">'+x.i.no+'</span>',AP.dt(x.i.t),E(x.i.customerName),N(x.i.total),N(x.c),sg(x.p),pc(x.p,x.i.total)]),foot:['Total','','',N(L.reduce((s,x)=>s+x.i.total,0)),N(L.reduce((s,x)=>s+x.c,0)),sg(L.reduce((s,x)=>s+x.p,0)),'']};};
R.discounts=(a,b)=>{const L=an.rows(a,b).inv.map(i=>({i,d:(i.invDisc||0)+i.items.reduce((s,l)=>s+l.disc,0)})).filter(x=>x.d>0).sort((x,y)=>y.d-x.d);const T=L.reduce((s,x)=>s+x.d,0);
  return{kpis:[['Total discount given',M(T)],['Bills with discount',String(L.length)]],cols:[['Invoice'],['Date'],['Cashier'],['Customer'],['Bill total','r'],['Discount','r'],['% of bill','r']],rows:L.map(x=>['<span class="mono b">'+x.i.no+'</span>',AP.dt(x.i.t),E(x.i.byName),E(x.i.customerName),N(x.i.total),N(x.d),pc(x.d,x.i.total+x.d)]),foot:['Total','','','','',N(T),'']};};
R.returns=(a,b)=>{const L=an.rows(a,b).ret.sort((x,y)=>y.t-x.t);return{kpis:[['Total refunded',M(L.reduce((s,r)=>s+r.refund,0))],['Returns',String(L.length)]],cols:[['Return'],['Date'],['Invoice'],['Customer'],['Items'],['Reason'],['Method'],['Refund','r']],rows:L.map(r=>['<span class="mono b">'+r.no+'</span>',AP.dt(r.t),r.invoiceNo,E(r.customerName),E(r.items.map(i=>i.name+' ×'+i.qty).join(', ')),E(r.reason),AP.PAY[r.method]||r.method,N(r.refund)]),foot:['Total','','','','','','',N(L.reduce((s,r)=>s+r.refund,0))]};};
R.manual=(a,b)=>{const L=an.rows(a,b).man.sort((x,y)=>y.t-x.t);const sh=id=>(AP.find('shifts',id)||{}).no||'—';return{kpis:[['Manual sales',M(L.reduce((s,m)=>s+m.amount,0))],['Estimated profit',M(L.reduce((s,m)=>s+m.amount,0)*an.mm())+' @ '+N(an.mm()*100,0)+'%']],cols:[['Date'],['Shift'],['Entered by'],['Note'],['Amount','r']],rows:L.map(m=>[AP.dt(m.t),sh(m.shiftId),E(m.by),E(m.note||'—'),N(m.amount)]),foot:['Total','','','',N(L.reduce((s,m)=>s+m.amount,0))]};};
/* ---------- P&L ---------- */
R.pnl=(a,b)=>{
  const [pa,pb]=an.prev(a,b),c=an.sum(a,b),p=an.sum(pa,pb),rows=an.rows(a,b),pr=an.rows(pa,pb);
  const ex=r=>{const o={};r.exp.forEach(e=>o[e.cat]=(o[e.cat]||0)+e.amount);return o},ec=ex(rows),ep=ex(pr);const cats=[...new Set([...Object.keys(ec),...Object.keys(ep)])];
  const L=(l,x,y,cls)=>['<span class="'+(cls||'')+'">'+l+'</span>',N(x),N(y),AP.dl?AP.dl(x,y):''];
  const r=[L('<b>Gross sales</b>',c.gross,p.gross),L('Manual sales',c.man,p.man),L('Less: returns',-c.ret,-p.ret),L('Less: VAT collected',-c.vat,-p.vat),L('<b>Net revenue</b>',c.revenue,p.revenue),L('Less: cost of goods sold',-(c.cost+c.manCost),-(p.cost+p.manCost)),L('<b>Gross profit</b>',c.gp,p.gp),['<span class="muted">Gross margin</span>',N(c.margin,1)+'%',N(p.margin,1)+'%','']].concat(cats.map(k=>L('&nbsp;&nbsp;'+E(k),-(ec[k]||0),-(ep[k]||0)))).concat([L('Less: total expenses',-c.exp,-p.exp),L('<b>Net profit / loss</b>',c.np,p.np)]);
  return{kpis:[['Net revenue',M(c.revenue)],['Gross profit',M(c.gp)],['Expenses',M(c.exp)],['Net profit / loss',M(c.np),c.np<0?'bad':'ok']],cols:[['Particulars'],['This period','r'],['Previous period','r'],['Change','r']],rows:r,note:'Discounts are already inside the sales figures. Manual sales profit uses the margin set in Settings ('+N(an.mm()*100,0)+'%).'};
};
R.margin=()=>{const L=AP.all('products').filter(p=>p.type!=='service').map(p=>({p,m:(+p.price||0)-(+p.cost||0)})).sort((x,y)=>x.m/(x.p.price||1)-y.m/(y.p.price||1));
  return{cols:[['Item'],['Cost','r'],['Price','r'],['Profit/unit','r'],['Margin','r'],['Flag']],rows:L.map(x=>[E(x.p.name),N(x.p.cost),N(x.p.price),sg(x.m),pc(x.m,x.p.price),x.m<0?'<span class="tag bad">Selling below cost</span>':x.m/(x.p.price||1)<.1?'<span class="tag warn">Thin margin</span>':''])};};
/* ---------- STOCK ---------- */
const stk=()=>AP.all('products').filter(p=>p.type!=='service'&&p.on!==false);
R.stock=()=>{const L=stk(),tc=L.reduce((s,p)=>s+(+p.stock||0)*(+p.cost||0),0),tr=L.reduce((s,p)=>s+(+p.stock||0)*(+p.price||0),0);
  return{kpis:[['Stock value (cost)',M(tc)],['Stock value (selling)',M(tr)],['Potential profit',M(tr-tc)],['Items',String(L.length)]],cols:[['Item'],['Category'],['Stock','r'],['Cost','r'],['Value (cost)','r'],['Price','r'],['Value (selling)','r']],rows:L.map(p=>[E(p.name),E(AP.catName(p.cat)||'—'),N(p.stock,0)+' '+E(p.unit||''),N(p.cost),N((+p.stock||0)*(+p.cost||0)),N(p.price),N((+p.stock||0)*(+p.price||0))]),foot:['Total','','','',N(tc),'',N(tr)]};};
R.low=()=>{const cfg=AP.cfg(),L=stk().filter(p=>(+p.stock||0)<=(+p.min||cfg.lowStock||0)).sort((x,y)=>x.stock-y.stock);
  return{actions:L.length?'<a class="btn" href="#/stockin?low=1">'+I('boxes-packing')+' Make stock-in from this list</a>':'',cols:[['Item'],['Category'],['Stock','r'],['Alert at','r'],['Suggested order','r'],['Est. cost','r']],rows:L.map(p=>{const q=Math.max(1,(+p.min||5)*3-(+p.stock||0));return[E(p.name),E(AP.catName(p.cat)||'—'),'<b class="'+(p.stock<=0?'bad':'warn')+'">'+N(p.stock,0)+'</b>',p.min||'—',N(q,0),N(q*(p.cost||0))]}),empty:'Stock levels are healthy'};};
R.expiry=()=>{const L=stk().filter(p=>p.expiry&&(+p.stock||0)>0).sort((x,y)=>x.expiry.localeCompare(y.expiry));
  return{cols:[['Item'],['Expiry'],['Status'],['Stock','r'],['Value at cost','r']],rows:L.map(p=>{const d=Math.ceil((+new Date(p.expiry)-Date.now())/864e5);return[E(p.name),E(p.expiry),d<0?'<span class="tag bad">Expired '+(-d)+' d ago</span>':d<=30?'<span class="tag warn">In '+d+' days</span>':d<=90?'<span class="tag">'+d+' days</span>':'<span class="tag ok">'+d+' days</span>',N(p.stock,0),N(p.stock*p.cost)]}),empty:'No items with expiry dates'};};
R.dead=()=>{const days=+(AP.q&&AP.q.get('days'))||30,since=Date.now()-days*864e5,sold={};AP.all('invoices').filter(i=>i.t>=since).forEach(i=>i.items.forEach(l=>sold[l.pid]=1));const L=stk().filter(p=>(+p.stock||0)>0&&!sold[p.id]);
  return{kpis:[['Dead items (no sale in '+days+' days)',String(L.length)],['Cash locked',M(L.reduce((s,p)=>s+p.stock*p.cost,0))]],cols:[['Item'],['Category'],['Stock','r'],['Value at cost','r']],rows:L.map(p=>[E(p.name),E(AP.catName(p.cat)||'—'),N(p.stock,0),N(p.stock*p.cost)]),empty:'Everything has sold recently'};};
R.movement=(a,b,ctx)=>{
  const pid=ctx.pid||(AP.all('products')[0]||{}).id;const p=AP.find('products',pid);if(!p)return{cols:[['Date']],rows:[],empty:'Add a product first'};
  const ev=[];AP.all('invoices').forEach(i=>i.items.forEach(l=>{if(l.pid===pid&&i.t>=a&&i.t<b)ev.push({t:i.t,ty:'Sale',ref:i.no,q:-l.qty})}));
  AP.all('returns').forEach(r=>r.items.forEach(l=>{if(l.pid===pid&&r.t>=a&&r.t<b)ev.push({t:r.t,ty:'Return',ref:r.no,q:l.qty})}));
  AP.all('stockins').forEach(s=>s.lines.forEach(l=>{if(l.pid===pid&&s.t>=a&&s.t<b)ev.push({t:s.t,ty:'Stock in',ref:s.no,q:l.qty})}));
  AP.all('adjusts').forEach(x=>{if(x.pid===pid&&x.t>=a&&x.t<b)ev.push({t:x.t,ty:'Adjust',ref:x.reason,q:x.diff})});
  ev.sort((x,y)=>x.t-y.t);const net=ev.reduce((s,x)=>s+x.q,0);
  return{pick:true,kpis:[['Current stock',N(p.stock,0)+' '+(p.unit||'')],['Net change in period',(net>0?'+':'')+N(net,0)]],cols:[['Date'],['Type'],['Reference'],['Qty','r']],rows:ev.map(x=>[AP.dt(x.t),x.ty,E(x.ref),sg(x.q)]),empty:'No movement in this period'};
};
R.adjust=(a,b)=>{const L=AP.all('adjusts').filter(x=>x.t>=a&&x.t<b).sort((x,y)=>y.t-x.t);return{cols:[['Date'],['Item'],['Reason'],['By'],['Change','r']],rows:L.map(x=>[AP.dt(x.t),E(x.name),E(x.reason),E(x.by),sg(x.diff)]),empty:'No adjustments in this period'};};
/* ---------- PURCHASES ---------- */
R.purchases=(a,b)=>{const L=an.rows(a,b).sti.sort((x,y)=>y.t-x.t);const T=L.reduce((s,x)=>({t:s.t+x.total,p:s.p+x.paid,d:s.d+x.due}),{t:0,p:0,d:0});
  return{kpis:[['Purchases',M(T.t)],['Paid',M(T.p)],['Owed',M(T.d)]],cols:[['Number'],['Date'],['Supplier'],['Items','r'],['Total','r'],['Paid','r'],['Owed','r']],rows:L.map(x=>['<span class="mono b">'+x.no+'</span>',AP.dt(x.t),E(x.supplierName),x.lines.length,N(x.total),N(x.paid),N(x.due)]),foot:['Total','','','',N(T.t),N(T.p),N(T.d)]};};
R.supplierwise=(a,b)=>{const o={};an.rows(a,b).sti.forEach(s=>{const x=o[s.supplierName]||(o[s.supplierName]={n:s.supplierName,k:0,t:0,p:0});x.k++;x.t+=s.total;x.p+=s.paid});const L=Object.values(o).sort((x,y)=>y.t-x.t);
  return{chart:L.length?AP.chart.hbars(L.map(x=>({l:x.n,v:x.t}))):'',cols:[['Supplier'],['Stock-ins','r'],['Purchased','r'],['Paid','r'],['Payable now','r']],rows:L.map(x=>[E(x.n),x.k,N(x.t),N(x.p),N((AP.all('suppliers').find(s=>s.name===x.n)||{}).due||0)])};};
R.payable=()=>{const L=AP.all('suppliers').filter(s=>s.due>0).sort((x,y)=>y.due-x.due);return{kpis:[['Total payable',M(L.reduce((s,x)=>s+x.due,0))]],cols:[['Supplier'],['Mobile'],['Payable','r']],rows:L.map(s=>[E(s.name),E(s.phone||'—'),'<b class="warn">'+N(s.due)+'</b>']),foot:['Total','',N(L.reduce((s,x)=>s+x.due,0))],empty:'You owe nothing to suppliers'};};
/* ---------- MONEY ---------- */
R.due=()=>{const now=Date.now(),L=AP.all('customers').map(c=>{const bills=AP.all('invoices').filter(i=>i.customerId===c.id&&i.due>0);const o={c,d0:0,d1:0,d2:0,d3:0,t:0};bills.forEach(i=>{const d=(now-i.t)/864e5;o[d<=7?'d0':d<=30?'d1':d<=90?'d2':'d3']+=i.due;o.t+=i.due});return o}).filter(x=>x.t>0).sort((x,y)=>y.t-x.t);
  const T=L.reduce((s,x)=>({a:s.a+x.d0,b:s.b+x.d1,c:s.c+x.d2,d:s.d+x.d3,t:s.t+x.t}),{a:0,b:0,c:0,d:0,t:0});
  return{kpis:[['Total receivable',M(T.t),'bad'],['Over 30 days',M(T.c+T.d)],['Customers',String(L.length)]],cols:[['Customer'],['Mobile'],['0–7 d','r'],['8–30 d','r'],['31–90 d','r'],['90+ d','r'],['Total due','r'],['']],rows:L.map(x=>[E(x.c.name),E(x.c.phone),N(x.d0),N(x.d1),N(x.d2),N(x.d3),'<b class="bad">'+N(x.t)+'</b>','<a class="btn sm" target="_blank" href="'+AP.waLink(x.c.phone,'আসসালামু আলাইকুম '+x.c.name+', '+AP.cfg().shop.name+'-এ আপনার বকেয়া '+M(x.t)+'। ধন্যবাদ।')+'"><i class="fa-brands fa-whatsapp"></i> Remind</a> <a class="btn sm ghost" href="#/receipts/new?c='+x.c.id+'">Receive</a>']),foot:['Total','',N(T.a),N(T.b),N(T.c),N(T.d),N(T.t),''],empty:'Nobody owes you money',nocsv:1};};
R.custledger=()=>{const L=AP.all('customers').sort((x,y)=>(y.spent||0)-(x.spent||0));return{cols:[['Customer'],['Mobile'],['Category'],['Total bought','r'],['Due','r'],['Advance','r'],['Points','r'],['Last purchase']],rows:L.map(c=>[E(c.name),E(c.phone),E(c.cat),N(c.spent||0),N(AP.custDue(c.id)),N(c.advance||0),c.points||0,c.last?AP.d(c.last):'—'])};};
R.expenses=(a,b)=>{const L=an.rows(a,b).exp.concat(AP.all('expenses').filter(e=>e.t>=a&&e.t<b&&e.cat==='Supplier payment')).sort((x,y)=>y.t-x.t),o={};L.forEach(e=>o[e.cat]=(o[e.cat]||0)+e.amount);const T=L.reduce((s,e)=>s+e.amount,0);
  return{kpis:[['Total expenses',M(T)],['Entries',String(L.length)]],chart:Object.keys(o).length?AP.chart.donut(Object.keys(o).map(k=>({l:k,v:o[k]}))):'',cols:[['Date'],['No.'],['Category'],['Note'],['Paid from'],['By'],['Amount','r']],rows:L.map(e=>[AP.dt(e.t),'<span class="mono">'+e.no+'</span>',E(e.cat),E(e.note||'—'),E(e.method),E(e.by),N(e.amount)]),foot:['Total','','','','','',N(T)]};};
R.cashbook=(a,b)=>{
  const ev=[];const rw=an.rows(a,b);
  rw.inv.forEach(i=>{const c=(i.pay||[]).filter(p=>p.m==='cash').reduce((s,p)=>s+p.amt,0)-(i.change||0);if(c>0)ev.push({t:i.t,d:'Sale '+i.no,i:c,o:0})});
  rw.man.forEach(m=>ev.push({t:m.t,d:'Manual sales'+(m.note?' — '+m.note:''),i:m.amount,o:0}));
  rw.rec.filter(r=>r.method==='cash').forEach(r=>ev.push({t:r.t,d:r.type+' '+r.no+' · '+r.customerName,i:r.type==='Advance returned'?0:r.amount,o:r.type==='Advance returned'?r.amount:0}));
  rw.ret.filter(r=>r.method==='cash').forEach(r=>ev.push({t:r.t,d:'Refund '+r.no,i:0,o:r.refund}));
  AP.all('expenses').filter(e=>e.t>=a&&e.t<b&&e.method==='cash').forEach(e=>ev.push({t:e.t,d:'Expense · '+e.cat,i:0,o:e.amount}));
  AP.all('cashmoves').filter(m=>m.t>=a&&m.t<b).forEach(m=>ev.push({t:m.t,d:'Cash '+m.type+' · '+(m.note||''),i:m.type==='in'?m.amt:0,o:m.type==='out'?m.amt:0}));
  AP.all('stockins').filter(s=>s.t>=a&&s.t<b&&s.paid>0&&s.cashPaid).forEach(s=>ev.push({t:s.t,d:'Purchase '+s.no,i:0,o:s.paid}));
  ev.sort((x,y)=>x.t-y.t);let bal=0;const T=ev.reduce((s,x)=>({i:s.i+x.i,o:s.o+x.o}),{i:0,o:0});
  return{kpis:[['Cash in',M(T.i)],['Cash out',M(T.o)],['Net movement',M(T.i-T.o)]],cols:[['Date'],['Particulars'],['In','r'],['Out','r'],['Balance','r']],rows:ev.map(x=>{bal+=x.i-x.o;return[AP.dt(x.t),E(x.d),x.i?N(x.i):'',x.o?N(x.o):'',N(bal)]}),foot:['Total','',N(T.i),N(T.o),N(T.i-T.o)]};};
R.shifts=(a,b)=>{const L=AP.all('shifts').filter(s=>s.openedAt>=a&&s.openedAt<b).sort((x,y)=>y.openedAt-x.openedAt);const ct=id=>(AP.find('counters',id)||{}).name||'—';
  return{cols:[['Shift'],['Counter'],['Cashier'],['Opened'],['Closed'],['Opening','r'],['Expected','r'],['Counted','r'],['Difference','r']],rows:L.map(s=>{const c=s.closedAt?null:AP.shiftCash(s.id);return['<span class="mono b">'+s.no+'</span>',E(ct(s.counterId)),E(s.byName),AP.dt(s.openedAt),s.closedAt?AP.dt(s.closedAt):'<span class="tag ok">Open</span>',N(s.openCash),N(s.closedAt?s.expected:c.expected),s.closedAt?N(s.counted):'—',s.closedAt?sg(s.diff):'—']}),foot:['Total','','','','',N(L.reduce((s,x)=>s+(x.openCash||0),0)),'','',sg(L.reduce((s,x)=>s+(x.diff||0),0))]};};
R.receipts=(a,b)=>{const L=an.rows(a,b).rec.sort((x,y)=>y.t-x.t);const T=L.reduce((s,r)=>s+(r.type==='Advance returned'?-r.amount:r.amount),0);return{kpis:[['Collected',M(T)],['Receipts',String(L.length)]],cols:[['Number'],['Date'],['Customer'],['Type'],['Into'],['Amount','r']],rows:L.map(r=>['<span class="mono b">'+r.no+'</span>',AP.dt(r.t),E(r.customerName),E(r.type),E(r.method),N(r.amount)]),foot:['Total','','','','',N(T)]};};
R.vat=(a,b)=>{const D=an.daily(a,b).filter(d=>d.vat||d.n);const T=D.reduce((s,d)=>s+d.vat,0);return{kpis:[['VAT collected',M(T)]],cols:[['Date'],['Bills','r'],['Taxable sales','r'],['VAT','r']],rows:D.map(d=>[dd(d.d),d.n,N(d.gross-d.vat),N(d.vat)]),foot:['Total',D.reduce((s,d)=>s+d.n,0),N(D.reduce((s,d)=>s+d.gross-d.vat,0)),N(T)]};};

/* ---------- page ---------- */
const strip=h=>{const d=document.createElement('div');d.innerHTML=h;return d.textContent.trim()};
P.reports=function(v,id){
  id=ALIAS[id]||id||'daily';
  const meta=MENU.flatMap(g=>g[1]).find(x=>x[0]===id);if(!meta){location.hash='#/reports';return}
  let per=AP.get('rep_per','mtd');if(!meta[3])per=null;
  const qf=AP.q.get('from'),qt=AP.q.get('to');if(qf){per='custom'}
  let cf=qf||AP.iso(Date.now()),ct=qt||cf;
  const draw=()=>{
    const [a,b]=per?AP.an.range(per,cf,ct):[0,Date.now()+864e5];
    const pid=AP.q.get('p');
    const out=R[id](a,b,{pid});
    v.innerHTML='<div class="rpt"><div class="card menu">'+MENU.map(g=>'<div class="mh">'+g[0]+'</div>'+g[1].map(x=>'<a href="#/reports/'+x[0]+'" class="'+(x[0]===id?'on':'')+'">'+I(x[2])+x[1]+'</a>').join('')).join('')+'</div><div><div class="ph"><h1>'+I(meta[2])+' '+meta[1]+'</h1><div class="row"><button class="btn ghost" id="csv"><i class="fa-solid fa-file-csv"></i> CSV</button><button class="btn ghost" id="prt"><i class="fa-solid fa-print"></i> Print</button></div></div>'
    +(per?'<div class="rtool"><div class="chips" id="pp">'+AP.an.presets.map(x=>'<button data-p="'+x[0]+'" class="'+(per===x[0]?'on':'')+'">'+x[1]+'</button>').join('')+'</div>'+(per==='custom'?'<input class="inp" type="date" id="f1" value="'+cf+'" style="width:150px"><span class="muted">to</span><input class="inp" type="date" id="f2" value="'+ct+'" style="width:150px">':'')+'<span class="muted mono" style="margin-left:auto">'+AP.d(a)+' – '+AP.d(b-864e5)+'</span></div>':'')
    +(out.pick?'<div class="rtool"><div class="fld" style="min-width:280px"><label>Product</label><select class="sel" id="pp2">'+AP.all('products').map(p=>'<option value="'+p.id+'"'+(p.id===(pid||AP.all('products')[0].id)?' selected':'')+'>'+E(p.name)+'</option>').join('')+'</select></div></div>':'')
    +(out.actions?'<div class="rtool">'+out.actions+'</div>':'')
    +(out.kpis?'<div class="grid g'+Math.min(4,out.kpis.length)+'" style="margin-bottom:14px">'+out.kpis.map(k=>'<div class="card kpi2"><div class="k">'+k[0]+'</div><div class="v '+(k[2]||'')+'" style="font-size:22px">'+k[1]+'</div></div>').join('')+'</div>':'')
    +(out.chart?'<div class="card pad" style="margin-bottom:14px">'+out.chart+'</div>':'')
    +(out.rows&&out.rows.length?'<div class="card tw"><table class="t"><thead><tr>'+out.cols.map(c=>'<th class="'+(c[1]||'')+'">'+c[0]+'</th>').join('')+'</tr></thead><tbody>'+out.rows.map(r=>'<tr>'+r.map((c,i)=>'<td class="'+(out.cols[i][1]||'')+(out.cols[i][1]==='r'?' num':'')+'">'+c+'</td>').join('')+'</tr>').join('')+'</tbody>'+(out.foot?'<tfoot><tr>'+out.foot.map((c,i)=>'<td class="'+(out.cols[i][1]||'')+(out.cols[i][1]==='r'?' num':'')+'">'+c+'</td>').join('')+'</tr></tfoot>':'')+'</table></div>':'<div class="card empty"><div class="ei">'+I('circle-check')+'</div><h4>'+(out.empty||'No data for this period')+'</h4><p>Try a different date range.</p></div>')
    +(out.note?'<p class="muted" style="margin-top:10px;font-size:12.5px">'+out.note+'</p>':'')+'</div></div>';
    $$('#pp button',v).forEach(x=>x.onclick=()=>{per=x.dataset.p;AP.set('rep_per',per);draw()});
    const f1=$('#f1',v);if(f1){f1.onchange=()=>{cf=f1.value;if(ct<cf)ct=cf;draw()};$('#f2',v).onchange=e=>{ct=e.target.value;draw()}}
    const pp=$('#pp2',v);if(pp)pp.onchange=()=>{location.hash='#/reports/movement?p='+pp.value};
    $('#csv',v).onclick=()=>AP.csv('report-'+id+'-'+AP.iso(Date.now())+'.csv',[out.cols.map(c=>c[0])].concat((out.rows||[]).map(r=>r.map(strip))).concat(out.foot?[out.foot.map(strip)]:[]));
    $('#prt',v).onclick=()=>window.print();
  };
  draw();
};
})();
