/* Amanath POS — analytics: date ranges, aggregates, tiny SVG charts */
(function(){
'use strict';
const A=window.AP,DAY=864e5,N=A.n;
const an=A.an={};
an.presets=[['today','Today'],['yest','Yesterday'],['7d','Last 7 days'],['30d','Last 30 days'],['mtd','This month'],['lm','Last month'],['ytd','This year'],['custom','Custom']];
an.range=(k,f,t)=>{
  const t0=A.day0(),d=new Date(t0);
  if(k==='today')return[t0,t0+DAY];
  if(k==='yest')return[t0-DAY,t0];
  if(k==='7d')return[t0-6*DAY,t0+DAY];
  if(k==='30d')return[t0-29*DAY,t0+DAY];
  if(k==='mtd')return[+new Date(d.getFullYear(),d.getMonth(),1),t0+DAY];
  if(k==='lm')return[+new Date(d.getFullYear(),d.getMonth()-1,1),+new Date(d.getFullYear(),d.getMonth(),1)];
  if(k==='ytd')return[+new Date(d.getFullYear(),0,1),t0+DAY];
  return[+new Date((f||A.iso(t0))+'T00:00:00'),+new Date((t||A.iso(t0))+'T00:00:00')+DAY];
};
an.prev=(a,b)=>[a-(b-a),a];
an.days=(a,b)=>Math.max(1,Math.round((b-a)/DAY));
an.mm=()=>(A.cfg().manualMargin==null?20:+A.cfg().manualMargin)/100;
const inR=(t,a,b)=>t>=a&&t<b;
/* raw rows in range */
an.rows=(a,b)=>({
  inv:A.all('invoices').filter(i=>inR(i.t,a,b)),ret:A.all('returns').filter(i=>inR(i.t,a,b)),
  exp:A.all('expenses').filter(i=>inR(i.t,a,b)&&i.cat!=='Supplier payment'),man:A.all('manualsales').filter(i=>inR(i.t,a,b)),
  rec:A.all('receipts').filter(i=>inR(i.t,a,b)),sti:A.all('stockins').filter(i=>inR(i.t,a,b))});
const costOfReturn=(r,invMap)=>{const inv=invMap[r.invoiceId];if(!inv)return 0;return r.items.reduce((s,x)=>{const l=inv.items.find(i=>i.pid===x.pid);return s+(l?l.cost*x.qty:0)},0)};
/* totals for a range */
an.sum=(a,b,rows)=>{
  const R=rows||an.rows(a,b),invMap={};A.all('invoices').forEach(i=>invMap[i.id]=i);
  const o={n:R.inv.length,gross:0,vat:0,lineDisc:0,invDisc:0,cost:0,qty:0,ret:0,retN:R.ret.length,man:0,exp:0,due:0,paidCash:0};
  R.inv.forEach(i=>{o.gross+=i.total;o.vat+=i.vat||0;o.invDisc+=i.invDisc||0;o.due+=i.due||0;i.items.forEach(l=>{o.lineDisc+=l.disc||0;o.cost+=l.cost*l.qty;o.qty+=l.qty})});
  R.ret.forEach(r=>{o.ret+=r.refund;o.cost-=costOfReturn(r,invMap)});
  R.man.forEach(m=>{o.man+=m.amount});
  R.exp.forEach(e=>{o.exp+=e.amount});
  o.disc=o.lineDisc+o.invDisc;
  o.net=o.gross+o.man-o.ret;
  o.manCost=o.man*(1-an.mm());
  o.revenue=o.net-o.vat;
  o.gp=o.revenue-o.cost-o.manCost;
  o.np=o.gp-o.exp;
  o.margin=o.revenue>0?o.gp/o.revenue*100:0;
  o.basket=o.n?o.gross/o.n:0;
  return o;
};
/* per-day series */
an.daily=(a,b)=>{
  const out=[];for(let t=a;t<b;t+=DAY){const R=an.rows(t,t+DAY);const s=an.sum(t,t+DAY,R);s.d=t;out.push(s)}return out;
};
an.hourly=(a,b)=>{const h=Array(24).fill(0),c=Array(24).fill(0);A.all('invoices').filter(i=>inR(i.t,a,b)).forEach(i=>{const k=new Date(i.t).getHours();h[k]+=i.total;c[k]++});return{h,c}};
an.delta=(cur,prev)=>prev?((cur-prev)/Math.abs(prev)*100):(cur?100:0);
an.stockValue=()=>A.all('products').filter(p=>p.type!=='service').reduce((s,p)=>s+(+p.stock||0)*(+p.cost||0),0);
/* item aggregation */
an.items=(a,b,keyFn)=>{
  const o={};A.all('invoices').filter(i=>inR(i.t,a,b)).forEach(i=>i.items.forEach(l=>{
    const p=A.find('products',l.pid)||{};const k=keyFn?keyFn(l,p,i):l.pid;const x=o[k]||(o[k]={k,n:'',q:0,r:0,c:0,d:0});
    x.q+=l.qty;x.r+=l.price*l.qty-l.disc;x.c+=l.cost*l.qty;x.d+=l.disc;x.n=x.n||l.name}));
  A.all('returns').filter(r=>inR(r.t,a,b)).forEach(r=>{const inv=A.find('invoices',r.invoiceId);if(!inv)return;r.items.forEach(it=>{const l=inv.items.find(z=>z.pid===it.pid);if(!l)return;const p=A.find('products',l.pid)||{};const k=keyFn?keyFn(l,p,inv):l.pid;const x=o[k];if(!x)return;x.q-=it.qty;x.r-=it.qty*it.net;x.c-=it.qty*l.cost})});
  return Object.values(o);
};
/* ---------- charts (inline SVG) ---------- */
const C=A.chart={};
const nice=m=>{if(m<=0)return 1;const p=Math.pow(10,Math.floor(Math.log10(m))),f=m/p;return(f<=1?1:f<=2?2:f<=5?5:10)*p};
const short=v=>{const a=Math.abs(v);return a>=1e7?N(v/1e7,1)+'Cr':a>=1e5?N(v/1e5,1)+'L':a>=1e3?N(v/1e3,1)+'k':N(v,0)};
C.short=short;
C.line=(labels,series,o)=>{
  o=o||{};const W=720,H=o.h||230,pl=46,pr=12,pt=14,pb=26,iw=W-pl-pr,ih=H-pt-pb;
  const all=series.flatMap(s=>s.vals);const mx=nice(Math.max(1,...all)),mn=Math.min(0,...all);const rng=mx-mn||1;
  const x=i=>pl+(labels.length<2?iw/2:i*iw/(labels.length-1)),y=v=>pt+ih-(v-mn)/rng*ih;
  let g='';for(let k=0;k<=4;k++){const v=mn+rng*k/4,yy=y(v);g+='<line x1="'+pl+'" x2="'+(W-pr)+'" y1="'+yy+'" y2="'+yy+'" stroke="var(--line)" stroke-dasharray="3 4"/><text x="'+(pl-6)+'" y="'+(yy+3.5)+'" text-anchor="end" font-size="10" fill="var(--muted)" font-family="var(--mono)">'+short(v)+'</text>'}
  const step=Math.ceil(labels.length/9);
  labels.forEach((l,i)=>{if(i%step===0||i===labels.length-1)g+='<text x="'+x(i)+'" y="'+(H-8)+'" text-anchor="middle" font-size="10" fill="var(--muted)" font-family="var(--mono)">'+l+'</text>'});
  series.forEach(s=>{
    const pts=s.vals.map((v,i)=>x(i)+','+y(v)).join(' ');
    if(s.area&&s.vals.length>1)g+='<polygon points="'+pl+','+y(0)+' '+pts+' '+x(s.vals.length-1)+','+y(0)+'" fill="'+s.color+'" opacity=".12"/>';
    g+='<polyline fill="none" stroke="'+s.color+'" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" points="'+pts+'"/>';
    if(s.vals.length<=40)s.vals.forEach((v,i)=>{g+='<circle cx="'+x(i)+'" cy="'+y(v)+'" r="3.2" fill="var(--card)" stroke="'+s.color+'" stroke-width="2"><title>'+labels[i]+' · '+s.name+': '+A.money(v)+'</title></circle>'});
  });
  return'<svg viewBox="0 0 '+W+' '+H+'" width="100%" role="img" style="display:block">'+g+'</svg>';
};
C.bars=(labels,vals,o)=>{
  o=o||{};const W=720,H=o.h||180,pl=40,pb=22,pt=10,iw=W-pl-8,ih=H-pt-pb;const mx=nice(Math.max(1,...vals)),bw=iw/labels.length;
  let g='';for(let k=0;k<=3;k++){const yy=pt+ih-ih*k/3;g+='<line x1="'+pl+'" x2="'+(W-8)+'" y1="'+yy+'" y2="'+yy+'" stroke="var(--line)" stroke-dasharray="3 4"/><text x="'+(pl-5)+'" y="'+(yy+3.5)+'" text-anchor="end" font-size="10" fill="var(--muted)" font-family="var(--mono)">'+short(mx*k/3)+'</text>'}
  vals.forEach((v,i)=>{const h=v/mx*ih;g+='<rect x="'+(pl+i*bw+bw*.15)+'" y="'+(pt+ih-h)+'" width="'+bw*.7+'" height="'+Math.max(0,h)+'" rx="3" fill="'+((o.hot&&o.hot(i,v))||o.color||'var(--mintd)')+'"><title>'+labels[i]+': '+A.money(v)+'</title></rect>';if(i%(o.step||1)===0)g+='<text x="'+(pl+i*bw+bw/2)+'" y="'+(H-6)+'" text-anchor="middle" font-size="9.5" fill="var(--muted)" font-family="var(--mono)">'+labels[i]+'</text>'});
  return'<svg viewBox="0 0 '+W+' '+H+'" width="100%" role="img" style="display:block">'+g+'</svg>';
};
C.palette=['#14925f','#ff4a1c','#0d0d0d','#e0a800','#6c8cff','#b05cff','#00a6b5','#8aa39a'];
C.donut=(parts,o)=>{
  const tot=parts.reduce((s,p)=>s+p.v,0)||1;let a0=-Math.PI/2;const R=62,r=40,cx=70,cy=70;let g='';
  parts.forEach((p,i)=>{const a1=a0+p.v/tot*Math.PI*2;const big=a1-a0>Math.PI?1:0;const f=(R,a)=>[cx+R*Math.cos(a),cy+R*Math.sin(a)];const [x0,y0]=f(R,a0),[x1,y1]=f(R,a1),[x2,y2]=f(r,a1),[x3,y3]=f(r,a0);
    if(p.v>0)g+=parts.length===1||p.v===tot?'<circle cx="'+cx+'" cy="'+cy+'" r="'+(R+r)/2+'" fill="none" stroke="'+(p.c||C.palette[i%8])+'" stroke-width="'+(R-r)+'"/>':'<path d="M'+x0+' '+y0+' A'+R+' '+R+' 0 '+big+' 1 '+x1+' '+y1+' L'+x2+' '+y2+' A'+r+' '+r+' 0 '+big+' 0 '+x3+' '+y3+'Z" fill="'+(p.c||C.palette[i%8])+'"><title>'+p.l+': '+A.money(p.v)+'</title></path>';a0=a1});
  const leg=parts.map((p,i)=>'<div class="lg"><i style="background:'+(p.c||C.palette[i%8])+'"></i><span>'+A.esc(p.l)+'</span><b>'+N(p.v/tot*100,0)+'%</b></div>').join('');
  return'<div class="donut"><svg viewBox="0 0 140 140" width="140" height="140" role="img">'+g+'<text x="70" y="68" text-anchor="middle" font-size="9" fill="var(--muted)" font-family="var(--mono)">TOTAL</text><text x="70" y="82" text-anchor="middle" font-size="12" font-weight="800" fill="var(--ink)">'+short(tot)+'</text></svg><div class="legend">'+leg+'</div></div>';
};
C.hbars=(rows,o)=>{
  o=o||{};const mx=Math.max(1,...rows.map(r=>r.v));
  return'<div class="hb">'+rows.map(r=>'<div class="hr"><span class="hl" title="'+A.esc(r.l)+'">'+A.esc(r.l)+'</span><span class="ht"><i style="width:'+Math.max(2,r.v/mx*100)+'%;background:'+(r.c||'var(--mintd)')+'"></i></span><b class="hv">'+(o.fmt?o.fmt(r.v):A.money(r.v))+'</b></div>').join('')+'</div>';
};
C.spark=(vals,color)=>{if(vals.length<2)return'';const W=100,H=28,mx=Math.max(...vals),mn=Math.min(...vals),r=mx-mn||1;const pts=vals.map((v,i)=>(i*W/(vals.length-1))+','+(H-2-(v-mn)/r*(H-4))).join(' ');return'<svg viewBox="0 0 '+W+' '+H+'" width="100" height="28" preserveAspectRatio="none"><polyline fill="none" stroke="'+(color||'currentColor')+'" stroke-width="2" points="'+pts+'"/></svg>'};
})();
